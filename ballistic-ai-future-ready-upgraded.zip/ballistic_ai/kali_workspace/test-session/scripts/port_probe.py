#!/usr/bin/env python3
"""
Simple TCP socket port connectivity test
Usage: python3 port_probe.py <host> <port>
"""
import socket
import sys

def probe(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1.5)
    try:
        s.connect((host, int(port)))
        print(f"[+] {host}:{port} is OPEN")
        s.close()
    except Exception as e:
        print(f"[-] {host}:{port} is CLOSED or FILTERED ({e})")

if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else '127.0.0.1'
    p = sys.argv[2] if len(sys.argv) > 2 else '3000'
    probe(target, p)
