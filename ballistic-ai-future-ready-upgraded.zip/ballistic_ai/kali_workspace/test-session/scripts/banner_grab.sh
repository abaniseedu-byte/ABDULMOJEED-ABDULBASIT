#!/bin/bash
# Banner Grabber script
TARGET="${1:-127.0.0.1}"
PORT="${2:-3000}"
echo "[*] Connecting to ${TARGET}:${PORT}..."
curl -s -I --connect-timeout 2 "http://${TARGET}:${PORT}" | head -n 8
