# Ballistic AI

Ballistic AI is a React/Vite security operations application backed by a Node/Express service. The production build uses live provider APIs and live runtime/network checks; it does not manufacture provider responses, remote agent sessions, provisioning success, or scan telemetry.

## Local development

Requirements: Node.js 20+

```bash
npm install
npm run dev
```

Configure provider credentials through environment variables or the app settings flow.

```env
GEMINI_API_KEY=...
DEEPSEEK_API_KEY=...
OPENAI_API_KEY=...
HMAC_SECRET=...
ENTERPRISE_PROVISION_URL=...   # optional, only when a real provisioning service exists
PORT=3000
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX=120
REQUEST_TIMEOUT_MS=60000
```

## Production

```bash
npm run build
npm start
```

## Reliability rules

- Provider failures are returned as explicit retryable errors instead of fake offline answers.
- C2/agent views never invent remote machines; only actual local runtime sessions are exposed until an authenticated agent transport is configured.
- Enterprise provisioning only reports success after an external provisioning service confirms it.
- Execution telemetry reports measured values rather than fabricated latency, PIDs, or host metadata.
