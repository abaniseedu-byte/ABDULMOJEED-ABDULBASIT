import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ChatConsole } from './components/ChatConsole';
import { DeepResearchConsole } from './components/DeepResearchConsole';
import { CodeHardenerConsole } from './components/CodeHardenerConsole';
import { MitreMatrixView } from './components/MitreMatrixView';
import { CvssCalculatorView } from './components/CvssCalculatorView';
import { DetectionRuleGeneratorView } from './components/DetectionRuleGeneratorView';
import { RealRedTeamConsole } from './components/RealRedTeamConsole';
import { C2ListenerConsole } from './components/C2ListenerConsole';
import { PayloadCompilerView } from './components/PayloadCompilerView';
import { CloudAuditView } from './components/CloudAuditView';
import { EnsembleAIEngine } from './components/EnsembleAIEngine';
import { ZeroDayFuzzer } from './components/ZeroDayFuzzer';
import { ThreatIntelFeed } from './components/ThreatIntelFeed';
import { NetworkInspectorView } from './components/NetworkInspectorView';
import { EdrLab } from './components/EdrLab';
import { ExportHubView } from './components/ExportHubView';
import { EnterpriseUpgradeView } from './components/EnterpriseUpgradeView';
import { KaliTerminal } from './components/KaliTerminal';
import { AutonomousGenesisLab } from './components/AutonomousGenesisLab';
import { BlackHatArsenal } from './components/BlackHatArsenal';
import { ChatHistorySidebar } from './components/ChatHistorySidebar';
import { ApiKeySettingsModal } from './components/ApiKeySettingsModal';
import { 
  OperationalMode, 
  ChatMessage, 
  FileAttachment, 
  DeepResearchReport, 
  CodeAuditResult,
  MitreTechnique,
  AiProvider,
  ChatSession,
  ApiKeyConfig,
  UsageStats
} from './types';

export default function App() {
  const [currentMode, setCurrentMode] = useState<OperationalMode>('red');
  const [activeView, setActiveView] = useState<'chat' | 'research' | 'auditor' | 'mitre' | 'cvss' | 'rules' | 'redteam' | 'c2' | 'compiler' | 'cloud' | 'ensemble' | 'fuzzer' | 'intel' | 'network' | 'edr' | 'export' | 'enterprise' | 'kali' | 'genesis' | 'blackhat'>('genesis');
  const [liveSearch, setLiveSearch] = useState(true);
  const [thinkingBudget, setThinkingBudget] = useState(0);
  const [aiProvider, setAiProvider] = useState<AiProvider>('gemini');
  const [deepseekConfigured, setDeepseekConfigured] = useState(false);
  const [apiKeyActive, setApiKeyActive] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<FileAttachment[]>([]);

  // Chat sessions & history persistence in localStorage
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem('ballistic_ai_chat_sessions');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [{
      id: `session-${Date.now()}`,
      title: 'Initial Security Consultation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: 'gemini',
      provider: 'gemini'
    }];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => sessions[0]?.id || 'default');
  const [searchQuery, setSearchQuery] = useState('');
  const [isHistorySidebarOpen, setIsHistorySidebarOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // API Keys stored securely in localStorage
  const [apiKeys, setApiKeys] = useState<ApiKeyConfig>(() => {
    try {
      const saved = sessionStorage.getItem('ballistic_ai_api_keys');
      if (saved) return JSON.parse(saved);
    } catch {}
    return { geminiKey: '', deepseekKey: '', openaiKey: '', anthropicKey: '' };
  });

  // Free Tier Usage Stats
  const [usageStats, setUsageStats] = useState<UsageStats>(() => {
    try {
      const saved = localStorage.getItem('ballistic_ai_usage_stats');
      const today = new Date().toDateString();
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.lastResetDate === today) return parsed;
      }
      return { requestsToday: 0, tokensToday: 0, lastResetDate: today, freeLimit: 100 };
    } catch {
      return { requestsToday: 0, tokensToday: 0, lastResetDate: new Date().toDateString(), freeLimit: 100 };
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('ballistic_ai_chat_sessions', JSON.stringify(sessions));
    } catch {}
  }, [sessions]);

  useEffect(() => {
    try {
      sessionStorage.setItem('ballistic_ai_api_keys', JSON.stringify(apiKeys));
    } catch {}
  }, [apiKeys]);

  useEffect(() => {
    try {
      localStorage.setItem('ballistic_ai_usage_stats', JSON.stringify(usageStats));
    } catch {}
  }, [usageStats]);

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];
  const messages = activeSession ? activeSession.messages : [];

  const setMessages = (updater: ChatMessage[] | ((prev: ChatMessage[]) => ChatMessage[])) => {
    setSessions(prevSessions => {
      return prevSessions.map(sess => {
        if (sess.id === activeSessionId) {
          const newMsgs = typeof updater === 'function' ? updater(sess.messages) : updater;
          let title = sess.title;
          if ((title.startsWith('Initial') || title.startsWith('Security')) && newMsgs.length > 0) {
            const firstUserMsg = newMsgs.find(m => m.role === 'user');
            if (firstUserMsg) {
              title = firstUserMsg.content.substring(0, 30) + (firstUserMsg.content.length > 30 ? '...' : '');
            }
          }
          return {
            ...sess,
            messages: newMsgs,
            title,
            updatedAt: Date.now()
          };
        }
        return sess;
      });
    });
  };

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: `Security Audit ${sessions.length + 1}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: aiProvider,
      provider: aiProvider
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (sessions.length <= 1) {
      handleClearAllSessions();
      return;
    }
    const remaining = sessions.filter(s => s.id !== id);
    setSessions(remaining);
    if (activeSessionId === id) {
      setActiveSessionId(remaining[0].id);
    }
  };

  const handleClearAllSessions = () => {
    const freshSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'Initial Security Consultation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: aiProvider,
      provider: aiProvider
    };
    setSessions([freshSession]);
    setActiveSessionId(freshSession.id);
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions(prev => prev.map(s => s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s));
  };

  const handleDeleteMessage = (messageId: string) => {
    setMessages(prev => prev.filter(m => m.id !== messageId));
  };

  // Check backend health on mount
  useEffect(() => {
    async function checkHealth() {
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          const data = await res.json();
          setApiKeyActive(data.keyConfigured || false);
          const isDsConfigured = !!(data.deepseek?.configured);
          setDeepseekConfigured(isDsConfigured);
          if (isDsConfigured) {
            setAiProvider('deepseek-chat');
          } else {
            setAiProvider('gemini');
          }
        }
      } catch (err) {
        console.warn('Backend health check error:', err);
      }
    }
    checkHealth();
  }, []);

  // Handle chat submission
  const handleSendMessage = async (text: string, mode: OperationalMode, attachments: FileAttachment[]) => {
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      mode,
      attachments: [...attachments]
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setAttachedFiles([]);
    setIsLoading(true);

    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (apiKeys.geminiKey) headers['x-custom-gemini-key'] = apiKeys.geminiKey;
    if (apiKeys.deepseekKey) headers['x-custom-deepseek-key'] = apiKeys.deepseekKey;
    if (apiKeys.openaiKey) headers['x-custom-openai-key'] = apiKeys.openaiKey;
    if (apiKeys.anthropicKey) headers['x-custom-anthropic-key'] = apiKeys.anthropicKey;

    const postChat = async () => {
      return await fetch('/api/chat', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          messages: newMessages,
          mode,
          liveSearch,
          thinkingBudget,
          attachments,
          provider: aiProvider
        })
      });
    };

    setUsageStats(prev => ({ ...prev, requestsToday: prev.requestsToday + 1 }));

    try {
      let response: Response;
      try {
        response = await postChat();
      } catch (firstErr: any) {
        // Retry once on transient network failure or container restart
        console.warn('First chat fetch failed, attempting immediate retry...', firstErr);
        await new Promise(r => setTimeout(r, 600));
        response = await postChat();
      }

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        const errMsg = (errData.error || '').toLowerCase();
        if (response.status === 429 || response.status === 503 || errMsg.includes('429') || errMsg.includes('503') || errMsg.includes('quota') || errMsg.includes('resource_exhausted') || errMsg.includes('unavailable') || errMsg.includes('high demand')) {
          throw new Error(errData.error || 'AI provider is temporarily unavailable. No synthetic result was generated.');
        }
        throw new Error(errData.error || `Server responded with ${response.status}`);
      }

      const data = await response.json();

      const assistantMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: data.content || 'Analysis generated.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode,
        metadata: data.metadata
      };

      if (typeof data.metadata?.tokensUsed === 'number') {
        setUsageStats(prev => ({ ...prev, tokensToday: prev.tokensToday + data.metadata.tokensUsed }));
      }
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error: any) {
      console.error('Chat error:', error);
      const errMsgStr = String(error?.message || '').toLowerCase();
      const isQuota = errMsgStr.includes('429') || 
                      errMsgStr.includes('503') ||
                      errMsgStr.includes('quota') ||
                      errMsgStr.includes('resource_exhausted') ||
                      errMsgStr.includes('unavailable') ||
                      errMsgStr.includes('high demand');

      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: isQuota
          ? `### ⚠️ Live AI Capacity Unavailable\n\n${error.message || 'The selected AI provider is temporarily unavailable.'}\n\nNo synthetic analysis was generated. Retry the request or switch to a configured provider in Settings.`
          : `### ⚠️ Live AI Connection Error\n\n${error.message || 'Connection interrupted.'}\n\nNo simulated result was generated. Check the backend and provider configuration, then retry.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode,
        metadata: {
          model: 'none',
          quotaExceeded: isQuota,
          isOfflineFallback: false,
          threatSeverity: 'UNKNOWN'
        }
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Run deep research
  const handleRunResearch = async (
    query: string,
    useLiveSearch: boolean,
    attachments: FileAttachment[]
  ): Promise<DeepResearchReport | null> => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/deep-research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          mode: 'research',
          liveSearch: useLiveSearch,
          attachments,
          provider: aiProvider
        })
      });

      if (!response.ok) {
        throw new Error(`Research server error: ${response.status}`);
      }

      const data = await response.json();
      return data.report;
    } catch (err: any) {
      console.error('Research error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Run code audit
  const handleRunAudit = async (
    fileName: string,
    content: string,
    fileType: string,
    sha256?: string
  ): Promise<CodeAuditResult | null> => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/file-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName,
          fileContent: content,
          fileType,
          sha256,
          provider: aiProvider
        })
      });

      if (!response.ok) {
        throw new Error(`Audit server error: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (err: any) {
      console.error('Code audit error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Generate detection rule
  const handleGenerateRule = async (
    threatDescription: string,
    ruleType: string
  ): Promise<string | null> => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/generate-rule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threatDescription, ruleType, provider: aiProvider })
      });

      if (!response.ok) {
        throw new Error(`Rule generation error: ${response.status}`);
      }

      const data = await response.json();
      return data.rule;
    } catch (err: any) {
      console.error('Rule generation error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Transfer MITRE technique to Chat
  const handleSelectTechniqueToChat = (technique: MitreTechnique) => {
    const prompt = `Perform an in-depth security analysis on MITRE ATT&CK Technique ${technique.id} (${technique.name}):
- Describe the adversary mechanics and prerequisites.
- Explain the telemetry logs required to detect this technique (Sysmon, auditd, cloud audit).
- Write defensive detection logic (Sigma / YARA) and remediation controls.`;

    setActiveView('chat');
    setCurrentMode('purple');
    handleSendMessage(prompt, 'purple', []);
  };

  // Transfer CVSS to Chat
  const handleAnalyzeCvssToChat = (vector: string, score: number, severity: string) => {
    const prompt = `Perform a comprehensive triage and remediation priority plan for vulnerability with CVSS v3.1 Vector:
\`${vector}\` (Score: ${score} - Severity: ${severity})

- Analyze each metric's defensive implications.
- Map out immediate containment measures.
- Provide a defense-in-depth architectural mitigation strategy.`;

    setActiveView('chat');
    setCurrentMode('blue');
    handleSendMessage(prompt, 'blue', []);
  };

  return (
    <div className="min-h-screen text-zinc-100 flex flex-col font-sans selection:bg-rose-500/20 selection:text-rose-200 bg-zinc-950 relative overflow-hidden">
      
      {/* Subtle Grid Canvas Pattern */}
      <div className="pointer-events-none fixed inset-0 z-0 opacity-15 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:32px_32px]"></div>
      
      <div className="relative z-10 flex-1 flex flex-col">
        {/* Top Tactical Navigation Header */}
        <Header
          currentMode={currentMode}
          onModeChange={setCurrentMode}
          liveSearch={liveSearch}
          onToggleLiveSearch={() => setLiveSearch(!liveSearch)}
          thinkingBudget={thinkingBudget}
          onToggleThinking={() => setThinkingBudget(prev => (prev === 0 ? 2048 : 0))}
          aiProvider={aiProvider}
          onToggleProvider={() => setAiProvider(prev => prev === 'gemini' ? 'deepseek-chat' : prev === 'deepseek-chat' ? 'deepseek-reasoner' : 'gemini')}
          deepseekConfigured={deepseekConfigured}
          activeView={activeView}
          onViewChange={setActiveView}
          apiKeyActive={apiKeyActive}
        />

        {/* Main Viewport Content */}
        <main className="flex-1 flex flex-col relative">
          {activeView === 'chat' && (
            <div className="flex-1 flex flex-row overflow-hidden">
              <ChatHistorySidebar
                isOpen={isHistorySidebarOpen}
                onToggle={() => setIsHistorySidebarOpen(!isHistorySidebarOpen)}
                sessions={sessions}
                activeSessionId={activeSessionId}
                onSelectSession={(id) => {
                  setActiveSessionId(id);
                  setIsHistorySidebarOpen(false);
                }}
                onNewChat={handleNewChat}
                onDeleteSession={handleDeleteSession}
                onRenameSession={handleRenameSession}
                onClearAllSessions={handleClearAllSessions}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
              />

              <div className="flex-1 flex flex-col min-w-0">
                <ChatConsole
                  messages={messages}
                  onSendMessage={handleSendMessage}
                  isLoading={isLoading}
                  currentMode={currentMode}
                  onModeChange={setCurrentMode}
                  onClearMessages={() => {
                    setMessages([]);
                    setAttachedFiles([]);
                  }}
                  onDeleteMessage={handleDeleteMessage}
                  attachedFiles={attachedFiles}
                  onAddAttachment={(file) => setAttachedFiles(prev => [...prev, file])}
                  onRemoveAttachment={(idx) => setAttachedFiles(prev => prev.filter((_, i) => i !== idx))}
                  liveSearch={liveSearch}
                  onToggleLiveSearch={() => setLiveSearch(!liveSearch)}
                  thinkingBudget={thinkingBudget}
                  onToggleThinking={() => setThinkingBudget(prev => prev > 0 ? 0 : 2000)}
                  aiProvider={aiProvider}
                  onProviderChange={setAiProvider}
                  onOpenSettings={() => setIsSettingsModalOpen(true)}
                  onToggleHistorySidebar={() => setIsHistorySidebarOpen(!isHistorySidebarOpen)}
                  isHistorySidebarOpen={isHistorySidebarOpen}
                  usageRequestsToday={usageStats.requestsToday}
                  usageLimit={usageStats.freeLimit}
                />
              </div>
            </div>
          )}

          <ApiKeySettingsModal
            isOpen={isSettingsModalOpen}
            onClose={() => setIsSettingsModalOpen(false)}
            apiKeys={apiKeys}
            onSaveKeys={setApiKeys}
            usageStats={usageStats}
            onResetUsage={() => setUsageStats(prev => ({ ...prev, requestsToday: 0, tokensToday: 0 }))}
          />

        {activeView === 'research' && (
          <DeepResearchConsole
            onRunResearch={handleRunResearch}
            isLoading={isLoading}
          />
        )}

        {activeView === 'auditor' && (
          <CodeHardenerConsole
            onRunAudit={handleRunAudit}
            isLoading={isLoading}
          />
        )}

        {activeView === 'mitre' && (
          <MitreMatrixView
            onSelectTechniqueToChat={handleSelectTechniqueToChat}
          />
        )}

        {activeView === 'cvss' && (
          <CvssCalculatorView
            onAnalyzeCvss={handleAnalyzeCvssToChat}
          />
        )}

        {activeView === 'rules' && (
          <DetectionRuleGeneratorView
            onGenerateRule={handleGenerateRule}
            isLoading={isLoading}
          />
        )}

        {activeView === 'redteam' && (
          <RealRedTeamConsole
            onExecuteInChat={(prompt) => {
              setActiveView('chat');
              setCurrentMode('red');
              handleSendMessage(prompt, 'red', []);
            }}
          />
        )}

        {activeView === 'c2' && <C2ListenerConsole />}
        {activeView === 'compiler' && <PayloadCompilerView />}
        {activeView === 'cloud' && <CloudAuditView />}
        {activeView === 'ensemble' && <EnsembleAIEngine />}
        {activeView === 'fuzzer' && <ZeroDayFuzzer />}
        {activeView === 'intel' && <ThreatIntelFeed />}
        {activeView === 'network' && <NetworkInspectorView />}
        {activeView === 'edr' && <EdrLab />}
        {activeView === 'export' && <ExportHubView />}
        {activeView === 'enterprise' && <EnterpriseUpgradeView />}
        {activeView === 'kali' && <KaliTerminal />}
        {activeView === 'genesis' && <AutonomousGenesisLab aiProvider={aiProvider} />}
        {activeView === 'blackhat' && (
          <BlackHatArsenal
            onExecuteInChat={(prompt) => {
              setActiveView('chat');
              setCurrentMode('blackhat');
              handleSendMessage(prompt, 'blackhat', []);
            }}
          />
        )}
        </main>

        {/* Global HUD Status Bar */}
        <footer className="border-t border-zinc-800 bg-zinc-950 px-4 py-1.5 flex items-center justify-between text-[11px] font-mono text-zinc-500 z-30 select-none">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              CORE NODE: ACTIVE
            </span>
            <span className="hidden sm:inline border-l border-zinc-800 pl-4 text-zinc-500">
              MITRE ATT&CK v14.1 &bull; CWE Top 25 Mapped
            </span>
          </div>
          <div className="flex items-center gap-4 text-zinc-500">
            <span className="hidden md:inline">
              ENGINE: {aiProvider.toUpperCase()}
            </span>
            <span className="text-zinc-400">BALLISTIC AI SEC-OPS</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
