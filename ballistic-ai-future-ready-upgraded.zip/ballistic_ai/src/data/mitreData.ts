import { MitreTechnique } from '../types';

export interface MitreTacticGroup {
  id: string;
  name: string;
  shortDesc: string;
  techniques: MitreTechnique[];
}

export const MITRE_TACTICS: MitreTacticGroup[] = [
  {
    id: 'TA0043',
    name: 'Reconnaissance',
    shortDesc: 'Gathering information to plan future adversary operations.',
    techniques: [
      {
        id: 'T1595',
        name: 'Active Scanning',
        tactic: 'Reconnaissance',
        description: 'Adversaries may execute active scans to gather info about victim networks (port scanning, vulnerability scanning).',
        detection: 'Monitor inbound network telemetry for broad SYN packets, banner grabs, and sequential port scans.',
        mitigation: 'Implement rate limiting on edge firewalls, disable public exposure of management ports, and use honeypots.'
      },
      {
        id: 'T1596',
        name: 'Search Open Technical Databases',
        tactic: 'Reconnaissance',
        description: 'Harvesting DNS records, WHOIS data, Shodan/Censys exposures, and public cloud bucket mappings.',
        detection: 'Regularly audit public attack surface via external ASM tools to detect asset leakage before adversaries.',
        mitigation: 'Remove debug headers, keep DNS zone transfers disabled, and review public repository history for API keys.'
      }
    ]
  },
  {
    id: 'TA0001',
    name: 'Initial Access',
    shortDesc: 'Techniques that adversaries use to gain entry to the network.',
    techniques: [
      {
        id: 'T1190',
        name: 'Exploit Public-Facing Application',
        tactic: 'Initial Access',
        description: 'Exploiting vulnerabilities in web applications, VPN gateways, or public APIs (SQLi, SSRF, Deserialization).',
        detection: 'Analyze WAF logs for abnormal payloads, inspect application crash dumps, and correlate with web server 500 errors.',
        mitigation: 'Enforce continuous SAST/DAST, apply security patches rapidly, implement WAF in blocking mode, and isolate edge servers.'
      },
      {
        id: 'T1566',
        name: 'Phishing',
        tactic: 'Initial Access',
        description: 'Spearphishing links and weaponized attachments to acquire user session tokens or credentials.',
        detection: 'Deploy email gateway inspection (SPF, DKIM, DMARC), monitor suspicious macro execution from Office binaries.',
        mitigation: 'Enforce FIDO2/WebAuthn hardware MFA, conduct red team phishing simulations, and restrict untrusted macro execution.'
      }
    ]
  },
  {
    id: 'TA0002',
    name: 'Execution',
    shortDesc: 'Techniques that result in adversary-controlled code running.',
    techniques: [
      {
        id: 'T1059',
        name: 'Command and Scripting Interpreter',
        tactic: 'Execution',
        description: 'Abusing PowerShell, Bash, Python, or Windows Command Shell to execute commands or download payloads.',
        detection: 'Enable PowerShell Script Block Logging (Event ID 4104), monitor child processes spawned by web server processes.',
        mitigation: 'Use AppLocker or WDAC to enforce constrained language mode, disallow web server users from spawning shells.'
      },
      {
        id: 'T1203',
        name: 'Exploitation for Client Execution',
        tactic: 'Execution',
        description: 'Exploiting software vulnerabilities in client applications (browsers, document viewers, PDF parsers).',
        detection: 'Monitor endpoint telemetry for unexpected process spawns from Acrobat Reader, Word, or Chrome.',
        mitigation: 'Enable OS-level exploit protections (DEP, ASLR, CFG), isolate untrusted documents in virtual sandboxes.'
      }
    ]
  },
  {
    id: 'TA0003',
    name: 'Persistence',
    shortDesc: 'Techniques used to keep access across restarts and credential resets.',
    techniques: [
      {
        id: 'T1053',
        name: 'Scheduled Task/Job',
        tactic: 'Persistence',
        description: 'Adversaries configure cron jobs, systemd timers, or Windows Task Scheduler to execute malicious code periodically.',
        detection: 'Audit cron table modifications, monitor Windows Security Event 4698 (A scheduled task was created).',
        mitigation: 'Restrict access to crontab and Task Scheduler via least privilege, monitor autorun keys continuously.'
      },
      {
        id: 'T1136',
        name: 'Create Account',
        tactic: 'Persistence',
        description: 'Creating local or cloud accounts (e.g. AWS IAM user with access keys) to maintain continuous access.',
        detection: 'Alert on new user creation events (Windows 4720, AWS CloudTrail CreateUser or CreateAccessKey).',
        mitigation: 'Enforce multi-party approval for new administrator accounts and audit IAM roles via continuous CSPM.'
      }
    ]
  },
  {
    id: 'TA0004',
    name: 'Privilege Escalation',
    shortDesc: 'Techniques used to gain higher-level permissions.',
    techniques: [
      {
        id: 'T1068',
        name: 'Exploitation for Privilege Escalation',
        tactic: 'Privilege Escalation',
        description: 'Exploiting operating system kernel vulnerabilities or SUID binaries to elevate from user to root/SYSTEM.',
        detection: 'Monitor sudden UID changes, inspect auditd logs for setuid execution on unusual binaries.',
        mitigation: 'Mount sensitive partitions with `nosuid`, audit sudoers file permissions, patch kernel CVEs promptly.'
      },
      {
        id: 'T1548',
        name: 'Abuse Elevation Control Mechanism',
        tactic: 'Privilege Escalation',
        description: 'Bypassing UAC in Windows or abusing sudo misconfigurations (e.g., sudo without password on find, nmap, vim).',
        detection: 'Monitor Windows Event 4688 for process elevation anomalies and Linux /var/log/auth.log for suspicious sudo invocations.',
        mitigation: 'Audit sudo privileges to prevent wildcards on scripting runtimes, set UAC to Always Notify.'
      }
    ]
  },
  {
    id: 'TA0005',
    name: 'Defense Evasion',
    shortDesc: 'Techniques used to avoid detection throughout their compromise.',
    techniques: [
      {
        id: 'T1027',
        name: 'Obfuscated/Compressed Files and Information',
        tactic: 'Defense Evasion',
        description: 'Adversaries alter payload signatures via base64, XOR, packers, or dynamic memory decoders to evade AV/EDR.',
        detection: 'Calculate file entropy (values > 7.2 often indicate packing/encryption), inspect process memory for unmapped RWX pages.',
        mitigation: 'Deploy memory-based behavioral EDR inspection and analyze payload entropy during ingress inspection.'
      },
      {
        id: 'T1070',
        name: 'Indicator Removal',
        tactic: 'Defense Evasion',
        description: 'Deleting event logs, bash history, or timestamping files to conceal unauthorized activity.',
        detection: 'Alert on `history -c`, `rm -rf /var/log/*`, or Windows Security Event 1102 (audit log cleared).',
        mitigation: 'Ship logs in real-time to write-once append-only remote SIEM; restrict local log tampering permissions.'
      }
    ]
  },
  {
    id: 'TA0006',
    name: 'Credential Access',
    shortDesc: 'Stealing credentials like account names and passwords.',
    techniques: [
      {
        id: 'T1003',
        name: 'OS Credential Dumping',
        tactic: 'Credential Access',
        description: 'Dumping LSASS memory, SAM hive, or /etc/shadow to extract plaintext credentials or hashes.',
        detection: 'Monitor LSASS handle creation with PROCESS_VM_READ permissions (Sysmon Event ID 10).',
        mitigation: 'Enable Windows Defender Credential Guard, disable WDigest, enforce LSA Protection, and use EDR blocking.'
      },
      {
        id: 'T1558',
        name: 'Steal or Forge Kerberos Tickets',
        tactic: 'Credential Access',
        description: 'Kerberoasting service accounts with weak SPN passwords or Golden/Silver ticket creation.',
        detection: 'Look for RC4 Kerberos ticket requests (TGS Request Event 4769 with encryption type 0x17).',
        mitigation: 'Use managed service accounts (gMSA) with 25+ character complex passwords and enforce AES Kerberos encryption.'
      }
    ]
  },
  {
    id: 'TA0008',
    name: 'Lateral Movement',
    shortDesc: 'Techniques to move through the environment to reach critical targets.',
    techniques: [
      {
        id: 'T1021',
        name: 'Remote Services (SSH, RDP, SMB/WinRM)',
        tactic: 'Lateral Movement',
        description: 'Using stolen credentials to access neighboring servers via WinRM, SMB exec, or SSH keys.',
        detection: 'Detect anomalous internal RDP connections across workstation-to-workstation segments, or sudden PsExec execution.',
        mitigation: 'Isolate internal network segments with zero trust micro-segmentation; disable SMBv1 and workstation-to-workstation traffic.'
      }
    ]
  },
  {
    id: 'TA0010',
    name: 'Exfiltration',
    shortDesc: 'Stealing data from the target network.',
    techniques: [
      {
        id: 'T1048',
        name: 'Exfiltration Over Alternative Protocol',
        tactic: 'Exfiltration',
        description: 'Transferring sensitive files over DNS tunneling, ICMP payloads, or cloud storage APIs.',
        detection: 'Monitor abnormal outbound DNS query lengths, high query volume to single subdomains, or unauthorized S3 bucket writes.',
        mitigation: 'Deploy DNS firewalls with entropy inspection, enforce outbound proxy with SSL inspection, and use DLP policies.'
      }
    ]
  }
];
