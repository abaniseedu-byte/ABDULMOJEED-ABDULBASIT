export type TerminalThemeId =
  | 'kali-dark'
  | 'kali-oled'
  | 'kali-matrix'
  | 'kali-red'
  | 'solarized';

export type PromptStyle = 'zsh-kali' | 'root-kali' | 'compact-1line';
export type CursorStyle = 'block' | 'underline' | 'bar';

export interface TerminalSettings {
  fontSize: number;
  fontFamily: string;
  theme: TerminalThemeId;
  promptStyle: PromptStyle;
  cursorStyle: CursorStyle;
  cursorBlink: boolean;
  audioBell: boolean;
  scrollbackLimit: number;
  showTiming: boolean;
  showExitCode: boolean;
}

export const DEFAULT_TERMINAL_SETTINGS: TerminalSettings = {
  fontSize: 13,
  fontFamily: 'ui-monospace, SFMono-Regular, "JetBrains Mono", Menlo, Monaco, Consolas, monospace',
  theme: 'kali-dark',
  promptStyle: 'zsh-kali',
  cursorStyle: 'block',
  cursorBlink: true,
  audioBell: true,
  scrollbackLimit: 2000,
  showTiming: true,
  showExitCode: true,
};

export interface TerminalEntry {
  id: string;
  type: 'banner' | 'command' | 'completion-matches' | 'system-info';
  user: string;
  hostname: string;
  cwd: string;
  displayCwd: string;
  commandText?: string;
  output?: string;
  stdout?: string;
  stderr?: string;
  exitCode?: number;
  executionTimeMs?: number;
  timestamp: number;
  killed?: boolean;
  completionMatches?: string[];
}

export interface TerminalTab {
  id: string;
  title: string;
  cwd: string;
  displayCwd: string;
  user: string;
  hostname: string;
  entries: TerminalEntry[];
  history: string[];
  historyIndex: number;
  draftInput: string;
  isRunning: boolean;
  runStartTime?: number;
  lastExitCode: number;
}
