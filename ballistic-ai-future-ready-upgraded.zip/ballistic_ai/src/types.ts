export type OperationalMode = 'red' | 'blue' | 'purple' | 'code' | 'research' | 'omni' | 'blackhat';

export type AiProvider = 'gemini' | 'deepseek-chat' | 'deepseek-reasoner' | 'deepseek' | 'gpt-high';

export interface FileAttachment {
  name: string;
  size: number;
  type: string;
  extension: string;
  sha256: string;
  entropy?: number;
  content: string; // text content or base64
  isBase64?: boolean;
  previewSnippet?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  mode?: OperationalMode;
  attachments?: FileAttachment[];
  metadata?: {
    model?: string;
    latencyMs?: number;
    searchGroundingUsed?: boolean;
    sources?: Array<{ title: string; uri: string }>;
    webSearchQueries?: string[];
    tokensUsed?: number;
    reasoningTokens?: number;
    thinking?: string;
    threatSeverity?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'INFO';
    cveList?: string[];
    mitreTactics?: string[];
    quotaExceeded?: boolean;
    isOfflineFallback?: boolean;
  };
}

export interface DeepResearchStep {
  id: string;
  title: string;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
  details?: string;
  findings?: string[];
}

export interface DeepResearchReport {
  id: string;
  query: string;
  timestamp: string;
  steps: DeepResearchStep[];
  executiveSummary: string;
  attackSurfaceAnalysis: string;
  threatVectors: Array<{
    name: string;
    cveOrCwe?: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    description: string;
    offensiveScenario: string;
    defensiveRemediation: string;
  }>;
  detectionEngineering: {
    yaraRule?: string;
    sigmaRule?: string;
    splunkQuery?: string;
  };
  remediationRoadmap: string[];
  fullMarkdown: string;
}

export interface CodeAuditResult {
  vulnerabilities: Array<{
    id: string;
    title: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    cwe: string;
    lineNumbers: string;
    description: string;
    exploitScenario: string;
    remediation: string;
  }>;
  hardenedCode: string;
  summary: string;
  securityScore: number; // 0 to 100
}

export interface MitreTechnique {
  id: string;
  name: string;
  tactic: string;
  description: string;
  detection: string;
  mitigation: string;
}

export interface CvssMetrics {
  av: 'N' | 'A' | 'L' | 'P'; // Attack Vector
  ac: 'L' | 'H'; // Attack Complexity
  pr: 'N' | 'L' | 'H'; // Privileges Required
  ui: 'N' | 'R'; // User Interaction
  s: 'U' | 'C'; // Scope
  c: 'H' | 'L' | 'N'; // Confidentiality
  i: 'H' | 'L' | 'N'; // Integrity
  a: 'H' | 'L' | 'N'; // Availability
}

export interface SynthesizedFile {
  path: string;
  language: string;
  purpose: string;
  content: string;
  loc: number;
}

export interface TestCaseItem {
  id: string;
  name: string;
  type: 'unit' | 'integration' | 'boundary' | 'security';
  code: string;
  status: 'passed' | 'failed';
  durationMs: number;
  assertions: string[];
}

export interface SelfHealingLog {
  pass: number;
  stage: string;
  detection: string;
  actionTaken: string;
  resolved: boolean;
}

export interface AutonomousProject {
  id: string;
  title: string;
  version: string;
  timestamp: string;
  ideaPrompt: string;
  targetDomain: string;
  techStack: string;
  architectureSummary: string;
  designDecisions: string[];
  files: SynthesizedFile[];
  testSuite: TestCaseItem[];
  selfHealingLogs: SelfHealingLog[];
  qualityScore: number;
  securityRating: string;
  zeroPlaceholderVerified: boolean;
  runCommand: string;
  dependencies: Record<string, string>;
  interactiveDemo?: {
    title: string;
    description: string;
    sampleInputs: Array<{ key: string; label: string; defaultValue: string; placeholder?: string }>;
    runHandlerCode?: string;
  };
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  model: string;
  provider: AiProvider;
}

export interface ApiKeyConfig {
  geminiKey: string;
  deepseekKey: string;
  openaiKey: string;
  anthropicKey: string;
}

export interface UsageStats {
  requestsToday: number;
  tokensToday: number;
  lastResetDate: string;
  freeLimit: number;
}
