import React, { useState } from 'react';
import { Zap, Code, ShieldAlert, Play, CheckCircle2, Terminal } from 'lucide-react';

export const ZeroDayFuzzer: React.FC = () => {
  const [targetEndpoint, setTargetEndpoint] = useState<string>('https://target.internal.lab/api/v1/search');
  const [fuzzMode, setFuzzMode] = useState<string>('api');
  const [fuzzResult, setFuzzResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRunFuzzer = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch('/api/fuzz/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetEndpoint, fuzzMode })
      });
      const data = await res.json();
      setFuzzResult(data);
    } catch (err) {
      console.error('Fuzzing failed', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-rose-500 pointer-events-none">
          <Zap className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Zap className="w-4 h-4 text-rose-400" />
            <span>AUTONOMOUS ZERO-DAY FUZZER & EXPLOIT SYNTHESIZER</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Automated Mutation Fuzzing & Exploit PoC Generation
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Continuously probe target endpoints with mutation-based fuzz vectors, isolate memory exceptions, and synthesize reproducible Python exploit proofs-of-concept.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-rose-400" />
            <span>Fuzzer Configuration</span>
          </h2>

          <form onSubmit={handleRunFuzzer} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Target Endpoint URL</label>
              <input
                type="text"
                value={targetEndpoint}
                onChange={(e) => setTargetEndpoint(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Fuzzing Strategy</label>
              <select
                value={fuzzMode}
                onChange={(e) => setFuzzMode(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-rose-500"
              >
                <option value="api">API Parameter Mutation & Injection</option>
                <option value="binary">Binary Heap Spray & Overflow Fuzz</option>
                <option value="protocol">Protocol State Machine Fuzz</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-rose-950/50"
            >
              <Play className="w-4 h-4" />
              <span>{isLoading ? 'Executing Fuzzing Engine...' : 'Launch Zero-Day Fuzz Campaign'}</span>
            </button>
          </form>
        </div>

        {/* Results */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Detected Anomalies & Synthesized PoC</span>
            </h2>

            {fuzzResult ? (
              <div className="space-y-4 font-mono text-xs overflow-y-auto max-h-96">
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">Requests Fuzzed</div>
                    <div className="text-zinc-200 font-bold">{fuzzResult.totalRequestsFuzzed}</div>
                  </div>
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">Anomalies Detected</div>
                    <div className="text-rose-400 font-bold">{fuzzResult.anomaliesDetected}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  {fuzzResult.fuzzResults.map((f: any, idx: number) => (
                    <div key={idx} className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-rose-300">{f.category}</span>
                        <span className="text-[10px] text-zinc-500">Mutation #{idx+1}</span>
                      </div>
                      <div className="text-zinc-400 text-[11px]">Payload: <code className="text-cyan-300">{f.input}</code></div>
                      <div className="text-rose-400 text-[11px]">Response: {f.response}</div>
                    </div>
                  ))}
                </div>

                <div>
                  <div className="text-[11px] text-zinc-400 mb-1">Synthesized Python Exploit PoC</div>
                  <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-emerald-300 overflow-x-auto">
                    <pre className="whitespace-pre-wrap">{fuzzResult.synthesizedExploitPoC}</pre>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-zinc-500 font-mono text-xs text-center">
                <Zap className="w-10 h-10 mb-2 opacity-30 animate-pulse" />
                <span>Configure target endpoint and launch fuzz campaign to isolate zero-day vulnerabilities.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
