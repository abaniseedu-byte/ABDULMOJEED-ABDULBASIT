import React, { useState } from 'react';
import { ShieldAlert, Globe, Server, CheckCircle2, AlertTriangle, Play, FileText, Cpu } from 'lucide-react';

export const CloudAuditView: React.FC = () => {
  const [cloudProvider, setCloudProvider] = useState<'aws' | 'gcp' | 'kubernetes'>('aws');
  const [configText, setConfigText] = useState<string>(
    'resource "aws_s3_bucket" "customer_pii" {\n  bucket = "customer-pii-bucket"\n  acl    = "public-read-write"\n}'
  );
  const [auditResult, setAuditResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRunAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch('/api/cloud/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ configText, cloudProvider })
      });
      const data = await res.json();
      setAuditResult(data);
    } catch (err) {
      console.error('Cloud audit failed', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-rose-500 pointer-events-none">
          <Server className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Server className="w-4 h-4 text-rose-500" />
            <span>CLOUD & KUBERNETES ATTACK PATH MATRIX</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            IAM Privilege Escalation & Cluster Misconfiguration Auditor
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Scan Terraform templates, IAM JSON policies, and Kubernetes YAML manifests for over-permissioned roles, public buckets, and container breakout vectors.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
            <FileText className="w-4 h-4 text-rose-400" />
            <span>Infrastructure Configuration / Policy</span>
          </h2>

          <form onSubmit={handleRunAudit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Target Cloud Provider</label>
              <div className="grid grid-cols-3 gap-2">
                {(['aws', 'gcp', 'kubernetes'] as const).map((prov) => (
                  <button
                    key={prov}
                    type="button"
                    onClick={() => setCloudProvider(prov)}
                    className={`py-2 rounded-xl text-xs font-mono uppercase border transition-all ${
                      cloudProvider === prov
                        ? 'bg-rose-950/80 border-rose-500 text-rose-300 font-bold'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {prov}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Terraform / IAM JSON / K8s Manifest</label>
              <textarea
                value={configText}
                onChange={(e) => setConfigText(e.target.value)}
                rows={8}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-rose-950/50"
            >
              <Play className="w-4 h-4" />
              <span>{isLoading ? 'Scanning Infrastructure...' : 'Execute Security Audit & Attack Path Analysis'}</span>
            </button>
          </form>
        </div>

        {/* Audit Results */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Audit Findings & Attack Vectors</span>
            </h2>

            {auditResult ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-2 font-mono text-xs">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">Total Findings</div>
                    <div className="text-zinc-200 font-bold">{auditResult.totalFindings}</div>
                  </div>
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">Critical</div>
                    <div className="text-rose-400 font-bold">{auditResult.criticalCount}</div>
                  </div>
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">High Risk</div>
                    <div className="text-amber-400 font-bold">{auditResult.highCount}</div>
                  </div>
                </div>

                <div className="space-y-3 overflow-y-auto max-h-72">
                  {auditResult.findings.map((f: any) => (
                    <div key={f.id} className="bg-zinc-950 border border-zinc-800 p-3 rounded-xl space-y-1 font-mono text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-zinc-200">{f.id}: {f.resource}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          f.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {f.severity}
                        </span>
                      </div>
                      <p className="text-zinc-400 text-[11px]">{f.issue}</p>
                      <p className="text-emerald-400 text-[11px] font-semibold mt-1">Fix: {f.remediation}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-zinc-500 font-mono text-xs text-center">
                <Server className="w-10 h-10 mb-2 opacity-30 animate-pulse" />
                <span>Run cloud infrastructure audit to uncover IAM privilege escalation and cluster vulnerabilities.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
