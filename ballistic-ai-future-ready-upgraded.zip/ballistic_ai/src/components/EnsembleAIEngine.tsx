import React, { useState } from 'react';
import { Cpu, Shield, Sparkles, Play, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

export const EnsembleAIEngine: React.FC = () => {
  const [query, setQuery] = useState<string>('Analyze authentication bypass risks in OAuth 2.0 PKCE flow and propose mitigation.');
  const [consensusResult, setConsensusResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRunConsensus = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch('/api/ensemble/consensus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });
      const data = await res.json();
      setConsensusResult(data);
    } catch (err) {
      console.error('Consensus evaluation failed', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-purple-500 pointer-events-none">
          <Sparkles className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-purple-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>MULTI-MODEL AUTONOMOUS CONSENSUS ENGINE (ENSEMBLE AI)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Adversarial Red/Blue Sparring & Judge Synthesis
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Execute real concurrent adversarial evaluation across Gemini 3.8 Flash, DeepSeek V3, and DeepSeek R1 Reasoner to validate exploit vectors and synthesize bulletproof enterprise defensive architectures.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-purple-400" />
            <span>Ensemble Evaluation Prompt</span>
          </h2>

          <form onSubmit={handleRunConsensus} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Target Scenario / Architecture Question</label>
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                rows={5}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-purple-950/50"
            >
              <Play className="w-4 h-4" />
              <span>{isLoading ? 'Running Multi-Model Consensus...' : 'Execute Ensemble Evaluation'}</span>
            </button>
          </form>
        </div>

        {/* Results */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <span>Consensus & Verdict Matrix</span>
            </h2>

            {consensusResult ? (
              <div className="space-y-4 font-mono text-xs overflow-y-auto max-h-96">
                <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 flex items-center justify-between">
                  <span className="text-zinc-400">Confidence Score</span>
                  <span className="text-purple-400 font-bold">{consensusResult.confidenceScore}%</span>
                </div>

                <div className="bg-rose-950/30 border border-rose-900/50 p-3 rounded-xl space-y-1">
                  <div className="text-[10px] text-rose-400 font-bold uppercase">Red Team Assessment</div>
                  <p className="text-zinc-300 text-[11px]">{consensusResult.redTeamAnalysis}</p>
                </div>

                <div className="bg-blue-950/30 border border-blue-900/50 p-3 rounded-xl space-y-1">
                  <div className="text-[10px] text-blue-400 font-bold uppercase">Blue Team Assessment</div>
                  <p className="text-zinc-300 text-[11px]">{consensusResult.blueTeamAnalysis}</p>
                </div>

                <div className="bg-purple-950/40 border border-purple-800/80 p-3 rounded-xl space-y-1">
                  <div className="text-[10px] text-purple-300 font-bold uppercase">Autonomous Judge Verdict</div>
                  <p className="text-purple-200 text-[11px] font-semibold">{consensusResult.consensusVerdict}</p>
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-zinc-500 font-mono text-xs text-center">
                <Sparkles className="w-10 h-10 mb-2 opacity-30 animate-pulse" />
                <span>Trigger multi-model consensus evaluation to generate adversarial sparring insights.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
