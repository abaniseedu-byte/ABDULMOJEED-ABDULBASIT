import React, { useState, useEffect } from 'react';
import { Key, Shield, Sparkles, ExternalLink, Check, Lock, Cpu, Zap, AlertCircle, RefreshCw } from 'lucide-react';
import { ApiKeyConfig, UsageStats } from '../types';

interface ApiKeySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiKeys: ApiKeyConfig;
  onSaveKeys: (keys: ApiKeyConfig) => void;
  usageStats: UsageStats;
  onResetUsage: () => void;
}

export const ApiKeySettingsModal: React.FC<ApiKeySettingsModalProps> = ({
  isOpen,
  onClose,
  apiKeys,
  onSaveKeys,
  usageStats,
  onResetUsage
}) => {
  const [localKeys, setLocalKeys] = useState<ApiKeyConfig>(apiKeys);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [savedMessage, setSavedMessage] = useState(false);
  const [activeTab, setActiveTab] = useState<'keys' | 'limits' | 'upgrade'>('keys');

  useEffect(() => {
    setLocalKeys(apiKeys);
  }, [apiKeys]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveKeys(localKeys);
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 2500);
  };

  const toggleShowKey = (field: string) => {
    setShowKeys(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const percentUsed = Math.min(100, Math.round((usageStats.requestsToday / usageStats.freeLimit) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-zinc-100">API Keys, Usage & Storage</h2>
              <p className="text-xs text-zinc-400">Secure local storage, free models, and paid API upgrades</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-100 text-sm font-medium px-3 py-1.5 rounded-lg hover:bg-zinc-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-zinc-800 bg-zinc-950/30 px-6 gap-6">
          <button
            onClick={() => setActiveTab('keys')}
            className={`py-3 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'keys' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Lock className="w-4 h-4" /> Secure API Keys
          </button>
          <button
            onClick={() => setActiveTab('limits')}
            className={`py-3 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'limits' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Zap className="w-4 h-4" /> Free-Tier Usage Limits
          </button>
          <button
            onClick={() => setActiveTab('upgrade')}
            className={`py-3 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'upgrade' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="w-4 h-4" /> Upgrade to Paid APIs
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {activeTab === 'keys' && (
            <form onSubmit={handleSave} className="space-y-5">
              <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-xl p-4 flex items-start gap-3">
                <Shield className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div className="text-xs text-cyan-200/90 leading-relaxed">
                  <span className="font-semibold text-cyan-300">Secure API-Key Storage:</span> Your custom API keys are stored exclusively in your browser&apos;s encrypted <code className="bg-cyan-950 px-1.5 py-0.5 rounded text-cyan-300">localStorage</code>. They are never logged or stored on our servers and are sent only via secure headers when making API requests.
                </div>
              </div>

              <div className="space-y-4">
                {/* Gemini Key */}
                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5">Google Gemini API Key (Optional Custom Key)</label>
                  <div className="relative">
                    <input
                      type={showKeys['gemini'] ? 'text' : 'password'}
                      value={localKeys.geminiKey}
                      onChange={(e) => setLocalKeys({ ...localKeys, geminiKey: e.target.value })}
                      placeholder="AIzaSy..."
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-cyan-500 pr-20"
                    />
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => toggleShowKey('gemini')}
                        className="text-xs text-zinc-400 hover:text-zinc-200 px-2 py-1"
                      >
                        {showKeys['gemini'] ? 'Hide' : 'Show'}
                      </button>
                    </div>
                  </div>
                  <p className="text-[11px] text-zinc-500 mt-1">Leave blank to use the built-in free tier platform server key.</p>
                </div>

                {/* DeepSeek Key */}
                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5">DeepSeek API Key (Optional Custom Key)</label>
                  <div className="relative">
                    <input
                      type={showKeys['deepseek'] ? 'text' : 'password'}
                      value={localKeys.deepseekKey}
                      onChange={(e) => setLocalKeys({ ...localKeys, deepseekKey: e.target.value })}
                      placeholder="sk-..."
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-cyan-500 pr-20"
                    />
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => toggleShowKey('deepseek')}
                        className="text-xs text-zinc-400 hover:text-zinc-200 px-2 py-1"
                      >
                        {showKeys['deepseek'] ? 'Hide' : 'Show'}
                      </button>
                    </div>
                  </div>
                  <p className="text-[11px] text-zinc-500 mt-1">Enables direct DeepSeek V3 and DeepSeek R1 Reasoner model inference.</p>
                </div>

                {/* OpenAI Key */}
                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5">OpenAI API Key (Optional)</label>
                  <div className="relative">
                    <input
                      type={showKeys['openai'] ? 'text' : 'password'}
                      value={localKeys.openaiKey}
                      onChange={(e) => setLocalKeys({ ...localKeys, openaiKey: e.target.value })}
                      placeholder="sk-proj-..."
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-cyan-500 pr-20"
                    />
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => toggleShowKey('openai')}
                        className="text-xs text-zinc-400 hover:text-zinc-200 px-2 py-1"
                      >
                        {showKeys['openai'] ? 'Hide' : 'Show'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
                <span className="text-xs text-zinc-400">
                  {savedMessage && <span className="text-emerald-400 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Keys saved successfully!</span>}
                </span>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-sm rounded-xl transition-colors shadow-lg shadow-cyan-500/20"
                >
                  Save API Keys
                </button>
              </div>
            </form>
          )}

          {activeTab === 'limits' && (
            <div className="space-y-6">
              <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-zinc-100">Free-Tier Quota Tracker</h3>
                    <p className="text-xs text-zinc-400">Resets daily at 00:00 UTC</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Active & Free
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-400">Requests Today</span>
                    <span className="text-zinc-200 font-medium">{usageStats.requestsToday} / {usageStats.freeLimit}</span>
                  </div>
                  <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                    <div 
                      className={`h-full transition-all duration-500 ${percentUsed > 85 ? 'bg-amber-500' : 'bg-cyan-500'}`}
                      style={{ width: `${percentUsed}%` }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="bg-zinc-900 border border-zinc-800/80 p-3 rounded-xl">
                    <span className="text-xs text-zinc-400 block">Estimated Tokens</span>
                    <span className="text-lg font-bold text-zinc-100 mt-0.5 block">{usageStats.tokensToday.toLocaleString()}</span>
                  </div>
                  <div className="bg-zinc-900 border border-zinc-800/80 p-3 rounded-xl">
                    <span className="text-xs text-zinc-400 block">Local Storage Database</span>
                    <span className="text-lg font-bold text-emerald-400 mt-0.5 block">100% Free</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={onResetUsage}
                  className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1.5 px-3 py-2 rounded-lg bg-zinc-800/50 hover:bg-zinc-800 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Reset Usage Counters
                </button>
                <button
                  onClick={() => setActiveTab('upgrade')}
                  className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  Need unlimited capacity? View paid tiers →
                </button>
              </div>
            </div>
          )}

          {activeTab === 'upgrade' && (
            <div className="space-y-5">
              <div className="bg-gradient-to-br from-cyan-500/10 via-zinc-900 to-indigo-500/10 border border-cyan-500/30 rounded-2xl p-6 space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-semibold">
                  <Sparkles className="w-3.5 h-3.5" /> Easy Upgrade to Paid APIs
                </div>
                <h3 className="text-xl font-bold text-zinc-100">Unlock Enterprise-Grade Rate Limits & High-Throughput Inference</h3>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  Ballistic AI supports seamless switching between free built-in inference and high-performance paid API tiers. Whenever you are ready to scale production workloads or remove rate limits, simply enter your paid API key in the <span className="text-cyan-400 font-medium">Secure API Keys</span> tab.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <a
                    href="https://ai.google.dev"
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-cyan-500/50 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 font-bold">G</div>
                      <div>
                        <div className="text-sm font-medium text-zinc-100 group-hover:text-cyan-400 transition-colors">Google AI Studio</div>
                        <div className="text-[11px] text-zinc-400">Gemini 2.5 Flash / Pro paid tiers</div>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-zinc-500 group-hover:text-cyan-400 transition-colors" />
                  </a>

                  <a
                    href="https://platform.deepseek.com"
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-cyan-500/50 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 font-bold">DS</div>
                      <div>
                        <div className="text-sm font-medium text-zinc-100 group-hover:text-indigo-400 transition-colors">DeepSeek Console</div>
                        <div className="text-[11px] text-zinc-400">DeepSeek V3 & R1 Reasoner</div>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-zinc-500 group-hover:text-indigo-400 transition-colors" />
                  </a>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-zinc-800 bg-zinc-950/60 flex items-center justify-between">
          <span className="text-xs text-zinc-500">Free database & chat history stored locally in browser</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium rounded-xl transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
