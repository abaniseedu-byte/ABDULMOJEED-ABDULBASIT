import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Terminal as TerminalIcon,
  Shield,
  Plus,
  X,
  RefreshCw,
  Search,
  Sliders,
  Maximize2,
  Minimize2,
  Copy,
  Check,
  Square,
  ChevronDown,
  ArrowDown,
  Edit2,
  AlertCircle
} from 'lucide-react';
import {
  TerminalSettings,
  DEFAULT_TERMINAL_SETTINGS,
  TerminalTab,
  TerminalEntry,
  TerminalThemeId
} from '../types/terminal';
import { parseAnsiToReact } from '../utils/ansiParser';
import { TerminalPrompt } from './terminal/TerminalPrompt';
import { TerminalSearchBar } from './terminal/TerminalSearchBar';
import { TerminalSettingsModal } from './terminal/TerminalSettingsModal';
import { TerminalQuickBar } from './terminal/TerminalQuickBar';

// Sound bell helper
function playTerminalBell() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.085);
  } catch {}
}

const THEME_CLASSES: Record<TerminalThemeId, { bg: string; text: string; headerBg: string; border: string }> = {
  'kali-dark': {
    bg: 'bg-[#0b0f19]',
    text: 'text-zinc-200',
    headerBg: 'bg-[#111827]',
    border: 'border-zinc-800'
  },
  'kali-oled': {
    bg: 'bg-[#000000]',
    text: 'text-zinc-100',
    headerBg: 'bg-[#09090b]',
    border: 'border-zinc-800'
  },
  'kali-matrix': {
    bg: 'bg-[#050c07]',
    text: 'text-emerald-300',
    headerBg: 'bg-[#0a180e]',
    border: 'border-emerald-950'
  },
  'kali-red': {
    bg: 'bg-[#0d0707]',
    text: 'text-rose-200',
    headerBg: 'bg-[#1a0c0c]',
    border: 'border-rose-950'
  },
  'solarized': {
    bg: 'bg-[#002b36]',
    text: 'text-[#839496]',
    headerBg: 'bg-[#073642]',
    border: 'border-[#073642]'
  }
};

export const KaliTerminal: React.FC = () => {
  // Terminal Settings
  const [settings, setSettings] = useState<TerminalSettings>(() => {
    try {
      const saved = localStorage.getItem('ballistic_kali_terminal_settings');
      if (saved) {
        return { ...DEFAULT_TERMINAL_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {}
    return DEFAULT_TERMINAL_SETTINGS;
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [terminalHeight, setTerminalHeight] = useState<number>(620);
  const [isResizing, setIsResizing] = useState(false);

  // Search State
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [matchCount, setMatchCount] = useState(0);
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);

  // Copy feedback state
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Tabs / Multi-Session State
  const [tabs, setTabs] = useState<TerminalTab[]>([
    {
      id: 'term_main',
      title: 'Terminal 1',
      cwd: '~/workspace',
      displayCwd: '~',
      user: 'kali',
      hostname: 'kali-rolling',
      entries: [
        {
          id: 'banner-0',
          type: 'banner',
          user: 'kali',
          hostname: 'kali-rolling',
          cwd: '',
          displayCwd: '~',
          output:
            '\x1b[1;36mKali GNU/Linux Rolling x86_64 - Kernel 6.12.9-kali-amd64 (tty1)\x1b[0m\n\n' +
            '  \x1b[1;34m┌──(\x1b[1;36mkali㉿kali-rolling\x1b[1;34m)-[\x1b[1;37m~\x1b[1;34m]\x1b[0m\n' +
            '  \x1b[1;34m└─$\x1b[0m \x1b[32mballistic-kali-terminal v5.0.0 [Active Shell: zsh]\x1b[0m\n' +
            '  \x1b[90mConnected to real Linux execution sandbox. Type "help" or select quick tools below.\x1b[0m\n',
          timestamp: Date.now()
        }
      ],
      history: [],
      historyIndex: -1,
      draftInput: '',
      isRunning: false,
      lastExitCode: 0
    }
  ]);

  const [activeTabId, setActiveTabId] = useState<string>('term_main');
  const [editingTabId, setEditingTabId] = useState<string | null>(null);
  const [editingTabTitle, setEditingTabTitle] = useState('');

  // DOM Refs
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  // Save settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('ballistic_kali_terminal_settings', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Initialize session on server for the active tab
  const initSession = useCallback(async (tabId: string, title?: string) => {
    try {
      const res = await fetch('/api/terminal/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: tabId, sessionName: title })
      });
      if (res.ok) {
        const data = await res.json();
        setTabs(prev =>
          prev.map(tab =>
            tab.id === tabId
              ? {
                  ...tab,
                  cwd: data.cwd || tab.cwd,
                  displayCwd: data.displayCwd || tab.displayCwd,
                  user: data.user || tab.user,
                  hostname: data.hostname || tab.hostname
                }
              : tab
          )
        );
      }
    } catch (err) {
      console.error('Failed to init terminal session:', err);
    }
  }, []);

  useEffect(() => {
    initSession(activeTab.id, activeTab.title);
  }, [activeTab.id, initSession]);

  // Focus input when switching tabs or closing modals
  useEffect(() => {
    if (!isSettingsOpen && !isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [activeTabId, isSettingsOpen, isSearchOpen]);

  // Auto-scroll on new entries if near bottom
  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 160;
    if (isNearBottom || activeTab.isRunning) {
      el.scrollTop = el.scrollHeight;
    }
  }, [activeTab.entries, activeTab.isRunning]);

  // Detect when user scrolls up
  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 100;
    setShowScrollBottom(!isNearBottom);
  };

  const scrollToBottom = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  };

  // Add new tab
  const handleAddTab = () => {
    const newId = `term_${Date.now()}`;
    const newTitle = `Terminal ${tabs.length + 1}`;
    const newTab: TerminalTab = {
      id: newId,
      title: newTitle,
      cwd: '~/workspace',
      displayCwd: '~',
      user: 'kali',
      hostname: 'kali-rolling',
      entries: [
        {
          id: `banner-${newId}`,
          type: 'banner',
          user: 'kali',
          hostname: 'kali-rolling',
          cwd: '',
          displayCwd: '~',
          output: `\x1b[1;36mKali GNU/Linux Rolling x86_64 - Session: ${newTitle}\x1b[0m\n\x1b[90mIsolated session workspace initialized. Ready for commands.\x1b[0m\n`,
          timestamp: Date.now()
        }
      ],
      history: [],
      historyIndex: -1,
      draftInput: '',
      isRunning: false,
      lastExitCode: 0
    };

    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
    initSession(newId, newTitle);
  };

  // Close tab
  const handleCloseTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return; // Keep at least one tab
    const tabToClose = tabs.find(t => t.id === tabId);
    if (tabToClose?.isRunning) {
      if (!confirm('This terminal session has an active running process. Close anyway?')) {
        return;
      }
      handleInterrupt(tabId);
    }

    const nextTabs = tabs.filter(t => t.id !== tabId);
    setTabs(nextTabs);
    if (activeTabId === tabId) {
      setActiveTabId(nextTabs[nextTabs.length - 1].id);
    }
  };

  // Rename Tab
  const startRenameTab = (tabId: string, currentTitle: string) => {
    setEditingTabId(tabId);
    setEditingTabTitle(currentTitle);
  };

  const saveRenameTab = () => {
    if (editingTabId && editingTabTitle.trim()) {
      setTabs(prev =>
        prev.map(t => (t.id === editingTabId ? { ...t, title: editingTabTitle.trim() } : t))
      );
    }
    setEditingTabId(null);
  };

  // Interrupt active running command (Ctrl+C)
  const handleInterrupt = async (tabId?: string) => {
    const targetId = tabId || activeTab.id;
    try {
      await fetch('/api/terminal/kill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: targetId })
      });

      setTabs(prev =>
        prev.map(t => {
          if (t.id === targetId) {
            return {
              ...t,
              isRunning: false,
              entries: [
                ...t.entries,
                {
                  id: `int-${Date.now()}`,
                  type: 'command',
                  user: t.user,
                  hostname: t.hostname,
                  cwd: t.cwd,
                  displayCwd: t.displayCwd,
                  commandText: t.draftInput || '^C',
                  output: '\x1b[1;31m^C [Process terminated by SIGINT]\x1b[0m',
                  exitCode: 130,
                  timestamp: Date.now(),
                  killed: true
                }
              ],
              draftInput: '',
              lastExitCode: 130
            };
          }
          return t;
        })
      );
    } catch (err) {
      console.error('Failed to interrupt process:', err);
    }
  };

  // Execute command
  const executeCommand = async (rawCommand: string) => {
    const trimmed = rawCommand.trim();
    if (!trimmed || activeTab.isRunning) return;

    // Clear built-in special handling
    if (trimmed.toLowerCase() === 'clear') {
      setTabs(prev =>
        prev.map(t =>
          t.id === activeTab.id
            ? {
                ...t,
                entries: [],
                draftInput: '',
                history: [...t.history, trimmed],
                historyIndex: -1
              }
            : t
        )
      );
      return;
    }

    const commandEntryId = `cmd-${Date.now()}`;
    const startTime = Date.now();

    // Mark as running and append command to history
    setTabs(prev =>
      prev.map(t => {
        if (t.id === activeTab.id) {
          return {
            ...t,
            isRunning: true,
            runStartTime: startTime,
            draftInput: '',
            history: [...t.history, trimmed],
            historyIndex: -1,
            entries: [
              ...t.entries.slice(-settings.scrollbackLimit),
              {
                id: commandEntryId,
                type: 'command',
                user: t.user,
                hostname: t.hostname,
                cwd: t.cwd,
                displayCwd: t.displayCwd,
                commandText: trimmed,
                timestamp: startTime
              }
            ]
          };
        }
        return t;
      })
    );

    try {
      const res = await fetch('/api/terminal/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: activeTab.id,
          command: trimmed
        })
      });

      const data = await res.json();
      const exitCode = typeof data.exitCode === 'number' ? data.exitCode : (data.success ? 0 : 1);

      // Play audio bell if non-zero exit code
      if (exitCode !== 0 && settings.audioBell) {
        playTerminalBell();
      }

      setTabs(prev =>
        prev.map(t => {
          if (t.id === activeTab.id) {
            const updatedEntries = t.entries.map(entry => {
              if (entry.id === commandEntryId) {
                return {
                  ...entry,
                  output: data.output || (exitCode === 0 ? '' : 'Process exited with error'),
                  stdout: data.stdout,
                  stderr: data.stderr,
                  exitCode,
                  executionTimeMs: data.executionTimeMs,
                  killed: data.killed
                };
              }
              return entry;
            });

            return {
              ...t,
              isRunning: false,
              cwd: data.cwd || t.cwd,
              displayCwd: data.displayCwd || t.displayCwd,
              lastExitCode: exitCode,
              entries: updatedEntries
            };
          }
          return t;
        })
      );
    } catch (err: any) {
      if (settings.audioBell) playTerminalBell();
      setTabs(prev =>
        prev.map(t => {
          if (t.id === activeTab.id) {
            const updatedEntries = t.entries.map(entry => {
              if (entry.id === commandEntryId) {
                return {
                  ...entry,
                  output: `\x1b[1;31mTerminal communication failure: ${err.message}\x1b[0m`,
                  exitCode: 1,
                  executionTimeMs: Date.now() - startTime
                };
              }
              return entry;
            });

            return {
              ...t,
              isRunning: false,
              lastExitCode: 1,
              entries: updatedEntries
            };
          }
          return t;
        })
      );
    } finally {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  // Tab Completion
  const handleTabCompletion = async () => {
    const input = activeTab.draftInput;
    const cursorPos = inputRef.current?.selectionStart ?? input.length;

    try {
      const res = await fetch('/api/terminal/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: activeTab.id,
          line: input,
          cursorPos
        })
      });

      if (!res.ok) return;
      const data = await res.json();

      if (data.replacement) {
        // Single match auto-completed!
        setTabs(prev =>
          prev.map(t => (t.id === activeTab.id ? { ...t, draftInput: data.replacement } : t))
        );
      } else if (Array.isArray(data.matches) && data.matches.length > 1) {
        // Multiple matches: show completion columns in terminal like real zsh
        setTabs(prev =>
          prev.map(t => {
            if (t.id === activeTab.id) {
              return {
                ...t,
                entries: [
                  ...t.entries,
                  {
                    id: `comp-${Date.now()}`,
                    type: 'completion-matches',
                    user: t.user,
                    hostname: t.hostname,
                    cwd: t.cwd,
                    displayCwd: t.displayCwd,
                    completionMatches: data.matches,
                    timestamp: Date.now()
                  }
                ]
              };
            }
            return t;
          })
        );
      }
    } catch (err) {
      console.error('Tab completion failed:', err);
    }
  };

  // Keyboard Navigation & Shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Tab completion
    if (e.key === 'Tab') {
      e.preventDefault();
      handleTabCompletion();
      return;
    }

    // Ctrl+C - Interrupt
    if (e.ctrlKey && e.key.toLowerCase() === 'c') {
      e.preventDefault();
      if (activeTab.isRunning) {
        handleInterrupt();
      } else {
        // Empty prompt with ^C like real bash
        setTabs(prev =>
          prev.map(t =>
            t.id === activeTab.id
              ? {
                  ...t,
                  entries: [
                    ...t.entries,
                    {
                      id: `cancel-${Date.now()}`,
                      type: 'command',
                      user: t.user,
                      hostname: t.hostname,
                      cwd: t.cwd,
                      displayCwd: t.displayCwd,
                      commandText: t.draftInput,
                      output: '\x1b[1;31m^C\x1b[0m',
                      exitCode: 130,
                      timestamp: Date.now()
                    }
                  ],
                  draftInput: '',
                  historyIndex: -1
                }
              : t
          )
        );
      }
      return;
    }

    // Ctrl+L - Clear Screen
    if (e.ctrlKey && e.key.toLowerCase() === 'l') {
      e.preventDefault();
      setTabs(prev =>
        prev.map(t => (t.id === activeTab.id ? { ...t, entries: [] } : t))
      );
      return;
    }

    // Ctrl+U - Clear line before cursor
    if (e.ctrlKey && e.key.toLowerCase() === 'u') {
      e.preventDefault();
      setTabs(prev =>
        prev.map(t => (t.id === activeTab.id ? { ...t, draftInput: '' } : t))
      );
      return;
    }

    // Ctrl+A - Move cursor to start
    if (e.ctrlKey && e.key.toLowerCase() === 'a') {
      e.preventDefault();
      inputRef.current?.setSelectionRange(0, 0);
      return;
    }

    // Ctrl+E - Move cursor to end
    if (e.ctrlKey && e.key.toLowerCase() === 'e') {
      e.preventDefault();
      const len = activeTab.draftInput.length;
      inputRef.current?.setSelectionRange(len, len);
      return;
    }

    // Ctrl+F - Search
    if (e.ctrlKey && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      setIsSearchOpen(true);
      return;
    }

    // Arrow Up - History
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (activeTab.history.length === 0) return;

      const nextIndex =
        activeTab.historyIndex === -1
          ? activeTab.history.length - 1
          : Math.max(0, activeTab.historyIndex - 1);

      setTabs(prev =>
        prev.map(t =>
          t.id === activeTab.id
            ? {
                ...t,
                historyIndex: nextIndex,
                draftInput: t.history[nextIndex] || ''
              }
            : t
        )
      );
      return;
    }

    // Arrow Down - History
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (activeTab.historyIndex === -1) return;

      const nextIndex = activeTab.historyIndex + 1;
      if (nextIndex >= activeTab.history.length) {
        setTabs(prev =>
          prev.map(t =>
            t.id === activeTab.id
              ? {
                  ...t,
                  historyIndex: -1,
                  draftInput: ''
                }
              : t
          )
        );
      } else {
        setTabs(prev =>
          prev.map(t =>
            t.id === activeTab.id
              ? {
                  ...t,
                  historyIndex: nextIndex,
                  draftInput: t.history[nextIndex] || ''
                }
              : t
          )
        );
      }
      return;
    }
  };

  // Copy full terminal session log
  const handleCopySession = () => {
    const fullLog = activeTab.entries
      .map(e => {
        if (e.type === 'banner') return e.output;
        if (e.type === 'command') {
          return `${e.user}@${e.hostname}:${e.displayCwd}$ ${e.commandText}\n${e.output || ''}`;
        }
        return '';
      })
      .join('\n\n');

    navigator.clipboard.writeText(fullLog).then(() => {
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 2000);
    });
  };

  // Search calculation
  useEffect(() => {
    if (!searchQuery.trim()) {
      setMatchCount(0);
      return;
    }
    const q = searchQuery.toLowerCase();
    let count = 0;
    for (const entry of activeTab.entries) {
      const text = `${entry.commandText || ''} ${entry.output || ''}`.toLowerCase();
      const occurrences = text.split(q).length - 1;
      count += occurrences;
    }
    setMatchCount(count);
  }, [searchQuery, activeTab.entries]);

  // Terminal drag resize
  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
    const startY = e.clientY;
    const startHeight = terminalHeight;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const delta = moveEvent.clientY - startY;
      const newH = Math.min(1000, Math.max(400, startHeight + delta));
      setTerminalHeight(newH);
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const themeStyle = THEME_CLASSES[settings.theme] || THEME_CLASSES['kali-dark'];

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-5">
      {/* Header Banner */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-cyan-500 pointer-events-none">
          <TerminalIcon className="w-36 h-36" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs uppercase tracking-wider font-semibold">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span>KALI LINUX ROLLING &bull; STATEFUL KERNEL SHELL</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-mono font-bold text-zinc-100 tracking-tight flex items-center gap-3">
              <span>Interactive Kali Linux Operations Console</span>
              <span className="text-[11px] font-mono font-normal px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-700/60 text-cyan-300">
                zsh 5.9
              </span>
            </h1>
            <p className="text-xs text-zinc-400 max-w-3xl leading-relaxed">
              Real Bash &amp; Zsh execution environment with working directory persistence, live filesystem navigation, multi-tab sessions, ANSI color parsing, tab autocompletion, and process control.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-800 border border-zinc-700/60 text-zinc-300 hover:text-zinc-100 text-xs font-mono transition-colors"
            >
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <span>Settings</span>
            </button>
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-800 border border-zinc-700/60 text-zinc-300 hover:text-zinc-100 text-xs font-mono transition-colors"
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              <span>{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Terminal Window Frame */}
      <div
        className={`rounded-2xl border ${themeStyle.border} shadow-2xl overflow-hidden flex flex-col transition-all relative ${
          isFullscreen
            ? 'fixed inset-4 z-50 shadow-[0_0_50px_rgba(0,0,0,0.8)]'
            : ''
        }`}
        style={{ height: isFullscreen ? 'calc(100vh - 32px)' : `${terminalHeight}px` }}
      >
        {/* Top Window Bar: OS Controls & Multi-Tab Strip */}
        <div className={`${themeStyle.headerBg} border-b border-zinc-800/90 px-3 py-1.5 flex items-center justify-between select-none z-20`}>
          <div className="flex items-center gap-3 overflow-x-auto max-w-[70%]">
            {/* Window Traffic Lights */}
            <div className="flex items-center gap-1.5 mr-1 flex-shrink-0">
              <span className="w-3 h-3 rounded-full bg-rose-500/90 hover:bg-rose-600 cursor-pointer inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/90 hover:bg-amber-600 cursor-pointer inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/90 hover:bg-emerald-600 cursor-pointer inline-block"></span>
            </div>

            {/* Tab Strip */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
              {tabs.map(tab => {
                const isActive = tab.id === activeTabId;
                return (
                  <div
                    key={tab.id}
                    onClick={() => setActiveTabId(tab.id)}
                    onDoubleClick={() => startRenameTab(tab.id, tab.title)}
                    className={`group px-3 py-1 rounded-md text-xs font-mono flex items-center gap-2 cursor-pointer transition-all border ${
                      isActive
                        ? 'bg-zinc-900 border-zinc-700 text-zinc-100 shadow-sm'
                        : 'bg-zinc-950/60 border-transparent text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'
                    }`}
                  >
                    {tab.isRunning ? (
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping flex-shrink-0" />
                    ) : (
                      <TerminalIcon className={`w-3 h-3 flex-shrink-0 ${isActive ? 'text-cyan-400' : 'text-zinc-500'}`} />
                    )}

                    {editingTabId === tab.id ? (
                      <input
                        type="text"
                        value={editingTabTitle}
                        onChange={(e) => setEditingTabTitle(e.target.value)}
                        onBlur={saveRenameTab}
                        onKeyDown={(e) => e.key === 'Enter' && saveRenameTab()}
                        autoFocus
                        className="w-20 bg-zinc-950 px-1 text-xs text-zinc-100 outline-none border border-cyan-500 rounded"
                      />
                    ) : (
                      <span className="whitespace-nowrap font-medium">{tab.title}</span>
                    )}

                    <button
                      onClick={(e) => handleCloseTab(tab.id, e)}
                      title="Close Tab"
                      className="opacity-40 group-hover:opacity-100 hover:text-rose-400 transition-opacity ml-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}

              <button
                onClick={handleAddTab}
                title="New Terminal Session Tab"
                className="p-1 rounded-md text-zinc-400 hover:text-cyan-300 hover:bg-zinc-800/80 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1.5 text-xs font-mono">
            {/* Live Process Status Badge */}
            {activeTab.isRunning && (
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-amber-950/70 border border-amber-800/80 text-amber-300 text-[11px] animate-pulse mr-2">
                <Square className="w-2.5 h-2.5 fill-amber-400" />
                <span>Running</span>
                <button
                  onClick={() => handleInterrupt()}
                  className="ml-1 underline hover:text-amber-100 font-bold"
                  title="Interrupt with SIGINT (Ctrl+C)"
                >
                  Ctrl+C
                </button>
              </div>
            )}

            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              title="Search Output (Ctrl+F)"
              className={`p-1.5 rounded-lg border transition-colors ${
                isSearchOpen
                  ? 'bg-cyan-950 border-cyan-700 text-cyan-300'
                  : 'bg-zinc-800/60 border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={handleCopySession}
              title="Copy Output"
              className="p-1.5 rounded-lg bg-zinc-800/60 border border-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors relative"
            >
              {copiedNotification ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() =>
                setTabs(prev =>
                  prev.map(t => (t.id === activeTab.id ? { ...t, entries: [] } : t))
                )
              }
              title="Clear Terminal (Ctrl+L)"
              className="p-1.5 rounded-lg bg-zinc-800/60 border border-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              title="Terminal Settings"
              className="p-1.5 rounded-lg bg-zinc-800/60 border border-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Quick Commands Bar */}
        <TerminalQuickBar onSelectCommand={(cmd) => executeCommand(cmd)} />

        {/* Search Bar Overlay */}
        {isSearchOpen && (
          <TerminalSearchBar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            matchCount={matchCount}
            currentMatchIndex={currentMatchIndex}
            onNext={() => setCurrentMatchIndex(prev => (prev + 1) % Math.max(1, matchCount))}
            onPrev={() => setCurrentMatchIndex(prev => (prev - 1 + matchCount) % Math.max(1, matchCount))}
            onClose={() => setIsSearchOpen(false)}
          />
        )}

        {/* Terminal Screen / Output Body */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          onClick={() => inputRef.current?.focus()}
          className={`flex-1 p-4 overflow-y-auto ${themeStyle.bg} ${themeStyle.text} select-text cursor-text space-y-3 relative`}
          style={{
            fontSize: `${settings.fontSize}px`,
            fontFamily: settings.fontFamily
          }}
        >
          {activeTab.entries.map((entry) => {
            if (entry.type === 'banner') {
              return (
                <div key={entry.id} className="whitespace-pre-wrap leading-relaxed">
                  {parseAnsiToReact(entry.output || '', searchQuery)}
                </div>
              );
            }

            if (entry.type === 'completion-matches' && entry.completionMatches) {
              return (
                <div key={entry.id} className="my-1.5 p-2 rounded bg-zinc-900/60 border border-zinc-800/80">
                  <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1 font-semibold">
                    Tab Completions ({entry.completionMatches.length}):
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1 text-xs">
                    {entry.completionMatches.map((match, mIdx) => (
                      <button
                        key={mIdx}
                        onClick={() => {
                          setTabs(prev =>
                            prev.map(t =>
                              t.id === activeTab.id
                                ? { ...t, draftInput: `${t.draftInput}${match} ` }
                                : t
                            )
                          );
                          inputRef.current?.focus();
                        }}
                        className="text-left px-1.5 py-0.5 rounded hover:bg-zinc-800 text-cyan-300 font-mono truncate"
                      >
                        {match}
                      </button>
                    ))}
                  </div>
                </div>
              );
            }

            // Command Entry
            return (
              <div key={entry.id} className="space-y-1 group">
                {/* Prompt + Command Line */}
                <div className="flex items-start gap-2">
                  <TerminalPrompt
                    user={entry.user}
                    hostname={entry.hostname}
                    displayCwd={entry.displayCwd}
                    style={settings.promptStyle}
                  />
                  <div className="flex-1 font-semibold flex items-center justify-between">
                    <span className="text-zinc-100">{entry.commandText}</span>
                    
                    {/* Timing & Exit Code Badges */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2 text-[10px] select-none">
                      {settings.showTiming && typeof entry.executionTimeMs === 'number' && (
                        <span className="text-zinc-500 font-mono">
                          {entry.executionTimeMs}ms
                        </span>
                      )}
                      {settings.showExitCode && typeof entry.exitCode === 'number' && (
                        <span
                          className={`px-1.5 py-0.2 rounded font-mono ${
                            entry.exitCode === 0
                              ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                              : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                          }`}
                        >
                          exit {entry.exitCode}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Output text */}
                {entry.output && (
                  <div className="pl-2 border-l border-zinc-800/60 my-1 whitespace-pre-wrap leading-relaxed font-mono">
                    {parseAnsiToReact(entry.output, searchQuery)}
                  </div>
                )}
              </div>
            );
          })}

          {/* Active Input Line */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              executeCommand(activeTab.draftInput);
            }}
            className="flex items-start gap-2 pt-1"
          >
            <TerminalPrompt
              user={activeTab.user}
              hostname={activeTab.hostname}
              displayCwd={activeTab.displayCwd}
              style={settings.promptStyle}
              isInput
            />
            <div className="flex-1 flex items-center relative">
              <input
                ref={inputRef}
                type="text"
                value={activeTab.draftInput}
                onChange={(e) => {
                  const val = e.target.value;
                  setTabs(prev =>
                    prev.map(t => (t.id === activeTab.id ? { ...t, draftInput: val } : t))
                  );
                }}
                onKeyDown={handleKeyDown}
                disabled={activeTab.isRunning}
                autoFocus
                spellCheck={false}
                autoComplete="off"
                autoCapitalize="off"
                placeholder={activeTab.isRunning ? 'Executing process...' : ''}
                className="w-full bg-transparent text-zinc-100 focus:outline-none font-mono caret-transparent placeholder-zinc-600"
                style={{
                  fontSize: `${settings.fontSize}px`,
                  fontFamily: settings.fontFamily
                }}
              />

              {/* Custom Simulated Terminal Cursor with real styling */}
              {!activeTab.isRunning && (
                <span
                  className={`pointer-events-none select-none inline-block ${
                    settings.cursorBlink ? 'animate-pulse' : ''
                  } ${
                    settings.cursorStyle === 'block'
                      ? 'w-2 h-4 bg-cyan-400 opacity-90'
                      : settings.cursorStyle === 'underline'
                      ? 'w-2.5 h-0.5 bg-cyan-400 self-end mb-1'
                      : 'w-0.5 h-4 bg-cyan-400'
                  }`}
                  style={{
                    marginLeft: `-${Math.max(0, activeTab.draftInput.length - (inputRef.current?.selectionStart ?? activeTab.draftInput.length))}ch`
                  }}
                />
              )}
            </div>
          </form>

          {/* Floating Jump To Bottom button */}
          {showScrollBottom && (
            <button
              onClick={scrollToBottom}
              className="sticky bottom-2 right-4 ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-cyan-950/90 border border-cyan-600 text-cyan-200 text-xs font-mono shadow-xl hover:bg-cyan-900 transition-all z-30"
            >
              <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
              <span>Jump to bottom</span>
            </button>
          )}
        </div>

        {/* Bottom Status Bar */}
        <div className={`${themeStyle.headerBg} border-t border-zinc-800/90 px-3 py-1 flex items-center justify-between text-[11px] font-mono text-zinc-500 select-none`}>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-zinc-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              SESSION: {activeTab.title.toUpperCase()}
            </span>
            <span className="hidden sm:inline border-l border-zinc-800 pl-3">
              CWD: <span className="text-zinc-300 font-semibold">{activeTab.displayCwd}</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden md:inline text-zinc-500">
              SHORTCUTS: Tab (Complete) &bull; Ctrl+C (Interrupt) &bull; Ctrl+L (Clear) &bull; Ctrl+F (Search)
            </span>
            <span className="text-zinc-400 font-medium">
              EXIT: {activeTab.lastExitCode}
            </span>
          </div>
        </div>

        {/* Vertical Resize Drag Handle (non-fullscreen only) */}
        {!isFullscreen && (
          <div
            onMouseDown={handleMouseDownResize}
            title="Drag to resize terminal height"
            className={`h-2 w-full bg-zinc-900/60 hover:bg-cyan-600/60 cursor-ns-resize transition-colors flex items-center justify-center ${
              isResizing ? 'bg-cyan-500' : ''
            }`}
          >
            <div className="w-8 h-1 rounded-full bg-zinc-700"></div>
          </div>
        )}
      </div>

      {/* Settings Modal */}
      <TerminalSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newS) => setSettings(prev => ({ ...prev, ...newS }))}
        onReset={() => setSettings(DEFAULT_TERMINAL_SETTINGS)}
      />
    </div>
  );
};
