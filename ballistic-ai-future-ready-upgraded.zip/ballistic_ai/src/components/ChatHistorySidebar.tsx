import React, { useState } from 'react';
import { 
  MessageSquare, 
  Plus, 
  Search, 
  Trash2, 
  Edit3, 
  Check, 
  X, 
  Clock, 
  Sparkles, 
  ChevronLeft, 
  ChevronRight,
  Database,
  AlertTriangle
} from 'lucide-react';
import { ChatSession } from '../types';

interface ChatHistorySidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onClearAllSessions: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const ChatHistorySidebar: React.FC<ChatHistorySidebarProps> = ({
  isOpen,
  onToggle,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onClearAllSessions,
  searchQuery,
  onSearchChange
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [showConfirmClearAll, setShowConfirmClearAll] = useState(false);
  const [sessionToDelete, setSessionToDelete] = useState<string | null>(null);

  const handleStartRename = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(session.id);
    setEditTitle(session.title);
  };

  const handleSaveRename = (id: string, e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const filteredSessions = sessions.filter(s => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const matchTitle = s.title.toLowerCase().includes(q);
    const matchMessages = s.messages.some(m => m.content.toLowerCase().includes(q));
    return matchTitle || matchMessages;
  });

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          onClick={onToggle}
          className="fixed inset-0 bg-black/60 z-30 lg:hidden backdrop-blur-sm"
        />
      )}

      {/* Sidebar Container */}
      <aside className={`fixed lg:static top-16 bottom-0 left-0 z-40 w-80 bg-zinc-950 border-r border-zinc-800/80 flex flex-col transition-all duration-300 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0 lg:w-80'
      }`}>
        
        {/* Top New Chat & Search */}
        <div className="p-4 border-b border-zinc-800 space-y-3 bg-zinc-900/40">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setShowConfirmClearAll(false);
                onNewChat();
              }}
              className="flex-1 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition-colors shadow-lg shadow-cyan-500/20"
            >
              <Plus className="w-4 h-4" /> New Secure Chat
            </button>
            {sessions.length > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowConfirmClearAll(prev => !prev);
                }}
                title="Delete all chat history"
                className={`font-medium text-xs p-2.5 rounded-xl flex items-center justify-center transition-colors border ${
                  showConfirmClearAll 
                    ? 'bg-red-950 border-red-600 text-red-300' 
                    : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-red-400 border-zinc-800'
                }`}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* In-UI Confirmation Banner for Delete All */}
          {showConfirmClearAll && (
            <div className="bg-red-950/90 border border-red-800/90 rounded-xl p-3 text-xs text-red-200 space-y-2 animate-in fade-in">
              <div className="flex items-center gap-1.5 font-semibold text-red-300">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>Delete All Chat History?</span>
              </div>
              <p className="text-[11px] text-red-300/80 leading-relaxed">
                Permanently purge all {sessions.length} saved sessions and telemetry records from storage.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onClearAllSessions();
                    setShowConfirmClearAll(false);
                  }}
                  className="flex-1 bg-red-600 hover:bg-red-500 text-white font-semibold text-[11px] py-1.5 px-2 rounded-lg transition-colors text-center"
                >
                  Yes, Delete All
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowConfirmClearAll(false);
                  }}
                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] py-1.5 px-3 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search chat history..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-3 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button 
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {filteredSessions.length === 0 ? (
            <div className="text-center py-12 px-4 text-zinc-500 text-xs space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto opacity-30" />
              <p>No chat history found</p>
              <p className="text-[11px] text-zinc-600">Start a new chat or adjust search filter.</p>
            </div>
          ) : (
            filteredSessions.map(session => {
              const isActive = session.id === activeSessionId;
              const isEditing = editingId === session.id;

              return (
                <div
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`group relative rounded-xl p-3 text-left transition-all cursor-pointer border ${
                    isActive 
                      ? 'bg-cyan-500/10 border-cyan-500/30 text-zinc-100 shadow-sm' 
                      : 'bg-zinc-900/40 border-transparent hover:bg-zinc-900 text-zinc-300 hover:text-zinc-100'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? 'text-cyan-400' : 'text-zinc-500'}`} />
                      
                      {isEditing ? (
                        <form onSubmit={(e) => handleSaveRename(session.id, e)} className="flex items-center gap-1 flex-1">
                          <input
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            autoFocus
                            className="w-full bg-zinc-950 border border-cyan-500 rounded px-2 py-0.5 text-xs text-zinc-100 focus:outline-none"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <button type="submit" className="text-cyan-400 hover:text-cyan-300 p-0.5">
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            type="button" 
                            onClick={(e) => { e.stopPropagation(); setEditingId(null); }}
                            className="text-zinc-500 hover:text-zinc-300 p-0.5"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </form>
                      ) : (
                        <div className="min-w-0 flex-1">
                          <h4 className="text-xs font-medium truncate">{session.title}</h4>
                          <span className="text-[10px] text-zinc-500 block mt-0.5">
                            {session.messages.length} msgs • {new Date(session.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      )}
                    </div>

                    {!isEditing && (
                      <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 shrink-0 transition-opacity">
                        <button
                          onClick={(e) => handleStartRename(session, e)}
                          title="Rename chat"
                          className="p-1 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={(e) => onDeleteSession(session.id, e)}
                          title="Delete chat"
                          className="p-1 text-zinc-400 hover:text-red-400 hover:bg-zinc-800 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer Storage Badge */}
        <div className="p-3 border-t border-zinc-800/80 bg-zinc-950/80 flex items-center justify-between text-[11px] text-zinc-500">
          <div className="flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-cyan-400" />
            <span>Local Database Active</span>
          </div>
          <span className="font-mono text-zinc-400">{sessions.length} chats</span>
        </div>

      </aside>
    </>
  );
};
