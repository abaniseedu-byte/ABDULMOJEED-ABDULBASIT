import React, { useState } from 'react';
import { Shield, AlertTriangle, ArrowRight, Flame, Copy, Check } from 'lucide-react';
import { CvssMetrics } from '../types';
import { calculateCvss3 } from '../utils/securityUtils';

interface CvssCalculatorViewProps {
  onAnalyzeCvss: (vector: string, score: number, severity: string) => void;
}

export const CvssCalculatorView: React.FC<CvssCalculatorViewProps> = ({
  onAnalyzeCvss
}) => {
  const [metrics, setMetrics] = useState<CvssMetrics>({
    av: 'N',
    ac: 'L',
    pr: 'N',
    ui: 'N',
    s: 'U',
    c: 'H',
    i: 'H',
    a: 'H'
  });

  const [copiedVector, setCopiedVector] = useState(false);

  const { score, severity, vector } = calculateCvss3(metrics);

  const handleMetricChange = <K extends keyof CvssMetrics>(key: K, value: CvssMetrics[K]) => {
    setMetrics(prev => ({ ...prev, [key]: value }));
  };

  const copyVector = () => {
    navigator.clipboard.writeText(vector);
    setCopiedVector(true);
    setTimeout(() => setCopiedVector(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-950 border border-rose-700/60 flex items-center justify-center text-rose-400 shadow-inner">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              CVSS v3.1 BASE THREAT CALCULATOR
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-950 text-rose-300 border border-rose-800">
                FIRST STANDARD
              </span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5 font-mono">
              Calculate standard vulnerability severity, compute exploitability vs. impact, and evaluate defense priority.
            </p>
          </div>
        </div>

        {/* Live Score Display */}
        <div className="flex items-center gap-4 bg-zinc-950 px-5 py-3 rounded-xl border border-zinc-800">
          <div className="text-right font-mono">
            <span className="text-[10px] text-zinc-500 uppercase block">Base Score</span>
            <span className={`text-2xl font-bold ${
              severity === 'CRITICAL' ? 'text-rose-500' :
              severity === 'HIGH' ? 'text-amber-400' :
              severity === 'MEDIUM' ? 'text-yellow-400' : 'text-emerald-400'
            }`}>
              {score}
            </span>
          </div>

          <div className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold ${
            severity === 'CRITICAL' ? 'bg-rose-950/80 border-rose-600 text-rose-300' :
            severity === 'HIGH' ? 'bg-amber-950/80 border-amber-600 text-amber-300' :
            severity === 'MEDIUM' ? 'bg-yellow-950/80 border-yellow-600 text-yellow-300' :
            'bg-emerald-950/80 border-emerald-600 text-emerald-300'
          }`}>
            {severity}
          </div>
        </div>
      </div>

      {/* Vector string bar */}
      <div className="p-3.5 bg-zinc-900 border border-zinc-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-2 truncate">
          <span className="text-zinc-500">Vector String:</span>
          <span className="text-rose-400 font-semibold select-all truncate">{vector}</span>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            id="copy-cvss-vector-btn"
            type="button"
            onClick={copyVector}
            className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center gap-1 transition-all"
          >
            {copiedVector ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Vector</span>
          </button>
          <button
            id="analyze-cvss-btn"
            type="button"
            onClick={() => onAnalyzeCvss(vector, score, severity)}
            className="px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold flex items-center gap-1.5 transition-all shadow-sm"
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Audit with Ballistic AI</span>
          </button>
        </div>
      </div>

      {/* Metric Option Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Exploitability Metrics */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider border-b border-zinc-800 pb-2">
            Exploitability Metrics
          </h3>

          {/* Attack Vector */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Attack Vector (AV):</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs font-mono">
              {[
                { val: 'N', label: 'Network' },
                { val: 'A', label: 'Adjacent' },
                { val: 'L', label: 'Local' },
                { val: 'P', label: 'Physical' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('av', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.av === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Attack Complexity */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Attack Complexity (AC):</span>
            <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
              {[
                { val: 'L', label: 'Low' },
                { val: 'H', label: 'High' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('ac', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.ac === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Privileges Required */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Privileges Required (PR):</span>
            <div className="grid grid-cols-3 gap-1.5 text-xs font-mono">
              {[
                { val: 'N', label: 'None' },
                { val: 'L', label: 'Low' },
                { val: 'H', label: 'High' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('pr', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.pr === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* User Interaction */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">User Interaction (UI):</span>
            <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
              {[
                { val: 'N', label: 'None' },
                { val: 'R', label: 'Required' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('ui', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.ui === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Scope */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Scope (S):</span>
            <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
              {[
                { val: 'U', label: 'Unchanged' },
                { val: 'C', label: 'Changed' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('s', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.s === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Impact Metrics (CIA Triad) */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider border-b border-zinc-800 pb-2">
            Impact Metrics (CIA Triad)
          </h3>

          {/* Confidentiality Impact */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Confidentiality Impact (C):</span>
            <div className="grid grid-cols-3 gap-1.5 text-xs font-mono">
              {[
                { val: 'H', label: 'High' },
                { val: 'L', label: 'Low' },
                { val: 'N', label: 'None' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('c', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.c === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Integrity Impact */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Integrity Impact (I):</span>
            <div className="grid grid-cols-3 gap-1.5 text-xs font-mono">
              {[
                { val: 'H', label: 'High' },
                { val: 'L', label: 'Low' },
                { val: 'N', label: 'None' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('i', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.i === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Availability Impact */}
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-400">Availability Impact (A):</span>
            <div className="grid grid-cols-3 gap-1.5 text-xs font-mono">
              {[
                { val: 'H', label: 'High' },
                { val: 'L', label: 'Low' },
                { val: 'N', label: 'None' }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => handleMetricChange('a', opt.val as any)}
                  className={`p-2 rounded-lg border text-center transition-all ${
                    metrics.a === opt.val
                      ? 'bg-rose-950 border-rose-500 text-rose-300 font-bold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tactical Advice Panel */}
          <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2 mt-6">
            <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-wider block">
              Automated Severity Triage Directive:
            </span>
            <p className="text-xs font-mono text-zinc-300 leading-relaxed">
              {score >= 9.0
                ? '🔴 CRITICAL: Zero-day level or remote unauthenticated impact. Requires immediate P0 incident response, hotpatch deployment, and micro-segmentation isolation.'
                : score >= 7.0
                ? '🟠 HIGH: Substantial risk to confidentiality or execution integrity. Schedule remediation sprint within 48-72 hours.'
                : score >= 4.0
                ? '🟡 MEDIUM: Conditional exploitability requiring specific privileges or interaction. Remediate in standard release cycle.'
                : '🟢 LOW: Minimal threat surface exposure. Document and apply defensive hardening.'}
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
