import React, { useState, useRef, useEffect } from 'react';
import { 
  Shield, 
  Terminal, 
  Cpu, 
  Flame, 
  Search, 
  Zap, 
  Radio, 
  Activity,
  Code2,
  Sparkles,
  Layers,
  Server,
  Globe,
  Download,
  Building2,
  Skull,
  ChevronDown,
  LayoutGrid,
  Check,
  ShieldCheck,
  Radar,
  MessageSquare
} from 'lucide-react';
import { OperationalMode, AiProvider } from '../types';

interface HeaderProps {
  currentMode: OperationalMode;
  onModeChange: (mode: OperationalMode) => void;
  liveSearch: boolean;
  onToggleLiveSearch: () => void;
  thinkingBudget: number;
  onToggleThinking: () => void;
  aiProvider: AiProvider;
  onToggleProvider: () => void;
  deepseekConfigured?: boolean;
  activeView: 'chat' | 'research' | 'auditor' | 'mitre' | 'cvss' | 'rules' | 'redteam' | 'c2' | 'compiler' | 'cloud' | 'ensemble' | 'fuzzer' | 'intel' | 'network' | 'edr' | 'export' | 'enterprise' | 'kali' | 'genesis' | 'blackhat';
  onViewChange: (view: 'chat' | 'research' | 'auditor' | 'mitre' | 'cvss' | 'rules' | 'redteam' | 'c2' | 'compiler' | 'cloud' | 'ensemble' | 'fuzzer' | 'intel' | 'network' | 'edr' | 'export' | 'enterprise' | 'kali' | 'genesis' | 'blackhat') => void;
  apiKeyActive: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onModeChange,
  liveSearch,
  onToggleLiveSearch,
  thinkingBudget,
  onToggleThinking,
  aiProvider,
  onToggleProvider,
  deepseekConfigured = false,
  activeView,
  onViewChange,
  apiKeyActive,
}) => {
  const [isModulesOpen, setIsModulesOpen] = useState(false);
  const [isModeMenuOpen, setIsModeMenuOpen] = useState(false);
  const modulesRef = useRef<HTMLDivElement>(null);
  const modeMenuRef = useRef<HTMLDivElement>(null);

  // Close menus on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (modulesRef.current && !modulesRef.current.contains(e.target as Node)) {
        setIsModulesOpen(false);
      }
      if (modeMenuRef.current && !modeMenuRef.current.contains(e.target as Node)) {
        setIsModeMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getModeDetails = (mode: OperationalMode) => {
    switch (mode) {
      case 'red':
        return {
          label: 'RED TEAM',
          sub: 'Offensive Exploits & Taint',
          color: 'text-rose-400',
          badge: 'bg-rose-950/60 border-rose-800 text-rose-300'
        };
      case 'blue':
        return {
          label: 'BLUE TEAM',
          sub: 'Defense, SOC & Hardening',
          color: 'text-emerald-400',
          badge: 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
        };
      case 'purple':
        return {
          label: 'PURPLE TEAM',
          sub: 'Dual-Perspective Verification',
          color: 'text-purple-400',
          badge: 'bg-purple-950/60 border-purple-800 text-purple-300'
        };
      case 'code':
        return {
          label: 'CODE HARDENER',
          sub: 'SAST & Auto-Remediation',
          color: 'text-amber-400',
          badge: 'bg-amber-950/60 border-amber-800 text-amber-300'
        };
      case 'research':
        return {
          label: 'DEEP RESEARCH',
          sub: 'Multi-Vector Investigation',
          color: 'text-cyan-400',
          badge: 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
        };
      case 'omni':
        return {
          label: 'OMNI DEFENSE',
          sub: 'Unrestricted Intelligence',
          color: 'text-cyan-300',
          badge: 'bg-cyan-950/80 border-cyan-700 text-cyan-200'
        };
      case 'blackhat':
        return {
          label: 'BLACK HAT',
          sub: 'Offensive Zero-Day Primitives',
          color: 'text-red-400',
          badge: 'bg-red-950/80 border-red-800 text-red-300'
        };
    }
  };

  const modeInfo = getModeDetails(currentMode);

  // Grouped secondary modules
  const moduleCategories = [
    {
      category: 'Offensive Security',
      items: [
        { id: 'redteam', label: 'Real Red Team', icon: Flame, desc: 'Adversary emulation & exploit chains', color: 'text-rose-400' },
        { id: 'c2', label: 'C2 Listener', icon: Radio, desc: 'Live local runtime & authenticated agent sessions', color: 'text-emerald-400' },
        { id: 'compiler', label: 'Payload Compiler', icon: Cpu, desc: 'Evasion shells & encoded stubs', color: 'text-cyan-400' },
        { id: 'fuzzer', label: 'Zero-Day Fuzzer', icon: Zap, desc: 'Boundary mutation & crash triage', color: 'text-rose-400' },
        { id: 'kali', label: 'Kali Linux Terminal', icon: Terminal, desc: 'Live penetration testing shell', color: 'text-emerald-400' }
      ]
    },
    {
      category: 'Defensive & SOC',
      items: [
        { id: 'mitre', label: 'ATT&CK Matrix', icon: Layers, desc: 'MITRE enterprise coverage & telemetry', color: 'text-purple-400' },
        { id: 'cvss', label: 'CVSS 3.1 Calculator', icon: Shield, desc: 'Vulnerability scoring & triage plans', color: 'text-rose-400' },
        { id: 'rules', label: 'Detection Lab', icon: Zap, desc: 'Sigma, YARA & Snort rule synthesis', color: 'text-emerald-400' },
        { id: 'edr', label: 'EDR Sandbox', icon: ShieldCheck, desc: 'Process behavioral analysis & evasions', color: 'text-emerald-400' }
      ]
    },
    {
      category: 'Infrastructure & Intel',
      items: [
        { id: 'cloud', label: 'Cloud & K8s Audit', icon: Server, desc: 'IAM, RBAC & container misconfig checks', color: 'text-rose-400' },
        { id: 'network', label: 'Network & TLS Audit', icon: Activity, desc: 'Ciphers, handshakes & port reconnaissance', color: 'text-cyan-400' },
        { id: 'intel', label: 'Threat Intel Feed', icon: Globe, desc: 'Live CVE, ransomware & APT telemetry', color: 'text-blue-400' },
        { id: 'ensemble', label: 'Ensemble AI Engine', icon: Radar, desc: 'Multi-model consensus cross-verification', color: 'text-purple-400' }
      ]
    },
    {
      category: 'Enterprise & Operations',
      items: [
        { id: 'export', label: 'Export & Reports Hub', icon: Download, desc: 'PDF, JSON & STIX 2.1 compliance packages', color: 'text-cyan-400' },
        { id: 'enterprise', label: 'Enterprise Sovereign', icon: Building2, desc: 'Air-gapped deployment & team licensing', color: 'text-amber-400' }
      ]
    }
  ];

  // Find label if a secondary view is active
  const activeSecondaryItem = moduleCategories
    .flatMap(c => c.items)
    .find(item => item.id === activeView);

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/95 backdrop-blur-md sticky top-0 z-40 px-4 py-2">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onViewChange('genesis')}>
            <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-700/80">
              <Flame className="w-4 h-4 text-rose-500" />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-zinc-950"></span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold tracking-wider text-sm text-zinc-100 flex items-center">
                  BALLISTIC<span className="text-rose-500 font-extrabold">.AI</span>
                </span>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-zinc-900 text-zinc-400 border border-zinc-800">
                  v3.8
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 font-mono tracking-tight hidden sm:block">
                Autonomous Cybersecurity & AI Architecture
              </p>
            </div>
          </div>

          {/* Telemetry pill (Mobile view) */}
          <div className="flex items-center gap-1.5 text-xs font-mono md:hidden">
            <span className={`w-1.5 h-1.5 rounded-full ${apiKeyActive ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
            <span className="text-zinc-400 text-[10px]">{apiKeyActive ? 'ONLINE' : 'LOCAL'}</span>
          </div>
        </div>

        {/* Center: Clean Segmented Operational Navigation */}
        <div className="flex items-center gap-1.5 bg-zinc-900/80 p-1 rounded-lg border border-zinc-800/80 overflow-x-auto max-w-full">
          {/* Primary View 1: Autonomous Architect */}
          <button
            id="view-genesis-btn"
            onClick={() => onViewChange('genesis')}
            className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'genesis'
                ? 'bg-cyan-950/70 text-cyan-300 border border-cyan-600/70 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Architect</span>
          </button>

          {/* Primary View 2: AI Console */}
          <button
            id="view-chat-btn"
            onClick={() => onViewChange('chat')}
            className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'chat'
                ? 'bg-zinc-800 text-zinc-100 border border-zinc-700 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Chat</span>
          </button>

          {/* Primary View 2.5: Kali Linux Terminal */}
          <button
            id="view-kali-btn"
            onClick={() => onViewChange('kali')}
            className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'kali'
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-600/80 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-emerald-400 hover:bg-zinc-800/50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span>Kali Linux</span>
          </button>

          {/* Primary View 3: Deep Research */}
          <button
            id="view-research-btn"
            onClick={() => onViewChange('research')}
            className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'research'
                ? 'bg-cyan-950/70 text-cyan-300 border border-cyan-600/70 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <span>Deep Research</span>
          </button>

          {/* Primary View 4: File & SAST Audit */}
          <button
            id="view-auditor-btn"
            onClick={() => onViewChange('auditor')}
            className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'auditor'
                ? 'bg-amber-950/70 text-amber-300 border border-amber-600/70 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-amber-400" />
            <span>SAST Auditor</span>
          </button>

          {/* Primary View 5: Black Hat Arsenal */}
          <button
            id="view-blackhat-btn"
            onClick={() => onViewChange('blackhat')}
            className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'blackhat'
                ? 'bg-red-950/70 text-red-300 border border-red-600/70 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-red-400 hover:bg-zinc-800/50'
            }`}
          >
            <Skull className="w-3.5 h-3.5 text-red-400" />
            <span>Black Hat</span>
          </button>

          {/* Categorized Modules Dropdown Trigger */}
          <div className="relative" ref={modulesRef}>
            <button
              id="view-all-modules-btn"
              onClick={() => setIsModulesOpen(!isModulesOpen)}
              className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap flex items-center gap-1.5 border ${
                activeSecondaryItem
                  ? 'bg-zinc-800 text-zinc-100 border-zinc-600'
                  : isModulesOpen
                  ? 'bg-zinc-800 text-zinc-200 border-zinc-700'
                  : 'bg-zinc-900/60 text-zinc-400 border-zinc-800/80 hover:text-zinc-200 hover:bg-zinc-800/50'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>{activeSecondaryItem ? activeSecondaryItem.label : 'All Modules'}</span>
              <ChevronDown className={`w-3 h-3 transition-transform ${isModulesOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Categorized Modules Popover */}
            {isModulesOpen && (
              <div className="absolute left-0 mt-2 w-80 sm:w-96 rounded-xl bg-zinc-900 border border-zinc-700/80 shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-100 max-h-[75vh] overflow-y-auto">
                <div className="text-[10px] font-mono uppercase text-zinc-400 tracking-wider mb-2 px-1">
                  Ballistic Security & Intelligence Suite
                </div>

                <div className="space-y-3">
                  {moduleCategories.map((cat, cIdx) => (
                    <div key={cIdx} className="space-y-1">
                      <div className="text-[11px] font-semibold text-zinc-400 px-2 py-0.5 border-b border-zinc-800/80">
                        {cat.category}
                      </div>
                      <div className="grid grid-cols-1 gap-1 pt-1">
                        {cat.items.map((item) => {
                          const IconComp = item.icon;
                          const isSelected = activeView === item.id;
                          return (
                            <button
                              key={item.id}
                              onClick={() => {
                                onViewChange(item.id as any);
                                setIsModulesOpen(false);
                              }}
                              className={`w-full flex items-start gap-2.5 px-2 py-1.5 rounded-lg text-left transition-colors text-xs ${
                                isSelected
                                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-700'
                                  : 'text-zinc-300 hover:bg-zinc-800/60 hover:text-zinc-100'
                              }`}
                            >
                              <div className="p-1 rounded bg-zinc-950 border border-zinc-800 mt-0.5">
                                <IconComp className={`w-3.5 h-3.5 ${item.color}`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="font-mono font-medium flex items-center justify-between">
                                  <span>{item.label}</span>
                                  {isSelected && <Check className="w-3 h-3 text-emerald-400" />}
                                </div>
                                <p className="text-[10px] text-zinc-500 truncate">{item.desc}</p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Operational Controls & Telemetry */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          {/* AI Model Selector */}
          <button
            id="toggle-provider-btn"
            onClick={onToggleProvider}
            title={
              aiProvider.startsWith('deepseek')
                ? deepseekConfigured
                  ? 'Active: Native DeepSeek API. Click to cycle models.'
                  : 'DeepSeek selected (Auto-routed via Gemini 3.8 until DEEPSEEK_API_KEY is configured in Settings). Click to cycle.'
                : 'Active: Gemini 3.8 Flash. Click to cycle models.'
            }
            className={`px-2.5 py-1 rounded-md text-xs font-mono flex items-center gap-1.5 border transition-all ${
              aiProvider === 'deepseek-reasoner'
                ? 'bg-purple-950/70 border-purple-600/70 text-purple-300 font-semibold'
                : aiProvider === 'deepseek-chat' || aiProvider === 'deepseek'
                ? 'bg-cyan-950/70 border-cyan-600/70 text-cyan-300 font-semibold'
                : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
            }`}
          >
            <Cpu className={`w-3.5 h-3.5 ${
              aiProvider === 'deepseek-reasoner' ? 'text-purple-400' :
              aiProvider === 'deepseek-chat' || aiProvider === 'deepseek' ? 'text-cyan-400' : 'text-zinc-400'
            }`} />
            <span>
              {aiProvider === 'deepseek-reasoner' ? 'DeepSeek R1' :
               aiProvider === 'deepseek-chat' || aiProvider === 'deepseek' ? 'DeepSeek V3' :
               'Gemini 3.8'}
            </span>
            {aiProvider.startsWith('deepseek') && !deepseekConfigured && (
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-950/70 border border-amber-800 text-amber-300">
                routed
              </span>
            )}
          </button>

          {/* Live Search Grounding Toggle */}
          <button
            id="toggle-live-search-btn"
            onClick={onToggleLiveSearch}
            title="Toggle Live Web & CVE Search Grounding"
            className={`px-2.5 py-1 rounded-md text-xs font-mono flex items-center gap-1.5 border transition-all ${
              liveSearch
                ? 'bg-blue-950/60 border-blue-600/70 text-blue-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-400 hover:border-zinc-700'
            }`}
          >
            <Radio className={`w-3 h-3 ${liveSearch ? 'text-blue-400 animate-pulse' : 'text-zinc-600'}`} />
            <span className="hidden sm:inline">Web Intel</span>
          </button>

          {/* Deep Thinking Toggle */}
          <button
            id="toggle-thinking-btn"
            onClick={onToggleThinking}
            title="Toggle Deep Neural Reasoning"
            className={`px-2.5 py-1 rounded-md text-xs font-mono flex items-center gap-1.5 border transition-all ${
              thinkingBudget > 0
                ? 'bg-purple-950/60 border-purple-600/70 text-purple-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-400 hover:border-zinc-700'
            }`}
          >
            <Sparkles className={`w-3 h-3 ${thinkingBudget > 0 ? 'text-purple-400 animate-pulse' : 'text-zinc-600'}`} />
            <span className="hidden sm:inline">Deep Reasoning</span>
          </button>

          {/* Operational Posture Menu */}
          <div className="relative" ref={modeMenuRef}>
            <button
              id="header-mode-dropdown-btn"
              onClick={() => setIsModeMenuOpen(!isModeMenuOpen)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-mono transition-all ${modeInfo.badge}`}
              title="Change Security Operational Mode"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
              <span className="font-semibold">{modeInfo.label}</span>
              <ChevronDown className={`w-3 h-3 opacity-70 transition-transform ${isModeMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            {isModeMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-zinc-900 border border-zinc-700/80 shadow-2xl p-2 z-50">
                <div className="text-[10px] font-mono uppercase text-zinc-400 tracking-wider mb-1.5 px-2 py-0.5">
                  Operational Posture
                </div>
                {(['red', 'blue', 'purple', 'code', 'research', 'omni', 'blackhat'] as OperationalMode[]).map((m) => {
                  const info = getModeDetails(m);
                  const isSelected = currentMode === m;
                  return (
                    <button
                      key={m}
                      onClick={() => {
                        onModeChange(m);
                        setIsModeMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-xs font-mono transition-colors text-left ${
                        isSelected ? 'bg-zinc-800 text-zinc-100 font-semibold' : 'text-zinc-300 hover:bg-zinc-800/60'
                      }`}
                    >
                      <div>
                        <div className={`font-semibold ${info.color}`}>{info.label}</div>
                        <div className="text-[10px] text-zinc-500">{info.sub}</div>
                      </div>
                      {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};
