import React, { useState } from 'react';
import { Layers, Search, Shield, Flame, ExternalLink, ArrowRight, Check } from 'lucide-react';
import { MITRE_TACTICS } from '../data/mitreData';
import { MitreTechnique } from '../types';

interface MitreMatrixViewProps {
  onSelectTechniqueToChat: (technique: MitreTechnique) => void;
}

export const MitreMatrixView: React.FC<MitreMatrixViewProps> = ({
  onSelectTechniqueToChat
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTacticId, setSelectedTacticId] = useState<string>(MITRE_TACTICS[0].id);
  const [selectedTechnique, setSelectedTechnique] = useState<MitreTechnique | null>(
    MITRE_TACTICS[0].techniques[0]
  );
  const [injectedId, setInjectedId] = useState<string | null>(null);

  const activeTactic = MITRE_TACTICS.find(t => t.id === selectedTacticId) || MITRE_TACTICS[0];

  const handleInject = (tech: MitreTechnique) => {
    onSelectTechniqueToChat(tech);
    setInjectedId(tech.id);
    setTimeout(() => setInjectedId(null), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      
      {/* Header Banner */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-purple-400 shadow-inner">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              MITRE ATT&CK ENTERPRISE MATRIX NAVIGATOR
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-950 text-purple-300 border border-purple-800">
                v15.1
              </span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5 font-mono">
              Map adversary tactics, explore technique detections, and generate real adversarial emulations and defensive controls.
            </p>
          </div>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
          <input
            id="mitre-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tactics or techniques..."
            className="bg-zinc-950 border border-zinc-800 focus:border-purple-500 rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:outline-none w-full sm:w-64"
          />
        </div>
      </div>

      {/* Tactical Selector Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {MITRE_TACTICS.map((tactic) => (
          <button
            key={tactic.id}
            id={`tactic-tab-${tactic.id}`}
            type="button"
            onClick={() => {
              setSelectedTacticId(tactic.id);
              setSelectedTechnique(tactic.techniques[0] || null);
            }}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all whitespace-nowrap border ${
              selectedTacticId === tactic.id
                ? 'bg-purple-950/80 border-purple-500 text-purple-300 font-bold shadow-sm'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
            }`}
          >
            <span>{tactic.name}</span>
            <span className="ml-1.5 text-[10px] opacity-60">({tactic.techniques.length})</span>
          </button>
        ))}
      </div>

      {/* Main Split Matrix View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Techniques List in Active Tactic */}
        <div className="lg:col-span-5 space-y-2.5">
          <div className="p-3 bg-zinc-900/80 rounded-xl border border-zinc-800">
            <span className="text-[11px] font-mono text-purple-400 font-bold uppercase block">
              {activeTactic.id}: {activeTactic.name}
            </span>
            <p className="text-xs text-zinc-400 mt-1 font-mono leading-relaxed">
              {activeTactic.shortDesc}
            </p>
          </div>

          <div className="space-y-2">
            {activeTactic.techniques
              .filter(t => !searchQuery || t.name.toLowerCase().includes(searchQuery.toLowerCase()) || t.id.toLowerCase().includes(searchQuery.toLowerCase()))
              .map((tech) => (
                <div
                  key={tech.id}
                  id={`tech-item-${tech.id}`}
                  onClick={() => setSelectedTechnique(tech)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    selectedTechnique?.id === tech.id
                      ? 'bg-purple-950/40 border-purple-500 text-zinc-100 shadow-md'
                      : 'bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700 text-zinc-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-purple-400">{tech.id}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                      Enterprise
                    </span>
                  </div>
                  <h4 className="text-sm font-mono font-semibold mt-1 text-zinc-100">
                    {tech.name}
                  </h4>
                  <p className="text-xs text-zinc-400 mt-1 line-clamp-2 font-sans">
                    {tech.description}
                  </p>
                </div>
              ))}
          </div>
        </div>

        {/* Technique Detail Inspector */}
        <div className="lg:col-span-7">
          {selectedTechnique ? (
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5 shadow-2xl sticky top-20">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-purple-400 bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
                      {selectedTechnique.id}
                    </span>
                    <span className="text-xs font-mono text-zinc-500">Tactic: {selectedTechnique.tactic}</span>
                  </div>
                  <h3 className="text-lg font-mono font-bold text-zinc-100 mt-1.5">
                    {selectedTechnique.name}
                  </h3>
                </div>

                <button
                  id="inject-to-chat-btn"
                  type="button"
                  onClick={() => handleInject(selectedTechnique)}
                  className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-semibold flex items-center gap-2 shadow-lg transition-all"
                >
                  {injectedId === selectedTechnique.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Transferred to Terminal</span>
                    </>
                  ) : (
                    <>
                      <Flame className="w-3.5 h-3.5 text-rose-300" />
                      <span>Inject into Ballistic AI</span>
                    </>
                  )}
                </button>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider">
                  Adversarial Mechanism
                </h4>
                <p className="text-xs text-zinc-300 font-mono leading-relaxed bg-zinc-950 p-4 rounded-xl border border-zinc-800">
                  {selectedTechnique.description}
                </p>
              </div>

              {/* Telemetry & Detection */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" />
                  Telemetry & Detection Engineering
                </h4>
                <p className="text-xs text-zinc-300 font-mono leading-relaxed bg-cyan-950/20 p-4 rounded-xl border border-cyan-800/40">
                  {selectedTechnique.detection}
                </p>
              </div>

              {/* Mitigation & Hardening */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" />
                  Hardening & Defensive Countermeasures
                </h4>
                <p className="text-xs text-zinc-300 font-mono leading-relaxed bg-emerald-950/20 p-4 rounded-xl border border-emerald-800/40">
                  {selectedTechnique.mitigation}
                </p>
              </div>
            </div>
          ) : (
            <div className="border border-zinc-800 rounded-2xl p-12 text-center text-zinc-500 font-mono text-sm">
              Select a technique to inspect its adversarial mechanics and defensive mitigations.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
