import React, { useState } from 'react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { 
  Code2, 
  ShieldAlert, 
  ShieldCheck, 
  Copy, 
  Check, 
  Download, 
  RefreshCw, 
  AlertTriangle, 
  Terminal, 
  FileCode,
  Sparkles,
  ArrowRight,
  Plus,
  Archive
} from 'lucide-react';
import { CodeAuditResult, FileAttachment } from '../types';
import { FileUploader } from './FileUploader';

interface CodeHardenerConsoleProps {
  onRunAudit: (fileName: string, content: string, fileType: string, sha256?: string) => Promise<CodeAuditResult | null>;
  isLoading: boolean;
}

const SAMPLE_VULNERABLE_SNIPPETS: { label: string; lang: string; code: string }[] = [
  {
    label: 'Python: SQLi & Command Injection',
    lang: 'python',
    code: `import os
import sqlite3
from flask import Flask, request

app = Flask(__name__)

@app.route("/api/user/lookup")
def user_lookup():
    user_id = request.args.get("id")
    # CWE-89: Direct string interpolation into SQL query
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE id = '{user_id}'"
    res = cursor.execute(query).fetchall()

    # CWE-78: Unsanitized input to OS command
    ping_ip = request.args.get("ip")
    if ping_ip:
        os.system(f"ping -c 1 {ping_ip}")

    return {"results": res}
`
  },
  {
    label: 'Solidity: Reentrancy & Integer Overflow',
    lang: 'solidity',
    code: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract VulnerableVault {
    mapping(address => uint256) public balances;

    function deposit() external payable {
        balances[msg.sender] += msg.value;
    }

    // CWE-841: Reentrancy vulnerability (State update after transfer)
    function withdraw() external {
        uint256 amount = balances[msg.sender];
        require(amount > 0, "Zero balance");

        (bool success, ) = msg.sender.call{value: amount}("");
        require(success, "Transfer failed");

        balances[msg.sender] = 0; // State updated after external call!
    }
}
`
  },
  {
    label: 'TypeScript: SSRF & Prototype Pollution',
    lang: 'typescript',
    code: `import express from "express";
import http from "http";

const app = express();
app.use(express.json());

// CWE-918: Server-Side Request Forgery (SSRF)
app.post("/api/proxy", async (req, res) => {
  const { targetUrl } = req.body;
  // Unvalidated fetch to internal VPC or cloud metadata service (169.254.169.254)
  const response = await fetch(targetUrl);
  const data = await response.text();
  res.send(data);
});

// CWE-1321: Prototype Pollution
app.post("/api/merge-config", (req, res) => {
  const target: any = {};
  const source = req.body;
  for (const key in source) {
    target[key] = source[key];
  }
  res.json({ status: "merged", config: target });
});
`
  }
];

export const CodeHardenerConsole: React.FC<CodeHardenerConsoleProps> = ({
  onRunAudit,
  isLoading
}) => {
  const [activeTab, setActiveTab] = useState<'input' | 'results'>('input');
  const [code, setCode] = useState(SAMPLE_VULNERABLE_SNIPPETS[0].code);
  const [fileName, setFileName] = useState('vulnerable_service.py');
  const [fileSha, setFileSha] = useState<string>('');
  const [auditResult, setAuditResult] = useState<CodeAuditResult | null>(null);
  const [copiedHardened, setCopiedHardened] = useState(false);
  const [activeCodeView, setActiveCodeView] = useState<'hardened' | 'original'>('hardened');

  const handleAudit = async () => {
    if (!code.trim() || isLoading) return;
    const res = await onRunAudit(fileName, code, 'source_code', fileSha);
    if (res) {
      setAuditResult(res);
      setActiveTab('results');
      setActiveCodeView('hardened');
    }
  };

  const handleFileUploaded = (attachment: FileAttachment) => {
    setFileName(attachment.name);
    setCode(attachment.content);
    setFileSha(attachment.sha256);
  };

  const handleCopyHardened = () => {
    if (!auditResult) return;
    navigator.clipboard.writeText(auditResult.hardenedCode);
    setCopiedHardened(true);
    setTimeout(() => setCopiedHardened(false), 2000);
  };

  const handleDownloadHardened = () => {
    if (!auditResult) return;
    const blob = new Blob([auditResult.hardenedCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hardened_${fileName}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    if (!auditResult) return;
    const zip = new JSZip();
    
    // Add original code
    zip.file(`original_${fileName}`, code);
    
    // Add hardened code
    zip.file(`hardened_${fileName}`, auditResult.hardenedCode);
    
    // Add vulnerability report
    const reportContent = `# Vulnerability Report for ${fileName}\n\n## Executive Summary\n${auditResult.summary}\n\n## Security Score: ${auditResult.securityScore}/100\n\n## Vulnerabilities\n\n${auditResult.vulnerabilities.map(v => `### ${v.title} (${v.severity})\n- **CWE:** ${v.cwe}\n- **Lines:** ${v.lineNumbers}\n- **Description:** ${v.description}\n- **Exploit Scenario:** ${v.exploitScenario}\n- **Remediation:** ${v.remediation}\n`).join('\n')}`;
    zip.file(`audit_report_${fileName}.md`, reportContent);
    
    const zipContent = await zip.generateAsync({ type: 'blob' });
    saveAs(zipContent, `ballistic-audit-${fileName}.zip`);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-700/60 flex items-center justify-center text-amber-400 shadow-inner">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              BALLISTIC CODE AUDITOR & HARDENER
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-950 text-amber-300 border border-amber-800">
                SAST + REWRITE
              </span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5 font-mono">
              Upload any file or code snippet for static taint analysis, CWE discovery, and mathematical zero-defect hardening.
            </p>
          </div>
        </div>

          <div className="flex items-center gap-2">
            {auditResult && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs font-mono">
                <span className="text-zinc-400">Security Score:</span>
                <span className={`font-bold ${
                  auditResult.securityScore >= 80 ? 'text-emerald-400' :
                  auditResult.securityScore >= 50 ? 'text-amber-400' : 'text-rose-500'
                }`}>
                  {auditResult.securityScore}/100
                </span>
              </div>
            )}

            {auditResult && (
              <button
                id="new-audit-btn"
                type="button"
                onClick={() => {
                  setAuditResult(null);
                  setActiveTab('input');
                }}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 text-xs font-mono font-medium flex items-center gap-1.5 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New Audit</span>
              </button>
            )}

            <button
              id="audit-execute-btn"
              type="button"
              disabled={isLoading || !code.trim()}
              onClick={handleAudit}
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-black font-mono text-xs font-bold flex items-center gap-2 shadow-lg transition-all"
            >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>AUDITING CODE...</span>
              </>
            ) : (
              <>
                <ShieldAlert className="w-4 h-4" />
                <span>RUN BALLISTIC AUDIT</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Code Input / File Upload (4 cols or full depending on state) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* File Upload Zone */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
            <span className="text-xs font-mono font-bold text-zinc-300 block">
              1. Upload File or Select Sample
            </span>
            <FileUploader onFileSelect={handleFileUploaded} compact={false} />
            
            <div className="pt-2 border-t border-zinc-800">
              <span className="text-[11px] font-mono text-zinc-500 block mb-1.5">Preset Vulnerable Code:</span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_VULNERABLE_SNIPPETS.map((s, idx) => (
                  <button
                    key={idx}
                    id={`sample-snippet-${idx}`}
                    type="button"
                    onClick={() => {
                      setCode(s.code);
                      setFileName(s.label.includes('Python') ? 'service.py' : s.label.includes('Solidity') ? 'vault.sol' : 'server.ts');
                    }}
                    className="px-2 py-1 rounded bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-[10px] font-mono text-zinc-400 hover:text-amber-300 transition-colors"
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Editable Source Code Buffer */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-zinc-300">
                Source Buffer: <span className="text-amber-400 font-normal">{fileName}</span>
              </span>
              <span className="text-[10px] font-mono text-zinc-500">
                {code.split('\n').length} lines
              </span>
            </div>
            <textarea
              id="code-auditor-textarea"
              rows={14}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500 rounded-lg p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:ring-1 focus:ring-amber-500 resize-y leading-relaxed"
            />
          </div>
        </div>

        {/* Right Column: Audit Triage & Hardened Code (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {!auditResult ? (
            <div className="h-full min-h-[400px] border border-dashed border-zinc-800 rounded-2xl bg-zinc-900/30 p-8 flex flex-col items-center justify-center text-center">
              <ShieldCheck className="w-12 h-12 text-zinc-700 mb-3" />
              <h3 className="text-sm font-mono font-bold text-zinc-400">
                Awaiting Static Application Security Testing
              </h3>
              <p className="text-xs text-zinc-500 max-w-sm mt-1 font-mono">
                Click &quot;Run Ballistic Audit&quot; to identify vulnerabilities, map CWE vectors, and produce mathematically hardened code.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              
              {/* Executive Posture & Score */}
              <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400" />
                    Security Posture Assessment
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-zinc-400">Found Flaws:</span>
                    <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800">
                      {auditResult.vulnerabilities.length} Weaknesses
                    </span>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 font-sans leading-relaxed">
                  {auditResult.summary}
                </p>
              </div>

              {/* Vulnerabilities List */}
              <div className="space-y-2.5">
                <span className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider block">
                  Identified Weaknesses & CWE Citations:
                </span>
                {auditResult.vulnerabilities.map((v, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2 text-xs font-mono">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          v.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                          v.severity === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                          'bg-zinc-800 text-zinc-300 border border-zinc-700'
                        }`}>
                          {v.severity}
                        </span>
                        <span className="font-bold text-zinc-100">{v.title}</span>
                      </div>
                      <span className="text-amber-400 font-semibold">{v.cwe}</span>
                    </div>

                    <p className="text-zinc-300 font-sans leading-relaxed text-[11px]">
                      {v.description}
                    </p>

                    <div className="p-2.5 rounded bg-zinc-900/90 border border-zinc-800/80 text-[11px] text-emerald-300">
                      <span className="font-bold text-emerald-400 block mb-0.5">Remediation:</span>
                      {v.remediation}
                    </div>
                  </div>
                ))}
              </div>

              {/* Hardened Code Viewer */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                <div className="p-3 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      id="view-hardened-btn"
                      type="button"
                      onClick={() => setActiveCodeView('hardened')}
                      className={`px-2.5 py-1 rounded text-xs font-mono transition-all ${
                        activeCodeView === 'hardened'
                          ? 'bg-amber-950/60 border border-amber-700 text-amber-300 font-semibold'
                          : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      🛡️ Ballistic Hardened Code
                    </button>
                    <button
                      id="view-original-btn"
                      type="button"
                      onClick={() => setActiveCodeView('original')}
                      className={`px-2.5 py-1 rounded text-xs font-mono transition-all ${
                        activeCodeView === 'original'
                          ? 'bg-zinc-800 text-zinc-200 border border-zinc-700 font-semibold'
                          : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      Original Vulnerable Code
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      id="copy-hardened-btn"
                      type="button"
                      onClick={handleCopyHardened}
                      className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs font-mono text-zinc-300 flex items-center gap-1 transition-all"
                    >
                      {copiedHardened ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>Copy</span>
                    </button>
                    <button
                      id="download-zip-btn"
                      type="button"
                      onClick={handleDownloadZip}
                      className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-xs font-mono flex items-center gap-1 transition-all"
                    >
                      <Archive className="w-3.5 h-3.5" />
                      <span>ZIP Archive</span>
                    </button>
                    <button
                      id="download-hardened-btn"
                      type="button"
                      onClick={handleDownloadHardened}
                      className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-black font-semibold text-xs font-mono flex items-center gap-1 transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Patch</span>
                    </button>
                  </div>
                </div>

                <pre className="p-4 bg-zinc-950 text-xs font-mono text-zinc-200 overflow-x-auto max-h-[500px] leading-relaxed">
                  {activeCodeView === 'hardened' ? auditResult.hardenedCode : code}
                </pre>
              </div>

            </div>
          )}
        </div>

      </div>

    </div>
  );
};
