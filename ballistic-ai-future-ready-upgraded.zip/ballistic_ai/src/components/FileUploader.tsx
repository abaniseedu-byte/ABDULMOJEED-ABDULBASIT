import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileCode, 
  Binary, 
  FileText, 
  CheckCircle2, 
  X, 
  AlertTriangle, 
  Hash, 
  Activity, 
  Eye, 
  ShieldAlert,
  ArrowRight,
  Fingerprint
} from 'lucide-react';
import { FileAttachment } from '../types';
import { computeSha256, calculateEntropy, formatBytes, generateHexDump } from '../utils/securityUtils';

interface FileUploaderProps {
  onFileSelect?: (file: FileAttachment) => void;
  onAuditTrigger?: (file: FileAttachment) => void;
  compact?: boolean;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  onFileSelect,
  onAuditTrigger,
  compact = false
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [currentFile, setCurrentFile] = useState<FileAttachment | null>(null);
  const [hexViewActive, setHexViewActive] = useState(false);
  const [hexDump, setHexDump] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (rawFile: File) => {
    try {
      setProcessing(true);
      const buffer = await rawFile.arrayBuffer();
      const sha256 = await computeSha256(buffer);
      const entropy = calculateEntropy(buffer);
      const ext = rawFile.name.split('.').pop()?.toLowerCase() || 'txt';
      
      let textContent = '';
      let isBase64 = false;

      // Determine if text or binary
      const isLikelyBinary = entropy > 7.3 || rawFile.type.includes('octet-stream') || ['bin', 'exe', 'elf', 'pcap', 'so', 'dll', 'class', 'wasm', 'iso', 'img', 'dmp'].includes(ext);

      if (!isLikelyBinary) {
        try {
          const decoder = new TextDecoder('utf-8', { fatal: true });
          textContent = decoder.decode(buffer);
        } catch {
          // If strict utf-8 decode fails, fallback to lossless binary base64 conversion
          isBase64 = true;
          const bytes = new Uint8Array(buffer);
          let binaryStr = '';
          const chunkSize = 8192;
          for (let i = 0; i < bytes.length; i += chunkSize) {
            const chunk = bytes.subarray(i, i + chunkSize);
            binaryStr += String.fromCharCode.apply(null, Array.from(chunk));
          }
          textContent = btoa(binaryStr);
        }
      } else {
        isBase64 = true;
        const bytes = new Uint8Array(buffer);
        let binaryStr = '';
        const chunkSize = 8192;
        for (let i = 0; i < bytes.length; i += chunkSize) {
          const chunk = bytes.subarray(i, i + chunkSize);
          binaryStr += String.fromCharCode.apply(null, Array.from(chunk));
        }
        textContent = btoa(binaryStr);
      }

      const hex = generateHexDump(buffer, Math.min(buffer.byteLength, 4096));
      setHexDump(hex);

      const attachment: FileAttachment = {
        name: rawFile.name,
        size: rawFile.size,
        type: rawFile.type || (isBase64 ? 'application/octet-stream' : 'text/plain'),
        extension: ext,
        sha256,
        entropy,
        content: textContent,
        isBase64,
        previewSnippet: textContent.slice(0, 1000)
      };

      setCurrentFile(attachment);
      if (onFileSelect) {
        onFileSelect(attachment);
      }
    } catch (err) {
      console.error('File parsing error:', err);
    } finally {
      setProcessing(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  const handleClear = () => {
    setCurrentFile(null);
    setHexDump('');
    setHexViewActive(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          id="hidden-file-input-compact"
          onChange={handleFileInputChange}
          className="hidden"
        />
        <button
          id="compact-upload-trigger-btn"
          type="button"
          onClick={() => fileInputRef.current?.click()}
          title="Upload file for Red/Blue security audit"
          className="p-2 rounded-lg bg-zinc-900 border border-zinc-700/80 text-zinc-300 hover:text-white hover:border-zinc-500 transition-all flex items-center gap-1.5 text-xs font-mono"
        >
          <Upload className="w-3.5 h-3.5 text-rose-400" />
          <span className="hidden sm:inline">Attach File</span>
        </button>

        {currentFile && (
          <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-zinc-900 border border-zinc-700 text-xs font-mono text-zinc-300">
            <span className="truncate max-w-[120px] text-zinc-200">{currentFile.name}</span>
            <span className="text-[10px] text-zinc-500 font-mono">({formatBytes(currentFile.size)})</span>
            <button
              id="clear-file-compact-btn"
              onClick={handleClear}
              className="text-zinc-400 hover:text-rose-400"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        id="hidden-file-input-full"
        onChange={handleFileInputChange}
        className="hidden"
      />

      {!currentFile ? (
        <div
          id="file-drop-zone"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-rose-500 bg-rose-950/20 text-rose-300'
              : 'border-zinc-800 hover:border-zinc-600 bg-zinc-900/40 hover:bg-zinc-900/60'
          }`}
        >
          <div className="flex flex-col items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-zinc-800/80 border border-zinc-700 flex items-center justify-center text-rose-400 shadow-inner">
              {processing ? (
                <Activity className="w-6 h-6 animate-spin text-rose-400" />
              ) : (
                <Upload className="w-6 h-6" />
              )}
            </div>

            <div>
              <p className="text-sm font-semibold text-zinc-200 font-mono">
                {processing ? 'Calculating SHA-256 & Entropy...' : 'Drop any file or click to inspect'}
              </p>
              <p className="text-xs text-zinc-400 mt-1">
                Source code (.py, .ts, .c, .rs, .go, .sol), configs (YAML, Dockerfile), logs (auth.log), PCAP dumps, or binaries
              </p>
            </div>

            <div className="flex items-center gap-4 text-[11px] font-mono text-zinc-500 mt-2">
              <span className="flex items-center gap-1">
                <Fingerprint className="w-3.5 h-3.5 text-zinc-400" /> SHA-256 Hashing
              </span>
              <span className="flex items-center gap-1">
                <Binary className="w-3.5 h-3.5 text-zinc-400" /> Entropy Analysis
              </span>
              <span className="flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 text-zinc-400" /> SAST Taint Inspection
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="border border-zinc-800 rounded-xl bg-zinc-900/90 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-rose-400">
                {currentFile.isBase64 ? <Binary className="w-5 h-5" /> : <FileCode className="w-5 h-5" />}
              </div>
              <div>
                <h4 className="text-sm font-mono font-bold text-zinc-100">{currentFile.name}</h4>
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                  <span>{formatBytes(currentFile.size)}</span>
                  <span>•</span>
                  <span>Format: {currentFile.extension.toUpperCase()}</span>
                  <span>•</span>
                  <span className={currentFile.entropy && currentFile.entropy > 7.0 ? 'text-amber-400 font-semibold' : 'text-emerald-400'}>
                    Entropy: {currentFile.entropy} {currentFile.entropy && currentFile.entropy > 7.0 ? '(High/Packed)' : '(Normal)'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="toggle-hex-view-btn"
                type="button"
                onClick={() => setHexViewActive(!hexViewActive)}
                className="px-2.5 py-1.5 rounded-lg border border-zinc-700 bg-zinc-800 text-xs font-mono text-zinc-300 hover:text-white flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" />
                {hexViewActive ? 'Show Code' : 'Hex Dump'}
              </button>

              {onAuditTrigger && (
                <button
                  id="trigger-sast-audit-btn"
                  type="button"
                  onClick={() => onAuditTrigger(currentFile)}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  Run Ballistic SAST Audit
                </button>
              )}

              <button
                id="clear-file-full-btn"
                type="button"
                onClick={handleClear}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800"
                title="Remove file"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Cryptographic Hash Bar */}
          <div className="bg-zinc-950/80 rounded-lg p-2.5 border border-zinc-800 font-mono text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-zinc-400 truncate">
              <Hash className="w-3.5 h-3.5 text-zinc-500 flex-shrink-0" />
              <span className="text-zinc-500">SHA-256:</span>
              <span className="text-emerald-400 select-all truncate">{currentFile.sha256}</span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono flex-shrink-0">
              Validated in Client Memory
            </span>
          </div>

          {/* Preview Canvas */}
          <div className="bg-zinc-950 rounded-lg border border-zinc-800/80 p-3 overflow-x-auto max-h-72 font-mono text-xs text-zinc-300">
            {hexViewActive ? (
              <pre className="text-emerald-400/90 leading-relaxed select-text">{hexDump}</pre>
            ) : (
              <pre className="text-zinc-300 leading-relaxed select-text whitespace-pre-wrap break-all font-mono">
                {currentFile.content}
              </pre>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
