import React, { useState } from 'react';
import { Building2, ShieldCheck, Lock, Cpu, Server, CheckCircle2, Zap, ArrowRight, Database, Network } from 'lucide-react';

export const EnterpriseUpgradeView: React.FC = () => {
  const [selectedTier, setSelectedTier] = useState<string>('sovereign');
  const [provisionStatus, setProvisionStatus] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleUpgrade = async (tierName: string) => {
    setIsLoading(true);
    setProvisionStatus(null);
    try {
      const res = await fetch('/api/enterprise/provision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tier: tierName })
      });
      const data = await res.json();
      setProvisionStatus(data.message || data.error || 'Provisioning request completed with no fabricated success response.');
    } catch (err: any) {
      setProvisionStatus(err?.message || 'Provisioning request failed. No cluster was provisioned.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 text-amber-500 pointer-events-none">
          <Building2 className="w-48 h-48 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest font-bold">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>ENTERPRISE SOVEREIGN & UNLIMITED TIER UPGRADE</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-mono font-bold text-zinc-100 tracking-tight">
            Enterprise Command Center & Air-Gapped Deployment
          </h1>
          <p className="text-sm text-zinc-400 max-w-3xl leading-relaxed">
            Unlock absolute enterprise capability: dedicated GPU clusters, SAML/OIDC SSO integration, HSM key management, SIEM/SOAR automated webhooks, and unlimited concurrent neural evaluations.
          </p>
        </div>
      </div>

      {/* Tiers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Tier 1 */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-zinc-800 text-zinc-300">STANDARD ENTERPRISE</span>
              <Server className="w-5 h-5 text-zinc-400" />
            </div>
            <div>
              <h2 className="text-xl font-mono font-bold text-zinc-100">Multi-Tenant VPC</h2>
              <p className="text-xs text-zinc-400 mt-1">For growing security teams requiring isolated workspaces.</p>
            </div>
            <ul className="space-y-2 font-mono text-xs text-zinc-300">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> SAML 2.0 / OIDC SSO Integration</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> 50,000 AI Token Requests / Day</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> SIEM Webhook Dispatchers</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> AES-256 Data Encryption</li>
            </ul>
          </div>
          <button
            onClick={() => handleUpgrade('Standard VPC')}
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-mono text-xs font-bold transition-colors"
          >
            Deploy Standard VPC
          </button>
        </div>

        {/* Tier 2 (Highlighted) */}
        <div className="bg-gradient-to-b from-zinc-900 to-amber-950/20 border-2 border-amber-500/50 rounded-2xl p-6 space-y-6 flex flex-col justify-between relative shadow-xl shadow-amber-950/20">
          <div className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-amber-500 text-zinc-950 font-mono text-[10px] font-bold uppercase">
            Most Popular for Fortune 500
          </div>
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-amber-950 text-amber-300 border border-amber-800">SOVEREIGN CLUSTER</span>
              <Cpu className="w-5 h-5 text-amber-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-mono font-bold text-zinc-100">Dedicated Air-Gapped</h2>
              <p className="text-xs text-zinc-400 mt-1">Fully dedicated GPU nodes with absolute zero data retention.</p>
            </div>
            <ul className="space-y-2 font-mono text-xs text-zinc-200">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> Unlimited AI Queries & Evaluations</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> Dedicated H100 / A100 Inference Nodes</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> Hardware Security Module (HSM) KMS</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> 24/7 Dedicated Red/Blue Threat Advisor</li>
            </ul>
          </div>
          <button
            onClick={() => handleUpgrade('Sovereign Air-Gapped Cluster')}
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-mono text-xs font-bold transition-colors shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2"
          >
            <Zap className="w-4 h-4" />
            <span>{isLoading ? 'Provisioning Cluster...' : 'Deploy Sovereign Cluster'}</span>
          </button>
        </div>

        {/* Tier 3 */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-purple-950 text-purple-300 border border-purple-800">CUSTOM ON-PREM</span>
              <Network className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-xl font-mono font-bold text-zinc-100">On-Premises Kubernetes</h2>
              <p className="text-xs text-zinc-400 mt-1">Helm chart deployment for strict internal data centers.</p>
            </div>
            <ul className="space-y-2 font-mono text-xs text-zinc-300">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Kubernetes Operator & Helm Charts</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Custom Model Fine-Tuning Pipelines</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Air-Gapped Offline License Key</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Custom SLA & Engineering Support</li>
            </ul>
          </div>
          <button
            onClick={() => handleUpgrade('On-Premises Helm Operator')}
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold transition-colors"
          >
            Download Helm Operator
          </button>
        </div>
      </div>

      {provisionStatus && (
        <div className="bg-amber-950/30 border border-amber-800/80 rounded-2xl p-6 font-mono text-xs text-amber-200 flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-amber-400 flex-shrink-0" />
          <div>
            <div className="font-bold uppercase tracking-wider text-amber-400">Enterprise Provisioning Status</div>
            <p className="text-zinc-300 mt-0.5">{provisionStatus}</p>
          </div>
        </div>
      )}
    </div>
  );
};
