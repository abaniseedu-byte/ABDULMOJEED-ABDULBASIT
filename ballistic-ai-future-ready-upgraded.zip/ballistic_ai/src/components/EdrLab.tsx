import React, { useState } from 'react';
import { Shield, Cpu, CheckCircle2, Play, Code, AlertTriangle } from 'lucide-react';

export const EdrLab: React.FC = () => {
  const [payloadType, setPayloadType] = useState<string>('Reverse Shell Stager (PowerShell)');
  const [evasionTechnique, setEvasionTechnique] = useState<string>('Direct Syscall Unhooking & AMSI Memory Patching');
  const [testResult, setTestResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRunTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch('/api/edr/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payloadType, evasionTechnique })
      });
      const data = await res.json();
      setTestResult(data);
    } catch (err) {
      console.error('EDR test failed', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-emerald-500 pointer-events-none">
          <Shield className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>EDR EVASION SANDBOX & VIRTUAL PATCHING LAB</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Automated EDR Evasion Testing & WAF Policy Synthesis
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Evaluate payloads against enterprise EDR engines (CrowdStrike Falcon, Microsoft Defender ATP, SentinelOne) and synthesize live eBPF/Istio virtual patches.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            <span>Sandbox Configuration</span>
          </h2>

          <form onSubmit={handleRunTest} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Payload Stager Type</label>
              <input
                type="text"
                value={payloadType}
                onChange={(e) => setPayloadType(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1">Evasion Technique</label>
              <select
                value={evasionTechnique}
                onChange={(e) => setEvasionTechnique(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="Direct Syscall Unhooking & AMSI Memory Patching">Direct Syscall Unhooking & AMSI Memory Patching</option>
                <option value="Process Hollowing & Hollow Process Injection">Process Hollowing & Hollow Process Injection</option>
                <option value="DLL Side-Loading & Indirect Call Obfuscation">DLL Side-Loading & Indirect Call Obfuscation</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-zinc-950 font-mono text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-950/50"
            >
              <Play className="w-4 h-4" />
              <span>{isLoading ? 'Executing Sandbox Test...' : 'Run Real EDR Evasion Analysis'}</span>
            </button>
          </form>
        </div>

        {/* Results */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold text-zinc-200 flex items-center gap-2">
              <Code className="w-4 h-4 text-emerald-400" />
              <span>Detection Status & Virtual Patching</span>
            </h2>

            {testResult ? (
              <div className="space-y-4 font-mono text-xs overflow-y-auto max-h-96">
                <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 space-y-2">
                  <div className="text-[10px] text-zinc-500">EDR Engines Evaluated</div>
                  <div className="flex flex-wrap gap-1">
                    {testResult.edrVendorsTested.map((v: string, i: number) => (
                      <span key={i} className="px-2 py-0.5 rounded text-[10px] bg-zinc-900 text-zinc-300 border border-zinc-800">
                        {v}
                      </span>
                    ))}
                  </div>
                  <div className="text-emerald-400 font-bold pt-1">Status: {testResult.detectionStatus}</div>
                </div>

                <div>
                  <div className="text-[11px] text-zinc-400 mb-1">Generated Istio / eBPF Virtual Patch Policy</div>
                  <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-emerald-300 overflow-x-auto">
                    <pre className="whitespace-pre-wrap">{testResult.virtualPatchGenerated}</pre>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-zinc-500 font-mono text-xs text-center">
                <Shield className="w-10 h-10 mb-2 opacity-30 animate-pulse" />
                <span>Execute EDR evasion analysis to test payload resilience and generate real virtual patches.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
