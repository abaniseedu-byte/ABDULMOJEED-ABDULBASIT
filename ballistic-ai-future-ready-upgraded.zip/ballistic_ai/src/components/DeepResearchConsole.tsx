import React, { useState } from 'react';
import Markdown from 'react-markdown';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { 
  Search, 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  AlertOctagon, 
  FileText, 
  Download, 
  Copy, 
  Check, 
  RefreshCw,
  Terminal,
  ExternalLink,
  ChevronRight,
  Plus,
  Archive
} from 'lucide-react';
import { DeepResearchReport, FileAttachment } from '../types';
import { FileUploader } from './FileUploader';

interface DeepResearchConsoleProps {
  onRunResearch: (query: string, liveSearch: boolean, attachments: FileAttachment[]) => Promise<DeepResearchReport | null>;
  isLoading: boolean;
}

export const DeepResearchConsole: React.FC<DeepResearchConsoleProps> = ({
  onRunResearch,
  isLoading
}) => {
  const [query, setQuery] = useState('');
  const [liveSearch, setLiveSearch] = useState(true);
  const [attachments, setAttachments] = useState<FileAttachment[]>([]);
  const [report, setReport] = useState<DeepResearchReport | null>(null);
  const [activeTab, setActiveTab] = useState<'brief' | 'vectors' | 'detection' | 'roadmap' | 'raw'>('brief');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const sampleResearchQueries = [
    'Deep architectural breakdown of HTTP/2 Rapid Reset (CVE-2023-44487) and stream cancellation amplification',
    'Root cause analysis of memory corruption in Linux eBPF verifier and kernel privilege escalation vectors',
    'Modern Pass-the-Ticket & Kerberoasting attack paths in hybrid Active Directory: SOC detection telemetry',
    'Zero Trust API Gateway: Authentication bypass vectors, BOLA/IDOR patterns, and automated policy enforcement'
  ];

  const handleStartResearch = async (targetQuery?: string) => {
    const q = targetQuery || query;
    if (!q.trim() || isLoading) return;
    setQuery(q);
    const result = await onRunResearch(q, liveSearch, attachments);
    if (result) {
      setReport(result);
      setActiveTab('brief');
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const exportReport = () => {
    if (!report) return;
    const content = `# Ballistic AI Deep Security Research Report
**Query:** ${report.query}
**Timestamp:** ${report.timestamp}

## Executive Summary
${report.executiveSummary}

## Attack Surface Analysis
${report.attackSurfaceAnalysis}

## Threat Vector Matrix
${report.threatVectors.map(v => `### ${v.name} [${v.severity}] (${v.cveOrCwe || 'N/A'})
- **Description:** ${v.description}
- **Offensive Scenario:** ${v.offensiveScenario}
- **Defensive Remediation:** ${v.defensiveRemediation}
`).join('\n')}

## Detection Engineering
\`\`\`yaml
${report.detectionEngineering.sigmaRule || '# No Sigma rule generated'}
\`\`\`

## Remediation Roadmap
${report.remediationRoadmap.map((step, i) => `${i + 1}. ${step}`).join('\n')}
`;

    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deep-research-${report.id}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    if (!report) return;
    const zip = new JSZip();
    let hasCode = false;

    // Save full markdown report
    const content = `# Ballistic AI Deep Security Research Report\n**Query:** ${report.query}\n**Timestamp:** ${report.timestamp}\n\n## Executive Summary\n${report.executiveSummary}\n\n## Attack Surface Analysis\n${report.attackSurfaceAnalysis}\n\n## Threat Vector Matrix\n${report.threatVectors.map(v => `### ${v.name} [${v.severity}] (${v.cveOrCwe || 'N/A'})\n- **Description:** ${v.description}\n- **Offensive Scenario:** ${v.offensiveScenario}\n- **Defensive Remediation:** ${v.defensiveRemediation}\n`).join('\n')}\n\n## Detection Engineering\n\`\`\`yaml\n${report.detectionEngineering.sigmaRule || '# No Sigma rule generated'}\n\`\`\`\n\n## Remediation Roadmap\n${report.remediationRoadmap.map((step, i) => `${i + 1}. ${step}`).join('\n')}\n`;
    zip.file(`advisory-${report.id}.md`, content);
    hasCode = true;

    // Add rules if they exist
    if (report.detectionEngineering.sigmaRule) {
      zip.file(`sigma-rule-${report.id}.yml`, report.detectionEngineering.sigmaRule);
    }
    if (report.detectionEngineering.yaraRule) {
      zip.file(`yara-rule-${report.id}.yar`, report.detectionEngineering.yaraRule);
    }
    if (report.detectionEngineering.splunkQuery) {
      zip.file(`splunk-query-${report.id}.txt`, report.detectionEngineering.splunkQuery);
    }

    // Attempt to extract raw code blocks from full markdown if available
    if (report.fullMarkdown) {
      const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
      let match;
      let fileIndex = 1;
      while ((match = codeBlockRegex.exec(report.fullMarkdown)) !== null) {
        const lang = match[1] || 'txt';
        const code = match[2];
        zip.file(`snippet_${fileIndex}.${lang}`, code);
        fileIndex++;
      }
    }

    if (!hasCode) {
      console.warn("No data available to zip.");
      return;
    }

    const zipContent = await zip.generateAsync({ type: 'blob' });
    saveAs(zipContent, `ballistic-research-${report.id}.zip`);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      
      {/* Research Launch Panel */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-700/60 flex items-center justify-center text-cyan-400 shadow-inner">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
                DEEP THREAT INTELLIGENCE ENGINE
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800">
                  MULTI-STAGE
                </span>
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5 font-mono">
                Automated multi-vector threat modeling, vulnerability root-cause analysis, and detection rule synthesis.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="research-live-search-toggle"
              type="button"
              onClick={() => setLiveSearch(!liveSearch)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono transition-all flex items-center gap-1.5 ${
                liveSearch
                  ? 'bg-blue-950/60 border-blue-500 text-blue-300'
                  : 'bg-zinc-900 border-zinc-700 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              Live CVE Grounding {liveSearch ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        {/* Input & Form */}
        <div className="space-y-3">
          <div className="relative">
            <textarea
              id="deep-research-query-input"
              rows={3}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="State a complex security inquiry, zero-day CVE investigation, cloud architecture threat surface, or attack scenario..."
              className="w-full bg-zinc-950 border border-zinc-800 focus:border-cyan-500 rounded-xl p-4 text-sm font-mono text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 resize-none"
            />
          </div>

          {/* Context File Attachment */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <FileUploader
              compact
              onFileSelect={(file) => setAttachments(prev => [...prev, file])}
            />

            <button
              id="execute-deep-research-btn"
              type="button"
              disabled={isLoading || !query.trim()}
              onClick={() => handleStartResearch()}
              className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white font-mono text-xs font-bold flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>DEEP REASONING IN PROGRESS...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>START DEEP RESEARCH</span>
                </>
              )}
            </button>
          </div>

          {/* Preset Prompts */}
          <div className="pt-2">
            <span className="text-[11px] font-mono text-zinc-500">Benchmark Research Directives:</span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-1.5">
              {sampleResearchQueries.map((sample, idx) => (
                <button
                  key={idx}
                  id={`sample-research-btn-${idx}`}
                  type="button"
                  onClick={() => handleStartResearch(sample)}
                  className="p-2.5 text-left rounded-lg bg-zinc-950/60 hover:bg-zinc-800/80 border border-zinc-800/80 text-xs font-mono text-zinc-400 hover:text-cyan-300 transition-all flex items-center justify-between"
                >
                  <span className="truncate pr-2">{sample}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-zinc-600 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Live Investigation Telemetry while Loading */}
      {isLoading && (
        <div className="border border-cyan-800/50 bg-cyan-950/20 rounded-2xl p-6 text-center space-y-4">
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-12 h-12 rounded-full border-2 border-cyan-500/20 border-t-cyan-400 animate-spin flex items-center justify-center"></div>
              <Sparkles className="w-5 h-5 text-cyan-400 absolute top-3.5 left-3.5 animate-pulse" />
            </div>
          </div>
          <div>
            <h4 className="text-sm font-mono font-bold text-cyan-300">
              Executing Ballistic Multi-Pass Research
            </h4>
            <p className="text-xs text-zinc-400 max-w-md mx-auto mt-1 font-mono">
              Decomposing attack surface → Scanning CVE/CWE databases → Formulating offensive reproduction scenarios → Synthesizing Sigma/YARA rules...
            </p>
          </div>
        </div>
      )}

      {/* Completed Research Report View */}
      {report && !isLoading && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
          
          {/* Report Header Bar */}
          <div className="p-5 bg-zinc-950 border-b border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                  REPORT #{report.id.slice(-6).toUpperCase()}
                </span>
                <span className="text-xs text-zinc-500 font-mono">{report.timestamp}</span>
              </div>
              <h3 className="text-base font-mono font-bold text-zinc-100 mt-1">
                {report.query}
              </h3>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                id="export-zip-btn"
                type="button"
                onClick={handleDownloadZip}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 text-xs font-mono font-medium flex items-center gap-1.5 transition-all self-start sm:self-auto"
              >
                <Archive className="w-3.5 h-3.5" />
                Download Full ZIP
              </button>
              <button
                id="export-research-report-btn"
                type="button"
                onClick={exportReport}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 text-xs font-mono font-medium flex items-center gap-1.5 transition-all self-start sm:self-auto"
              >
                <Download className="w-3.5 h-3.5" />
                Download Advisory (.md)
              </button>
              <button
                id="new-research-btn"
                type="button"
                onClick={() => setReport(null)}
                className="px-3 py-1.5 rounded-lg bg-cyan-900/60 hover:bg-cyan-800 border border-cyan-800/80 text-cyan-200 text-xs font-mono font-medium flex items-center gap-1.5 transition-all self-start sm:self-auto"
              >
                <Plus className="w-3.5 h-3.5" />
                New Research
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 px-4 py-2 border-b border-zinc-800 bg-zinc-950/60 overflow-x-auto">
            <button
              id="report-tab-brief"
              type="button"
              onClick={() => setActiveTab('brief')}
              className={`px-3 py-1.5 rounded-md text-xs font-mono transition-all flex items-center gap-1.5 ${
                activeTab === 'brief'
                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-700 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              Executive Brief
            </button>

            <button
              id="report-tab-vectors"
              type="button"
              onClick={() => setActiveTab('vectors')}
              className={`px-3 py-1.5 rounded-md text-xs font-mono transition-all flex items-center gap-1.5 ${
                activeTab === 'vectors'
                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-700 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <AlertOctagon className="w-3.5 h-3.5 text-rose-400" />
              Threat Vector Matrix ({report.threatVectors.length})
            </button>

            <button
              id="report-tab-detection"
              type="button"
              onClick={() => setActiveTab('detection')}
              className={`px-3 py-1.5 rounded-md text-xs font-mono transition-all flex items-center gap-1.5 ${
                activeTab === 'detection'
                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-700 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Detection Engineering
            </button>

            <button
              id="report-tab-roadmap"
              type="button"
              onClick={() => setActiveTab('roadmap')}
              className={`px-3 py-1.5 rounded-md text-xs font-mono transition-all flex items-center gap-1.5 ${
                activeTab === 'roadmap'
                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-700 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-purple-400" />
              Remediation Roadmap
            </button>
          </div>

          {/* Tab Content Panels */}
          <div className="p-6">
            {activeTab === 'brief' && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider mb-2">
                    Executive Threat Summary
                  </h4>
                  <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-200 text-sm leading-relaxed font-sans">
                    {report.executiveSummary}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider mb-2">
                    Attack Surface Architecture Decomposition
                  </h4>
                  <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-200 text-sm leading-relaxed font-mono whitespace-pre-wrap">
                    {report.attackSurfaceAnalysis}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'vectors' && (
              <div className="space-y-4">
                {report.threatVectors.map((v, i) => (
                  <div key={i} className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          v.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                          v.severity === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                          'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        }`}>
                          {v.severity}
                        </span>
                        <h5 className="text-sm font-mono font-bold text-zinc-100">{v.name}</h5>
                      </div>
                      {v.cveOrCwe && (
                        <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
                          {v.cveOrCwe}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-zinc-300 font-sans leading-relaxed">
                      {v.description}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                      <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-900/40">
                        <span className="text-[11px] font-mono font-bold text-rose-400 block mb-1">
                          🔴 Offensive Verification Scenario:
                        </span>
                        <p className="text-xs text-zinc-300 font-mono leading-relaxed">
                          {v.offensiveScenario}
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-900/40">
                        <span className="text-[11px] font-mono font-bold text-emerald-400 block mb-1">
                          🛡️ Defensive Remediation:
                        </span>
                        <p className="text-xs text-zinc-300 font-mono leading-relaxed">
                          {v.defensiveRemediation}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'detection' && (
              <div className="space-y-6">
                {report.detectionEngineering.sigmaRule && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xs font-mono font-bold text-zinc-300 flex items-center gap-2">
                        <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                        Sigma Detection Rule (YAML)
                      </h4>
                      <button
                        id="copy-sigma-rule-btn"
                        onClick={() => copyToClipboard(report.detectionEngineering.sigmaRule!, 'sigma')}
                        className="text-xs font-mono text-zinc-400 hover:text-zinc-200 flex items-center gap-1"
                      >
                        {copiedKey === 'sigma' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        Copy YAML
                      </button>
                    </div>
                    <pre className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-mono text-emerald-300/90 overflow-x-auto leading-relaxed">
                      {report.detectionEngineering.sigmaRule}
                    </pre>
                  </div>
                )}

                {report.detectionEngineering.yaraRule && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xs font-mono font-bold text-zinc-300 flex items-center gap-2">
                        <Terminal className="w-3.5 h-3.5 text-rose-400" />
                        YARA Malware & Memory Signature
                      </h4>
                      <button
                        id="copy-yara-rule-btn"
                        onClick={() => copyToClipboard(report.detectionEngineering.yaraRule!, 'yara')}
                        className="text-xs font-mono text-zinc-400 hover:text-zinc-200 flex items-center gap-1"
                      >
                        {copiedKey === 'yara' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        Copy YARA
                      </button>
                    </div>
                    <pre className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-mono text-rose-300/90 overflow-x-auto leading-relaxed">
                      {report.detectionEngineering.yaraRule}
                    </pre>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'roadmap' && (
              <div className="space-y-3">
                <h4 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider mb-2">
                  Systemic Security Remediation Sequence
                </h4>
                {report.remediationRoadmap.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3.5 rounded-xl bg-zinc-950 border border-zinc-800">
                    <span className="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-400 text-xs font-mono font-bold flex items-center justify-center flex-shrink-0">
                      {idx + 1}
                    </span>
                    <p className="text-xs font-mono text-zinc-200 leading-relaxed pt-0.5">
                      {item}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
