import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  RefreshCw, 
  ShieldAlert, 
  Search, 
  ExternalLink, 
  Copy, 
  Check, 
  AlertTriangle, 
  ShieldCheck,
  Database,
  Radio,
  KeyRound,
  FileWarning,
  Bug,
  Shield,
  Layers,
  ArrowRight,
  MapPin,
  Server,
  CheckCircle2,
  XCircle,
  Crosshair,
  Network,
  ListFilter,
  Activity
} from 'lucide-react';

type IntelTab = 'directory' | 'kev' | 'cve_lookup' | 'circl' | 'threatfox' | 'urlhaus' | 'hibp' | 'ipapi' | 'otx';

export const ThreatIntelFeed: React.FC = () => {
  const [activeTab, setActiveTab] = useState<IntelTab>('directory');
  
  // Tab 1: CISA KEV
  const [feed, setFeed] = useState<any[]>([]);
  const [isLoadingKev, setIsLoadingKev] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<'all' | 'ransomware' | 'critical' | 'high'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [liveSource, setLiveSource] = useState<string>('CISA Known Exploited Vulnerabilities Catalog');

  // Tab 2: NIST NVD Deep CVE Lookup
  const [cveQuery, setCveQuery] = useState<string>('CVE-2024-3400');
  const [cveLoading, setCveLoading] = useState<boolean>(false);
  const [cveResult, setCveResult] = useState<any>(null);
  const [cveError, setCveError] = useState<string | null>(null);

  // Tab 3: CIRCL CVE Search
  const [circlQuery, setCirclQuery] = useState<string>('CVE-2023-4863');
  const [circlLoading, setCirclLoading] = useState<boolean>(false);
  const [circlResult, setCirclResult] = useState<any>(null);
  const [circlError, setCirclError] = useState<string | null>(null);

  // Tab 4: abuse.ch ThreatFox IOC Search
  const [tfQuery, setTfQuery] = useState<string>('Cobalt Strike');
  const [tfLoading, setTfLoading] = useState<boolean>(false);
  const [tfResult, setTfResult] = useState<any>(null);
  const [tfError, setTfError] = useState<string | null>(null);

  // Tab 5: abuse.ch URLhaus Host / Payload Search
  const [uhQuery, setUhQuery] = useState<string>('');
  const [uhLoading, setUhLoading] = useState<boolean>(false);
  const [uhResult, setUhResult] = useState<any>(null);
  const [uhError, setUhError] = useState<string | null>(null);

  // Tab 6: HIBP k-Anonymity Credential Check
  const [passwordQuery, setPasswordQuery] = useState<string>('');
  const [hibpLoading, setHibpLoading] = useState<boolean>(false);
  const [hibpResult, setHibpResult] = useState<any>(null);
  const [hibpError, setHibpError] = useState<string | null>(null);

  // Tab 7: IP-API.com Geolocation & ASN
  const [ipQuery, setIpQuery] = useState<string>('8.8.8.8');
  const [ipLoading, setIpLoading] = useState<boolean>(false);
  const [ipResult, setIpResult] = useState<any>(null);
  const [ipError, setIpError] = useState<string | null>(null);

  // Tab 8: AlienVault OTX Pulses
  const [otxQuery, setOtxQuery] = useState<string>('google.com');
  const [otxType, setOtxType] = useState<string>('domain');
  const [otxLoading, setOtxLoading] = useState<boolean>(false);
  const [otxResult, setOtxResult] = useState<any>(null);
  const [otxError, setOtxError] = useState<string | null>(null);

  // Tab 0: Free Cloud APIs Directory
  const [dirApis, setDirApis] = useState<any[]>([]);
  const [dirLoading, setDirLoading] = useState<boolean>(false);

  useEffect(() => {
    fetchFeed();
    fetchDirectory();
  }, []);

  const fetchFeed = async () => {
    setIsLoadingKev(true);
    try {
      const res = await fetch('/api/intel/feed');
      const data = await res.json();
      if (data.feed) {
        setFeed(data.feed);
      }
      if (data.liveSource) {
        setLiveSource(data.liveSource);
      }
    } catch (err) {
      console.error('Failed to fetch threat intel feed', err);
    } finally {
      setIsLoadingKev(false);
    }
  };

  const handleCveLookup = async (idToLookup?: string) => {
    const id = (idToLookup || cveQuery).trim().toUpperCase();
    if (!id || !id.startsWith('CVE-')) {
      setCveError('Please enter a valid CVE ID (e.g. CVE-2024-3400)');
      return;
    }
    setCveLoading(true);
    setCveError(null);
    setCveResult(null);

    try {
      const res = await fetch(`/api/intel/cve/${encodeURIComponent(id)}`);
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'CVE lookup failed');
      }
      setCveResult(data);
    } catch (err: any) {
      setCveError(err.message || 'Error querying NIST/CIRCL CVE databases');
    } finally {
      setCveLoading(false);
    }
  };

  const handleThreatFoxSearch = async (term?: string) => {
    const query = (term || tfQuery).trim();
    if (!query) return;
    setTfLoading(true);
    setTfError(null);
    setTfResult(null);

    try {
      const res = await fetch('/api/intel/threatfox', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ searchTerm: query })
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'ThreatFox query error');
      }
      setTfResult(data);
    } catch (err: any) {
      setTfError(err.message || 'Error communicating with abuse.ch ThreatFox');
    } finally {
      setTfLoading(false);
    }
  };

  const handleUrlhausSearch = async (host?: string) => {
    const targetHost = (host !== undefined ? host : uhQuery).trim();
    setUhLoading(true);
    setUhError(null);
    setUhResult(null);

    try {
      const res = await fetch('/api/intel/urlhaus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(targetHost ? { host: targetHost } : {})
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'URLhaus query error');
      }
      setUhResult(data);
    } catch (err: any) {
      setUhError(err.message || 'Error communicating with abuse.ch URLhaus');
    } finally {
      setUhLoading(false);
    }
  };

  const handleHibpCheck = async () => {
    if (!passwordQuery) {
      setHibpError('Please enter a password string to test k-Anonymity privacy verification');
      return;
    }
    setHibpLoading(true);
    setHibpError(null);
    setHibpResult(null);

    try {
      const res = await fetch('/api/intel/hibp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: passwordQuery })
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'HIBP lookup failed');
      }
      setHibpResult(data);
    } catch (err: any) {
      setHibpError(err.message || 'Error checking Have I Been Pwned');
    } finally {
      setHibpLoading(false);
    }
  };

  const handleIpLookup = async (targetIp?: string) => {
    const ip = (targetIp || ipQuery).trim();
    if (!ip) return;
    setIpLoading(true);
    setIpError(null);
    setIpResult(null);
    try {
      const res = await fetch('/api/intel/ip-api', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip })
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'IP-API lookup failed');
      }
      setIpResult(data.data);
    } catch (err: any) {
      setIpError(err.message || 'Error querying IP-API.com');
    } finally {
      setIpLoading(false);
    }
  };

  const handleOtxLookup = async (indicatorVal?: string, indType?: string) => {
    const ind = (indicatorVal || otxQuery).trim();
    if (!ind) return;
    setOtxLoading(true);
    setOtxError(null);
    setOtxResult(null);
    try {
      const res = await fetch('/api/intel/otx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ indicator: ind, type: indType || otxType })
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'AlienVault OTX query failed');
      }
      setOtxResult(data);
    } catch (err: any) {
      setOtxError(err.message || 'Error querying AlienVault OTX');
    } finally {
      setOtxLoading(false);
    }
  };

  const handleCirclLookup = async (cve?: string) => {
    const cveId = (cve || circlQuery).trim().toUpperCase();
    if (!cveId || !cveId.startsWith('CVE-')) {
      setCirclError('Please enter a valid CVE ID (e.g. CVE-2023-4863)');
      return;
    }
    setCirclLoading(true);
    setCirclError(null);
    setCirclResult(null);
    try {
      const res = await fetch(`/api/intel/circl/${encodeURIComponent(cveId)}`);
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'CIRCL CVE lookup failed');
      }
      setCirclResult(data);
    } catch (err: any) {
      setCirclError(err.message || 'Error querying CIRCL CVE Search API');
    } finally {
      setCirclLoading(false);
    }
  };

  const fetchDirectory = async () => {
    setDirLoading(true);
    try {
      const res = await fetch('/api/intel/free-apis-directory');
      const data = await res.json();
      if (data.apis) {
        setDirApis(data.apis);
      }
    } catch (err) {
      console.error('Failed to fetch APIs directory', err);
    } finally {
      setDirLoading(false);
    }
  };

  const copyText = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredFeed = feed.filter(item => {
    const matchesSearch = 
      item.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.vendor?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.product?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.indicator?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.type?.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (filterType === 'ransomware') {
      return item.ransomwareUse === 'Known';
    }
    if (filterType === 'critical') {
      return item.severity === 'CRITICAL';
    }
    if (filterType === 'high') {
      return item.severity === 'HIGH';
    }
    return true;
  });

  const ransomwareCount = feed.filter(i => i.ransomwareUse === 'Known').length;
  const criticalCount = feed.filter(i => i.severity === 'CRITICAL').length;

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-blue-500 pointer-events-none">
          <Globe className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded bg-blue-950/80 border border-blue-600 text-blue-300 font-mono text-[11px] font-semibold flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              GLOBAL DEFENSIVE THREAT RADAR
            </span>
            <span className="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-600 text-emerald-300 font-mono text-[11px] font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              10 FREE-FOR-LIFE CLOUD APIs (NO PAYMENT REQUIRED)
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Threat Intelligence & Cloud Security Radar
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-3xl leading-relaxed font-mono">
            Direct real-time connections to 10 free-for-life cybersecurity APIs: NIST NVD 2.0, CISA KEV, abuse.ch URLhaus & ThreatFox, HIBP k-Anonymity, crt.sh CT Logs, Cloudflare DoH, IP-API.com Geolocation, AlienVault OTX Pulses, and CIRCL CVE Search.
          </p>

          {/* Navigation Sub-Tabs */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-zinc-800/80">
            <button
              onClick={() => setActiveTab('directory')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'directory'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Free Cloud APIs Hub (10/10)
            </button>
            <button
              onClick={() => setActiveTab('kev')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'kev'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              CISA KEV ({feed.length})
            </button>
            <button
              onClick={() => setActiveTab('cve_lookup')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'cve_lookup'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              NIST NVD 2.0
            </button>
            <button
              onClick={() => setActiveTab('circl')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'circl'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              CIRCL CVE & CPE
            </button>
            <button
              onClick={() => setActiveTab('threatfox')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'threatfox'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              ThreatFox IOCs
            </button>
            <button
              onClick={() => setActiveTab('urlhaus')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'urlhaus'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <FileWarning className="w-3.5 h-3.5" />
              URLhaus Malware
            </button>
            <button
              onClick={() => setActiveTab('hibp')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'hibp'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              HIBP Passwords
            </button>
            <button
              onClick={() => setActiveTab('ipapi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'ipapi'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              IP-API Geolocation & ASN
            </button>
            <button
              onClick={() => setActiveTab('otx')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'otx'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Crosshair className="w-3.5 h-3.5" />
              AlienVault OTX Pulses
            </button>
          </div>
        </div>
      </div>

      {/* TAB 0: FREE-FOR-LIFE 10 CLOUD SECURITY APIS DIRECTORY */}
      {activeTab === 'directory' && (
        <div className="space-y-6">
          {/* Summary Matrix Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono">
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
              <div className="text-[10px] text-zinc-500 uppercase font-semibold">Total Cloud APIs</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                10 / 10 Active
              </div>
              <div className="text-[11px] text-zinc-400 mt-1">100% Real, Zero Simulation</div>
            </div>

            <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
              <div className="text-[10px] text-zinc-500 uppercase font-semibold">Cost / Financial Barrier</div>
              <div className="text-2xl font-bold text-cyan-400 mt-1">$0.00 / Life</div>
              <div className="text-[11px] text-zinc-400 mt-1">No money, credit card, or paywall</div>
            </div>

            <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
              <div className="text-[10px] text-zinc-500 uppercase font-semibold">Key Requirement</div>
              <div className="text-2xl font-bold text-blue-400 mt-1">No Key Req.</div>
              <div className="text-[11px] text-zinc-400 mt-1">Open public REST & JSON endpoints</div>
            </div>

            <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
              <div className="text-[10px] text-zinc-500 uppercase font-semibold">Coverage Depth</div>
              <div className="text-2xl font-bold text-purple-400 mt-1">Full-Spectrum</div>
              <div className="text-[11px] text-zinc-400 mt-1">Vulns, Malware, CT, DNS, Geolocation</div>
            </div>
          </div>

          {/* Directory Grid */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-4 font-mono">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
              <div>
                <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  Free-For-Life Cloud Security APIs Directory
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Authoritative public security data sources operating with perpetual open tiers and zero payment requirements.
                </p>
              </div>
              <button
                onClick={fetchDirectory}
                disabled={dirLoading}
                className="px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 text-xs flex items-center gap-1.5 self-start sm:self-auto"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${dirLoading ? 'animate-spin text-emerald-400' : ''}`} />
                <span>Refresh Matrix</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  num: 1,
                  name: 'NIST National Vulnerability Database (NVD)',
                  badge: 'Free (No key needed)',
                  useCase: 'Real CVE definitions, CVSS v3/v4 metrics, and affected software configurations.',
                  endpoint: 'https://services.nvd.nist.gov/rest/json/cves/2.0',
                  actionTab: 'cve_lookup' as IntelTab,
                  buttonText: 'Query NIST NVD',
                  color: 'border-blue-800/80 bg-blue-950/20'
                },
                {
                  num: 2,
                  name: 'CISA Known Exploited Vulnerabilities (KEV)',
                  badge: 'Completely Free / Open (No key)',
                  useCase: 'Authoritative feed of vulnerabilities actively weaponized in the wild with remediation deadlines.',
                  endpoint: 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json',
                  actionTab: 'kev' as IntelTab,
                  buttonText: 'Inspect CISA KEV',
                  color: 'border-emerald-800/80 bg-emerald-950/20'
                },
                {
                  num: 3,
                  name: 'abuse.ch URLhaus API',
                  badge: 'Completely Free / Open (No key)',
                  useCase: 'Verified malicious URLs, malware distribution sites, and active payload delivery links.',
                  endpoint: 'https://urlhaus-api.abuse.ch/v1/',
                  actionTab: 'urlhaus' as IntelTab,
                  buttonText: 'Search URLhaus Drops',
                  color: 'border-amber-800/80 bg-amber-950/20'
                },
                {
                  num: 4,
                  name: 'abuse.ch ThreatFox API',
                  badge: 'Completely Free / Open (No key)',
                  useCase: 'Community IOCs (Indicators of Compromise): C2 IP addresses, botnet domains, and payload hashes.',
                  endpoint: 'https://threatfox-api.abuse.ch/v1/',
                  actionTab: 'threatfox' as IntelTab,
                  buttonText: 'Search ThreatFox IOCs',
                  color: 'border-purple-800/80 bg-purple-950/20'
                },
                {
                  num: 5,
                  name: 'HIBP Pwned Passwords (k-Anonymity)',
                  badge: 'Completely Free / Unlimited (No key)',
                  useCase: 'Defensive credential audits using 5-character SHA-1 hash prefixes without leaking credentials.',
                  endpoint: 'https://api.pwnedpasswords.com/range/{hash_prefix}',
                  actionTab: 'hibp' as IntelTab,
                  buttonText: 'Verify Password Hashes',
                  color: 'border-fuchsia-800/80 bg-fuchsia-950/20'
                },
                {
                  num: 6,
                  name: 'crt.sh (Certificate Transparency Logs)',
                  badge: 'Completely Free / Open (No key)',
                  useCase: 'Real-time querying of public SSL/TLS certificate transparency logs for domain auditing & subdomains.',
                  endpoint: 'https://crt.sh/?q=%.domain.com&output=json',
                  actionTab: null,
                  networkLink: true,
                  buttonText: 'Open in Network Inspector',
                  color: 'border-cyan-800/80 bg-cyan-950/20'
                },
                {
                  num: 7,
                  name: 'Cloudflare DNS-over-HTTPS (DoH) JSON API',
                  badge: 'Completely Free / Open (No key)',
                  useCase: 'Fast, encrypted DNS resolution and record verification (A, AAAA, MX, TXT, SPF, DKIM) via HTTP.',
                  endpoint: 'https://cloudflare-dns.com/dns-query?name=example.com&type=A',
                  actionTab: null,
                  networkLink: true,
                  buttonText: 'Open in Network Inspector',
                  color: 'border-teal-800/80 bg-teal-950/20'
                },
                {
                  num: 8,
                  name: 'IP-API.com Geolocation & ASN',
                  badge: 'Free Tier (45 req/min, no key)',
                  useCase: 'Autonomous System Numbers (ASN), ISP, hosting provider, and IP geolocation metadata.',
                  endpoint: 'http://ip-api.com/json/{ip}',
                  actionTab: 'ipapi' as IntelTab,
                  buttonText: 'Inspect IP Geolocation',
                  color: 'border-indigo-800/80 bg-indigo-950/20'
                },
                {
                  num: 9,
                  name: 'AlienVault OTX (Open Threat Exchange)',
                  badge: 'Perpetual Free Tier (Key optional)',
                  useCase: 'Global crowdsourced threat intelligence pulses, IP reputation checks, and adversary tracking.',
                  endpoint: 'https://otx.alienvault.com/api/v1/',
                  actionTab: 'otx' as IntelTab,
                  buttonText: 'Query OTX Pulses',
                  color: 'border-rose-800/80 bg-rose-950/20'
                },
                {
                  num: 10,
                  name: 'CIRCL CVE Search API',
                  badge: 'Free Public Service (20 req/min)',
                  useCase: 'Direct lookup of CVE identifiers, CPE software fingerprints, CAPEC mappings, and vendor advisories.',
                  endpoint: 'https://cve.circl.lu/api/',
                  actionTab: 'circl' as IntelTab,
                  buttonText: 'Search CIRCL CVE',
                  color: 'border-emerald-800/80 bg-emerald-950/20'
                }
              ].map((api) => (
                <div
                  key={api.num}
                  className={`border rounded-xl p-4.5 space-y-3 relative flex flex-col justify-between transition-all hover:border-zinc-700 ${api.color}`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 flex items-center justify-center shrink-0">
                          {api.num}
                        </span>
                        <h3 className="text-xs font-bold text-zinc-100">{api.name}</h3>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-zinc-950 border border-zinc-800 text-emerald-400 shrink-0">
                        {api.badge}
                      </span>
                    </div>

                    <p className="text-[11px] text-zinc-400 leading-relaxed">
                      {api.useCase}
                    </p>

                    <div className="text-[10px] text-zinc-500 bg-zinc-950/80 p-2 rounded border border-zinc-800/80 break-all flex items-center justify-between gap-2">
                      <span className="truncate">{api.endpoint}</span>
                      <a
                        href={api.endpoint.split('?')[0]}
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 shrink-0"
                        title="Open Official Docs / Endpoint"
                      >
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-zinc-800/60 flex items-center justify-between gap-2">
                    <span className="text-[10px] text-zinc-500 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      Status: Active
                    </span>
                    {api.actionTab ? (
                      <button
                        onClick={() => setActiveTab(api.actionTab!)}
                        className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all"
                      >
                        <span>{api.buttonText}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    ) : (
                      <a
                        href="#network"
                        onClick={() => {
                          // Allow user to jump to network inspector if desired
                          const navBtn = document.querySelector('button[title*="Network"], button:has(svg.lucide-activity)');
                          if (navBtn instanceof HTMLButtonElement) navBtn.click();
                        }}
                        className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all"
                      >
                        <span>{api.buttonText}</span>
                        <ArrowRight className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: CISA KEV CATALOG */}
      {activeTab === 'kev' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-zinc-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search CVE ID, vendor, product, or keywords..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-10 pr-4 py-2 text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex bg-zinc-950 border border-zinc-800 rounded-xl p-1 text-xs font-mono">
                <button
                  onClick={() => setFilterType('all')}
                  className={`px-3 py-1.5 rounded-lg transition-colors ${filterType === 'all' ? 'bg-zinc-800 text-zinc-100 font-semibold' : 'text-zinc-400 hover:text-zinc-200'}`}
                >
                  All ({feed.length})
                </button>
                <button
                  onClick={() => setFilterType('ransomware')}
                  className={`px-3 py-1.5 rounded-lg transition-colors ${filterType === 'ransomware' ? 'bg-rose-950/80 text-rose-300 font-semibold border border-rose-800/60' : 'text-zinc-400 hover:text-rose-300'}`}
                >
                  Ransomware ({ransomwareCount})
                </button>
                <button
                  onClick={() => setFilterType('critical')}
                  className={`px-3 py-1.5 rounded-lg transition-colors ${filterType === 'critical' ? 'bg-amber-950/80 text-amber-300 font-semibold border border-amber-800/60' : 'text-zinc-400 hover:text-amber-300'}`}
                >
                  Critical ({criticalCount})
                </button>
              </div>

              <button
                onClick={fetchFeed}
                disabled={isLoadingKev}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-semibold flex items-center gap-2 transition-colors shadow-md disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingKev ? 'animate-spin' : ''}`} />
                <span>{isLoadingKev ? 'Syncing...' : 'Sync Live KEV'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-3.5">
            {filteredFeed.length === 0 ? (
              <div className="text-center py-12 text-zinc-500 font-mono text-xs">
                No exploited vulnerabilities match the current filter or search criteria.
              </div>
            ) : (
              filteredFeed.map((item) => (
                <div
                  key={item.id}
                  className="bg-zinc-950 border border-zinc-800/90 hover:border-zinc-700 p-4 sm:p-5 rounded-xl flex flex-col gap-3 font-mono text-xs transition-all shadow-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-sm text-zinc-100 flex items-center gap-1.5">
                        {item.id}
                        <button
                          onClick={(e) => copyText(item.id, item.id, e)}
                          title="Copy CVE ID"
                          className="text-zinc-500 hover:text-zinc-300 transition-colors"
                        >
                          {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </span>

                      {item.vendor && (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-zinc-800/80 text-zinc-300 border border-zinc-700">
                          {item.vendor} {item.product ? `• ${item.product}` : ''}
                        </span>
                      )}

                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                        item.severity === 'CRITICAL'
                          ? 'bg-rose-950/80 text-rose-300 border-rose-800'
                          : 'bg-amber-950/80 text-amber-300 border-amber-800'
                      }`}>
                        {item.severity || 'HIGH'}
                      </span>

                      {item.ransomwareUse === 'Known' && (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-rose-950 text-rose-300 border border-rose-600 font-bold uppercase flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-rose-400" />
                          RANSOMWARE WEAPONIZED
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => {
                          setCveQuery(item.id);
                          setActiveTab('cve_lookup');
                          handleCveLookup(item.id);
                        }}
                        className="text-xs text-blue-400 hover:text-blue-300 underline font-mono flex items-center gap-1"
                      >
                        Deep NVD Audit <ArrowRight className="w-3 h-3" />
                      </button>
                      <a
                        href={`https://nvd.nist.gov/vuln/detail/${item.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200"
                      >
                        <span>NVD</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  <div className="text-zinc-200 text-xs leading-relaxed">
                    {item.indicator || item.type}
                  </div>

                  {item.requiredAction && (
                    <div className="bg-zinc-900/80 border border-zinc-800 rounded-lg p-3 text-xs space-y-1">
                      <div className="text-emerald-400 font-semibold flex items-center gap-1.5 text-[11px]">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        CISA Mandated Action:
                      </div>
                      <div className="text-zinc-300 text-[11px] leading-relaxed">
                        {item.requiredAction}
                      </div>
                      {item.dueDate && (
                        <div className="text-zinc-500 text-[10px] pt-1">
                          Federal Civilian Agency Due Date: <span className="text-amber-400">{item.dueDate}</span>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="text-zinc-500 text-[10px] flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-zinc-900">
                    <span>Source: {item.source}</span>
                    <span>Date Added to KEV: {item.dateAdded || item.timestamp}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 2: NIST NVD 2.0 CVE DEEP LOOKUP */}
      {activeTab === 'cve_lookup' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6">
          <div className="space-y-2">
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-400" />
              NIST National Vulnerability Database (NVD 2.0) & CIRCL Direct Query
            </h2>
            <p className="text-xs text-zinc-400 font-mono">
              Live queries NIST official REST API v2.0 for precise CVSS v3.1 base score, vector strings, CWE classifications, and cross-checks with CISA KEV catalog.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={cveQuery}
                onChange={(e) => setCveQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCveLookup()}
                placeholder="e.g. CVE-2024-3400, CVE-2023-4966, CVE-2021-44228..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-blue-500 uppercase"
              />
            </div>
            <button
              onClick={() => handleCveLookup()}
              disabled={cveLoading}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${cveLoading ? 'animate-spin' : ''}`} />
              <span>{cveLoading ? 'Querying NVD...' : 'Lookup CVE'}</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-mono">
            <span className="text-zinc-500 text-[11px] self-center">Popular CVEs:</span>
            {['CVE-2024-3400', 'CVE-2024-4577', 'CVE-2023-4966', 'CVE-2021-44228', 'CVE-2024-21887'].map((cve) => (
              <button
                key={cve}
                onClick={() => {
                  setCveQuery(cve);
                  handleCveLookup(cve);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-blue-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                {cve}
              </button>
            ))}
          </div>

          {cveError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs font-mono text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{cveError}</span>
            </div>
          )}

          {cveResult && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-5 font-mono">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-zinc-800">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold text-zinc-100">{cveResult.cveId}</span>
                    <span className={`px-2.5 py-0.5 rounded text-[11px] font-bold uppercase border ${
                      cveResult.cvss?.severity === 'CRITICAL'
                        ? 'bg-rose-950 text-rose-300 border-rose-700'
                        : 'bg-amber-950 text-amber-300 border-amber-700'
                    }`}>
                      {cveResult.cvss?.severity || 'HIGH'} ({cveResult.cvss?.score || 'N/A'})
                    </span>
                  </div>
                  <div className="text-[11px] text-zinc-500">
                    Source: {cveResult.source} • Published: {cveResult.published || 'N/A'}
                  </div>
                </div>

                {cveResult.cisaKev?.inCatalog ? (
                  <div className="px-3 py-1.5 rounded-lg bg-rose-950/80 border border-rose-600 text-rose-300 text-xs font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    ACTIVELY EXPLOITED IN CISA KEV
                  </div>
                ) : (
                  <div className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-zinc-500" />
                    Not Flagged in CISA KEV
                  </div>
                )}
              </div>

              {/* CVSS Metric Vector */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">CVSS Base Score</div>
                  <div className="text-2xl font-bold text-zinc-100 mt-0.5">{cveResult.cvss?.score}</div>
                </div>
                <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-lg sm:col-span-2">
                  <div className="text-[10px] text-zinc-500 uppercase">CVSS v3.1 Vector String</div>
                  <div className="text-xs font-bold text-blue-400 mt-1 break-all">{cveResult.cvss?.vector}</div>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <div className="text-[11px] text-zinc-400 font-bold uppercase">Official Vulnerability Summary</div>
                <p className="text-xs text-zinc-200 leading-relaxed bg-zinc-900/50 p-3 rounded-lg border border-zinc-800/80">
                  {cveResult.description}
                </p>
              </div>

              {/* Weaknesses */}
              {cveResult.weaknesses?.length > 0 && (
                <div className="space-y-1.5">
                  <div className="text-[11px] text-zinc-400 font-bold uppercase">Weakness Enumeration (CWE)</div>
                  <div className="flex flex-wrap gap-2">
                    {cveResult.weaknesses.map((w: string, idx: number) => (
                      <span key={idx} className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs">
                        {w}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* CISA Required Action */}
              {cveResult.cisaKev?.inCatalog && cveResult.cisaKev?.requiredAction && (
                <div className="p-3.5 bg-emerald-950/40 border border-emerald-800/80 rounded-lg space-y-1">
                  <div className="text-emerald-400 font-bold text-xs flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" /> CISA Mandated Remediation Action:
                  </div>
                  <div className="text-zinc-200 text-xs">{cveResult.cisaKev.requiredAction}</div>
                  {cveResult.cisaKev.dueDate && (
                    <div className="text-[10px] text-amber-400 pt-1">Due Date: {cveResult.cisaKev.dueDate}</div>
                  )}
                </div>
              )}

              {/* References */}
              {cveResult.references?.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-zinc-900">
                  <div className="text-[11px] text-zinc-400 font-bold uppercase">Authoritative References & Advisories</div>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {cveResult.references.map((ref: string, idx: number) => (
                      <a
                        key={idx}
                        href={ref}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-xs text-blue-400 hover:underline truncate"
                      >
                        {ref}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: THREATFOX IOC SEARCH */}
      {activeTab === 'threatfox' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6">
          <div className="space-y-2">
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400" />
              abuse.ch ThreatFox Community Threat Indicators (IOCs)
            </h2>
            <p className="text-xs text-zinc-400 font-mono">
              Live queries the open ThreatFox platform by the Bern University of Applied Sciences & abuse.ch for verified Indicators of Compromise (C2 IP addresses, botnet domains, malware hashes).
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={tfQuery}
                onChange={(e) => setTfQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleThreatFoxSearch()}
                placeholder="Search malware family (e.g. Cobalt Strike, RedLine, AsyncRAT), IP, or SHA256..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-blue-500"
              />
            </div>
            <button
              onClick={() => handleThreatFoxSearch()}
              disabled={tfLoading}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <Search className={`w-3.5 h-3.5 ${tfLoading ? 'animate-spin' : ''}`} />
              <span>{tfLoading ? 'Querying ThreatFox...' : 'Search IOCs'}</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-mono">
            <span className="text-zinc-500 text-[11px] self-center">Popular Indicators:</span>
            {['Cobalt Strike', 'AsyncRAT', 'RedLineStealer', 'QakBot', 'LokiBot'].map((term) => (
              <button
                key={term}
                onClick={() => {
                  setTfQuery(term);
                  handleThreatFoxSearch(term);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-emerald-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                {term}
              </button>
            ))}
          </div>

          {tfError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs font-mono text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{tfError}</span>
            </div>
          )}

          {tfResult && (
            <div className="space-y-3 font-mono">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>Total Matches: <strong className="text-zinc-100">{tfResult.count}</strong></span>
                <span>Status: {tfResult.queryStatus}</span>
              </div>

              {tfResult.data?.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 text-xs bg-zinc-950 border border-zinc-800 rounded-xl">
                  No active threat indicators returned for &quot;{tfQuery}&quot;.
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                  {tfResult.data.map((ioc: any, idx: number) => (
                    <div key={idx} className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl text-xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-zinc-100 text-sm">{ioc.ioc_value}</span>
                          <button
                            onClick={(e) => copyText(ioc.ioc_value, `ioc-${idx}`, e)}
                            className="text-zinc-500 hover:text-zinc-300"
                          >
                            {copiedId === `ioc-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-950 text-rose-300 border border-rose-800">
                          {ioc.threat_type_desc || ioc.threat_type || 'Threat IOC'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-zinc-400 bg-zinc-900/60 p-2.5 rounded-lg">
                        <div>Malware: <span className="text-emerald-400 font-bold">{ioc.malware_printable || 'Unknown'}</span></div>
                        <div>Type: <span className="text-zinc-200">{ioc.ioc_type}</span></div>
                        <div>Confidence: <span className="text-amber-400">{ioc.confidence_level}%</span></div>
                        <div>Reported: <span className="text-zinc-300">{ioc.first_seen?.split(' ')[0] || 'Recent'}</span></div>
                      </div>

                      {ioc.tags && ioc.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {ioc.tags.map((t: string, tIdx: number) => (
                            <span key={tIdx} className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-400">
                              #{t}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: URLHAUS MALWARE SITES */}
      {activeTab === 'urlhaus' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6">
          <div className="space-y-2">
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              <FileWarning className="w-4 h-4 text-amber-400" />
              abuse.ch URLhaus Real-Time Malware Distribution Telemetry
            </h2>
            <p className="text-xs text-zinc-400 font-mono">
              Live tracking of malicious websites being used for malware distribution and weaponized payload delivery.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={uhQuery}
                onChange={(e) => setUhQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleUrlhausSearch()}
                placeholder="Enter host to inspect (or leave blank to fetch latest active malware URLs)..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-blue-500"
              />
            </div>
            <button
              onClick={() => handleUrlhausSearch()}
              disabled={uhLoading}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-mono text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${uhLoading ? 'animate-spin' : ''}`} />
              <span>{uhLoading ? 'Querying URLhaus...' : uhQuery.trim() ? 'Lookup Host' : 'Fetch Recent Drops'}</span>
            </button>
          </div>

          {uhError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs font-mono text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{uhError}</span>
            </div>
          )}

          {uhResult && (
            <div className="space-y-3 font-mono">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>URLs Returned: <strong className="text-zinc-100">{uhResult.count}</strong></span>
                <span>Source: {uhResult.source}</span>
              </div>

              {uhResult.urls?.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 text-xs bg-zinc-950 border border-zinc-800 rounded-xl">
                  No active malicious distribution URLs found for this query.
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                  {uhResult.urls.map((u: any, idx: number) => (
                    <div key={idx} className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl text-xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-bold text-zinc-100 break-all">{u.url}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                          u.url_status === 'online'
                            ? 'bg-rose-950 text-rose-300 border-rose-800'
                            : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                        }`}>
                          {u.url_status || 'offline'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-zinc-400 bg-zinc-900/60 p-2.5 rounded-lg">
                        <div>Threat: <span className="text-rose-400 font-bold">{u.threat || 'Malware payload'}</span></div>
                        <div>Date Added: <span className="text-zinc-200">{u.dateadded?.split(' ')[0]}</span></div>
                        <div>Reporter: <span className="text-zinc-300">{u.reporter || 'Community'}</span></div>
                      </div>

                      {u.tags && u.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {u.tags.map((tag: string, tIdx: number) => (
                            <span key={tIdx} className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] text-amber-300">
                              #{tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: HIBP K-ANONYMITY PASSWORD CHECK */}
      {activeTab === 'hibp' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6">
          <div className="space-y-2">
            <h2 className="text-base font-mono font-bold text-zinc-100 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-purple-400" />
              Have I Been Pwned (HIBP) k-Anonymity Credential Verifier
            </h2>
            <p className="text-xs text-zinc-400 font-mono">
              Audits password strength against hundreds of millions of exposed real-world credentials. Employs Troy Hunt&apos;s mathematical k-Anonymity model (only the 5-character SHA-1 prefix is ever queried, strictly preserving password secrecy).
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={passwordQuery}
                onChange={(e) => setPasswordQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleHibpCheck()}
                placeholder="Enter password or string to check compromise status..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-purple-500"
              />
            </div>
            <button
              onClick={handleHibpCheck}
              disabled={hibpLoading}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <Shield className={`w-3.5 h-3.5 ${hibpLoading ? 'animate-spin' : ''}`} />
              <span>{hibpLoading ? 'Verifying Hash...' : 'Audit Credential'}</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-mono">
            <span className="text-zinc-500 text-[11px] self-center">Test Examples:</span>
            {['password123', 'admin2024!', 'CorrectHorseBatteryStaple99$', 'P@ssw0rd12345'].map((p) => (
              <button
                key={p}
                onClick={() => {
                  setPasswordQuery(p);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-purple-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                {p}
              </button>
            ))}
          </div>

          {hibpError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs font-mono text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{hibpError}</span>
            </div>
          )}

          {hibpResult && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4 font-mono">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-400">Anonymized Hash Range:</span>
                  <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-purple-300 font-bold text-xs">
                    {hibpResult.sha1Prefix}
                  </span>
                </div>
                <span className={`px-3 py-1 rounded-lg text-xs font-bold uppercase border ${
                  hibpResult.pwned
                    ? 'bg-rose-950 text-rose-300 border-rose-700'
                    : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                }`}>
                  {hibpResult.pwned ? 'BREACH DETECTED' : 'UNCOMPROMISED'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Public Breach Appearances</div>
                  <div className={`text-2xl font-bold mt-0.5 ${hibpResult.pwned ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {hibpResult.occurrences.toLocaleString()} times
                  </div>
                </div>
                <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Privacy Model</div>
                  <div className="text-xs font-bold text-zinc-200 mt-1">k-Anonymity (Zero Credential Leakage)</div>
                </div>
              </div>

              <div className={`p-4 rounded-xl border text-xs leading-relaxed ${
                hibpResult.pwned
                  ? 'bg-rose-950/30 border-rose-800/80 text-rose-200'
                  : 'bg-emerald-950/30 border-emerald-800/80 text-emerald-200'
              }`}>
                {hibpResult.recommendation}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: CIRCL CVE SEARCH */}
      {activeTab === 'circl' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6 font-mono">
          <div className="space-y-2">
            <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
              <Search className="w-4 h-4 text-emerald-400" />
              CIRCL Computer Incident Response Center Luxembourg (CVE & CPE)
            </h2>
            <p className="text-xs text-zinc-400">
              Query CIRCL’s authoritative vulnerability database for CVE definitions, Common Platform Enumerations (CPE), Common Attack Pattern Enumeration and Classification (CAPEC), and vendor advisory references.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={circlQuery}
                onChange={(e) => setCirclQuery(e.target.value)}
                placeholder="Enter CVE ID (e.g. CVE-2023-4863, CVE-2021-44228)..."
                onKeyDown={(e) => e.key === 'Enter' && handleCirclLookup()}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-emerald-500 uppercase"
              />
            </div>
            <button
              onClick={() => handleCirclLookup()}
              disabled={circlLoading}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow"
            >
              {circlLoading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Querying CIRCL...</span>
                </>
              ) : (
                <>
                  <Search className="w-3.5 h-3.5" />
                  <span>Inspect CVE</span>
                </>
              )}
            </button>
          </div>

          {/* Quick presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-zinc-500">Quick Samples:</span>
            {[
              { id: 'CVE-2023-4863', label: 'libwebp Buffer Overflow (Zero-Day)' },
              { id: 'CVE-2021-44228', label: 'Log4Shell RCE' },
              { id: 'CVE-2024-3400', label: 'PAN-OS Command Injection' },
              { id: 'CVE-2023-38606', label: 'Triangulation Apple Kernel' }
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  setCirclQuery(p.id);
                  handleCirclLookup(p.id);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-emerald-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                <span className="font-bold text-emerald-400 mr-1">{p.id}</span>
                <span>({p.label})</span>
              </button>
            ))}
          </div>

          {circlError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{circlError}</span>
            </div>
          )}

          {circlResult && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4 font-mono">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-zinc-100">{circlResult.id}</span>
                  {circlResult.cwe && (
                    <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-400">
                      {circlResult.cwe}
                    </span>
                  )}
                </div>
                {circlResult.cvss && (
                  <span className={`px-3 py-1 rounded-lg text-xs font-bold border ${
                    Number(circlResult.cvss) >= 9.0 
                      ? 'bg-rose-950 text-rose-300 border-rose-700'
                      : Number(circlResult.cvss) >= 7.0
                        ? 'bg-amber-950 text-amber-300 border-amber-700'
                        : 'bg-blue-950 text-blue-300 border-blue-700'
                  }`}>
                    CVSS: {circlResult.cvss}
                  </span>
                )}
              </div>

              {circlResult.summary && (
                <div className="p-4 bg-zinc-900/60 border border-zinc-800/80 rounded-xl text-xs text-zinc-300 leading-relaxed">
                  <div className="text-[10px] uppercase text-zinc-500 font-semibold mb-1">Vulnerability Summary</div>
                  {circlResult.summary}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Published Date</div>
                  <div className="font-bold text-zinc-200 mt-0.5">{circlResult.Published || 'N/A'}</div>
                </div>
                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Last Modified</div>
                  <div className="font-bold text-zinc-200 mt-0.5">{circlResult.Modified || 'N/A'}</div>
                </div>
                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">CIRCL Source</div>
                  <div className="font-bold text-emerald-400 mt-0.5">cve.circl.lu</div>
                </div>
              </div>

              {/* CAPEC Attack Patterns */}
              {circlResult.capec && Array.isArray(circlResult.capec) && circlResult.capec.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                    <Crosshair className="w-3.5 h-3.5 text-purple-400" />
                    <span>Associated CAPEC Attack Patterns ({circlResult.capec.length})</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {circlResult.capec.slice(0, 4).map((c: any, cIdx: number) => (
                      <div key={cIdx} className="p-2.5 rounded bg-zinc-900/60 border border-zinc-800 text-[11px] text-zinc-300">
                        <div className="font-bold text-purple-300">CAPEC-{c.id}: {c.name}</div>
                        {c.summary && <div className="text-zinc-400 text-[10px] mt-0.5 line-clamp-2">{c.summary}</div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Vulnerable Configurations */}
              {circlResult.vulnerable_configuration && circlResult.vulnerable_configuration.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5 text-blue-400" />
                    <span>Vulnerable Software CPEs ({circlResult.vulnerable_configuration.length})</span>
                  </div>
                  <div className="max-h-36 overflow-y-auto space-y-1 bg-zinc-900/40 p-2.5 rounded-lg border border-zinc-800 text-[11px] text-zinc-400 font-mono">
                    {circlResult.vulnerable_configuration.slice(0, 10).map((cpe: string, idx: number) => (
                      <div key={idx} className="truncate hover:text-zinc-200">
                        • {cpe}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* References */}
              {circlResult.references && circlResult.references.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                    <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Advisory References ({circlResult.references.length})</span>
                  </div>
                  <div className="max-h-32 overflow-y-auto space-y-1 text-[11px]">
                    {circlResult.references.slice(0, 6).map((ref: string, rIdx: number) => (
                      <a
                        key={rIdx}
                        href={ref}
                        target="_blank"
                        rel="noreferrer"
                        className="block text-cyan-400 hover:text-cyan-300 truncate hover:underline"
                      >
                        • {ref}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 7: IP-API.COM GEOLOCATION & ASN */}
      {activeTab === 'ipapi' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6 font-mono">
          <div className="space-y-2">
            <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-indigo-400" />
              IP-API.com Real-Time ASN & Geolocation Intelligence
            </h2>
            <p className="text-xs text-zinc-400">
              Query Autonomous System Numbers (ASN), ISP infrastructure, organization ownership, and precise geographic coordinates for any public IPv4 or IPv6 address.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={ipQuery}
                onChange={(e) => setIpQuery(e.target.value)}
                placeholder="Enter IP address or domain (e.g. 8.8.8.8, 1.1.1.1, github.com)..."
                onKeyDown={(e) => e.key === 'Enter' && handleIpLookup()}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button
              onClick={() => handleIpLookup()}
              disabled={ipLoading}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow"
            >
              {ipLoading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Geolocating...</span>
                </>
              ) : (
                <>
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Inspect IP</span>
                </>
              )}
            </button>
          </div>

          {/* Quick presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-zinc-500">Quick Targets:</span>
            {[
              { ip: '8.8.8.8', name: 'Google Public DNS' },
              { ip: '1.1.1.1', name: 'Cloudflare Anycast' },
              { ip: '9.9.9.9', name: 'Quad9 DNS' },
              { ip: '140.82.121.4', name: 'GitHub Edge' }
            ].map((target) => (
              <button
                key={target.ip}
                onClick={() => {
                  setIpQuery(target.ip);
                  handleIpLookup(target.ip);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-indigo-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                <span className="font-bold text-indigo-400 mr-1">{target.ip}</span>
                <span>({target.name})</span>
              </button>
            ))}
          </div>

          {ipError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{ipError}</span>
            </div>
          )}

          {ipResult && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4 font-mono">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-indigo-400" />
                  <span className="text-base font-bold text-zinc-100">{ipResult.query}</span>
                  <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-400">
                    {ipResult.countryCode || 'GLOBAL'}
                  </span>
                </div>
                <span className="px-3 py-1 rounded-lg text-xs font-bold uppercase bg-indigo-950 border border-indigo-700 text-indigo-300">
                  {ipResult.status === 'success' ? 'IP RESOLVED' : 'ERROR'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Country & City</div>
                  <div className="font-bold text-zinc-200 mt-1">
                    {ipResult.city || 'Unknown'}, {ipResult.country || 'N/A'}
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">{ipResult.regionName} ({ipResult.region})</div>
                </div>

                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">ASN & Routing</div>
                  <div className="font-bold text-indigo-400 mt-1">
                    {ipResult.as?.split(' ')[0] || 'AS Unknown'}
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5 truncate">{ipResult.asname || ipResult.as}</div>
                </div>

                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">ISP / Organization</div>
                  <div className="font-bold text-zinc-200 mt-1 truncate">
                    {ipResult.isp || 'N/A'}
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5 truncate">{ipResult.org}</div>
                </div>

                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Coordinates & Timezone</div>
                  <div className="font-bold text-zinc-200 mt-1">
                    {ipResult.lat}, {ipResult.lon}
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">{ipResult.timezone}</div>
                </div>
              </div>

              {/* Classification Badges */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-xs text-zinc-500 mr-1">Classification Flags:</span>
                <span className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                  ipResult.hosting 
                    ? 'bg-purple-950 text-purple-300 border-purple-800' 
                    : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                }`}>
                  Hosting/Datacenter: {ipResult.hosting ? 'YES' : 'NO'}
                </span>
                <span className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                  ipResult.proxy 
                    ? 'bg-rose-950 text-rose-300 border-rose-800' 
                    : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                }`}>
                  Proxy / VPN: {ipResult.proxy ? 'DETECTED' : 'CLEAN'}
                </span>
                <span className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                  ipResult.mobile 
                    ? 'bg-amber-950 text-amber-300 border-amber-800' 
                    : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                }`}>
                  Mobile Cellular: {ipResult.mobile ? 'YES' : 'NO'}
                </span>
                {ipResult.reverse && (
                  <span className="px-2.5 py-1 rounded-lg text-[11px] bg-zinc-900 text-zinc-300 border border-zinc-800">
                    PTR: {ipResult.reverse}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 8: ALIENVAULT OTX PULSES */}
      {activeTab === 'otx' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6 font-mono">
          <div className="space-y-2">
            <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
              <Crosshair className="w-4 h-4 text-rose-400" />
              AlienVault OTX (Open Threat Exchange) Pulses & Reputation
            </h2>
            <p className="text-xs text-zinc-400">
              Query global crowdsourced threat intelligence pulses, malicious activity reports, and targeted sector campaigns from thousands of security researchers worldwide.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <select
              value={otxType}
              onChange={(e) => setOtxType(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-zinc-200 focus:outline-none focus:border-rose-500"
            >
              <option value="domain">Domain</option>
              <option value="IPv4">IPv4 Address</option>
              <option value="hostname">Hostname</option>
              <option value="file">File Hash (MD5/SHA256)</option>
            </select>
            <div className="relative flex-1">
              <input
                type="text"
                value={otxQuery}
                onChange={(e) => setOtxQuery(e.target.value)}
                placeholder="Enter domain, IP, or hash (e.g. google.com, 8.8.8.8)..."
                onKeyDown={(e) => e.key === 'Enter' && handleOtxLookup()}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-rose-500"
              />
            </div>
            <button
              onClick={() => handleOtxLookup()}
              disabled={otxLoading}
              className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow"
            >
              {otxLoading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Scanning OTX...</span>
                </>
              ) : (
                <>
                  <Crosshair className="w-3.5 h-3.5" />
                  <span>Scan Indicator</span>
                </>
              )}
            </button>
          </div>

          {/* Quick presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-zinc-500">Quick Targets:</span>
            {[
              { val: 'google.com', type: 'domain', label: 'google.com (Clean)' },
              { val: '8.8.8.8', type: 'IPv4', label: '8.8.8.8 (Public DNS)' },
              { val: 'pastebin.com', type: 'domain', label: 'pastebin.com (Exfil Host)' },
              { val: 'cobaltstrike.com', type: 'domain', label: 'cobaltstrike.com' }
            ].map((target) => (
              <button
                key={target.val}
                onClick={() => {
                  setOtxQuery(target.val);
                  setOtxType(target.type);
                  handleOtxLookup(target.val, target.type);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-rose-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                <span className="font-bold text-rose-400 mr-1">{target.val}</span>
                <span>({target.type})</span>
              </button>
            ))}
          </div>

          {otxError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{otxError}</span>
            </div>
          )}

          {otxResult && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4 font-mono">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-zinc-100">{otxResult.indicator}</span>
                  <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-400 uppercase">
                    {otxResult.type}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-lg text-xs font-bold border ${
                    otxResult.pulseCount > 0 
                      ? 'bg-rose-950 text-rose-300 border-rose-700' 
                      : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  }`}>
                    {otxResult.pulseCount} THREAT PULSES
                  </span>
                </div>
              </div>

              {/* Adversaries & Malware Families */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Associated Adversaries</div>
                  <div className="mt-1 font-bold text-zinc-200">
                    {otxResult.adversaries && otxResult.adversaries.length > 0 
                      ? otxResult.adversaries.join(', ') 
                      : 'No specific APT/threat group linked'}
                  </div>
                </div>

                <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-lg">
                  <div className="text-[10px] text-zinc-500 uppercase">Malware Families</div>
                  <div className="mt-1 font-bold text-zinc-200">
                    {otxResult.malwareFamilies && otxResult.malwareFamilies.length > 0 
                      ? otxResult.malwareFamilies.join(', ') 
                      : 'No linked malware samples'}
                  </div>
                </div>
              </div>

              {/* Pulses list */}
              {otxResult.pulses && otxResult.pulses.length > 0 ? (
                <div className="space-y-3">
                  <div className="text-xs font-bold text-zinc-300 flex items-center justify-between">
                    <span>Active Threat Pulses ({otxResult.pulses.length})</span>
                    <span className="text-[10px] text-zinc-500">Source: AlienVault OTX Community</span>
                  </div>

                  <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                    {otxResult.pulses.map((pulse: any, pIdx: number) => (
                      <div key={pIdx} className="p-3 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-2 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-bold text-zinc-100 hover:text-rose-400 transition-colors">
                            {pulse.name}
                          </span>
                          <span className="text-[10px] text-zinc-500">
                            {pulse.created?.split('T')[0] || 'Recent'} • By {pulse.author_name || 'OTX Analyst'}
                          </span>
                        </div>

                        {pulse.description && (
                          <p className="text-[11px] text-zinc-400 line-clamp-2 leading-relaxed">
                            {pulse.description}
                          </p>
                        )}

                        {pulse.tags && pulse.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 pt-1">
                            {pulse.tags.slice(0, 5).map((t: string, tIdx: number) => (
                              <span key={tIdx} className="px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-[10px] text-rose-300">
                                #{t}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/60 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>No malicious threat pulses reported for this indicator on AlienVault OTX. Reputation appears clean.</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
