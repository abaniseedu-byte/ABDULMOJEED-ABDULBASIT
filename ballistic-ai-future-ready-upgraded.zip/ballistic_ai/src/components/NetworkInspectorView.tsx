import React, { useState } from 'react';
import { 
  Globe, 
  Shield, 
  Lock, 
  Unlock, 
  Server, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  Copy, 
  Check, 
  ExternalLink,
  Activity,
  Search,
  FileCheck,
  Radio
} from 'lucide-react';

type NetTab = 'socket' | 'crtsh' | 'doh';

export const NetworkInspectorView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NetTab>('socket');

  // Tab 1: Socket & TLS
  const [target, setTarget] = useState<string>('cisa.gov');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  // Tab 2: crt.sh Certificate Transparency
  const [crtDomain, setCrtDomain] = useState<string>('cisa.gov');
  const [crtLoading, setCrtLoading] = useState<boolean>(false);
  const [crtResult, setCrtResult] = useState<any>(null);
  const [crtError, setCrtError] = useState<string | null>(null);

  // Tab 3: Cloudflare DoH
  const [dohName, setDohName] = useState<string>('cisa.gov');
  const [dohType, setDohType] = useState<string>('A');
  const [dohLoading, setDohLoading] = useState<boolean>(false);
  const [dohResult, setDohResult] = useState<any>(null);
  const [dohError, setDohError] = useState<string | null>(null);

  const quickTargets = ['cisa.gov', 'github.com', 'cloudflare.com', 'google.com', 'nist.gov'];

  const handleInspect = async (hostToInspect?: string) => {
    const host = hostToInspect || target;
    if (!host.trim()) return;

    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/network/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: host.trim() })
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Inspection failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCrtshLookup = async (domainToLookup?: string) => {
    const dom = (domainToLookup || crtDomain).trim();
    if (!dom) return;
    setCrtLoading(true);
    setCrtError(null);
    setCrtResult(null);

    try {
      const res = await fetch('/api/network/crtsh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: dom })
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'crt.sh lookup failed');
      }
      setCrtResult(data);
    } catch (err: any) {
      setCrtError(err.message || 'Failed to query crt.sh transparency logs');
    } finally {
      setCrtLoading(false);
    }
  };

  const handleDohQuery = async () => {
    if (!dohName.trim()) return;
    setDohLoading(true);
    setDohError(null);
    setDohResult(null);

    try {
      const res = await fetch('/api/network/doh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: dohName.trim(), type: dohType })
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Cloudflare DoH query failed');
      }
      setDohResult(data);
    } catch (err: any) {
      setDohError(err.message || 'Failed to resolve DNS over HTTPS');
    } finally {
      setDohLoading(false);
    }
  };

  const copyData = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-cyan-500 pointer-events-none">
          <Globe className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded bg-cyan-950/80 border border-cyan-600 text-cyan-300 font-mono text-[11px] font-semibold flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              LIVE NETWORK & TLS ENGINE
            </span>
            <span className="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-600 text-emerald-300 font-mono text-[11px] font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              REAL NODE.JS DNS / CERT / DOH AUDITING
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Live Network, DNS & SSL/TLS Security Inspector
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-3xl leading-relaxed font-mono">
            Authoritative defensive network auditing: inspect TLS X.509 chains, calculate HTTP Security Grades, query crt.sh Certificate Transparency for subdomains, and perform encrypted recursive lookups with Cloudflare DoH.
          </p>

          {/* Sub-tabs */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-zinc-800/80">
            <button
              onClick={() => setActiveTab('socket')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'socket'
                  ? 'bg-cyan-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              Socket, TLS & Header Inspector
            </button>
            <button
              onClick={() => setActiveTab('crtsh')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'crtsh'
                  ? 'bg-cyan-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <FileCheck className="w-3.5 h-3.5" />
              crt.sh Certificate Transparency Logs
            </button>
            <button
              onClick={() => setActiveTab('doh')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'doh'
                  ? 'bg-cyan-600 text-white shadow'
                  : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              Cloudflare DNS-over-HTTPS (DoH)
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'socket' && (
        <div className="space-y-6">

      {/* Target Input and Quick Targets */}
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleInspect()}
              placeholder="Enter domain or URL (e.g. cisa.gov, github.com)..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            onClick={() => handleInspect()}
            disabled={isLoading || !target.trim()}
            className="px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-mono text-xs font-semibold flex items-center justify-center gap-2 transition-colors shadow-md"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{isLoading ? 'Inspecting...' : 'Audit Security Posture'}</span>
          </button>
        </div>

        {/* Quick selector buttons */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs font-mono">
          <span className="text-zinc-500 text-[11px]">Quick Targets:</span>
          {quickTargets.map((qt) => (
            <button
              key={qt}
              onClick={() => {
                setTarget(qt);
                handleInspect(qt);
              }}
              className="px-2.5 py-1 rounded-lg bg-zinc-950 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 transition-colors text-[11px]"
            >
              {qt}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-rose-300 font-mono text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          <span>Error inspecting target: {error}</span>
        </div>
      )}

      {/* Results View */}
      {result && (
        <div className="space-y-6">
          {/* Top Summary Badges */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Security Grade */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 font-mono flex items-center justify-between">
              <div>
                <div className="text-[11px] text-zinc-500 uppercase font-semibold">HTTP Security Grade</div>
                <div className="text-xs text-zinc-400 mt-1">
                  {result.headers ? `${result.headers.passedChecks}/${result.headers.totalChecks} Headers Active` : 'No HTTP data'}
                </div>
              </div>
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-bold border ${
                result.headers?.securityGrade === 'A+' || result.headers?.securityGrade === 'A'
                  ? 'bg-emerald-950/80 border-emerald-600 text-emerald-400'
                  : result.headers?.securityGrade === 'B'
                  ? 'bg-blue-950/80 border-blue-600 text-blue-400'
                  : result.headers?.securityGrade === 'C'
                  ? 'bg-yellow-950/80 border-yellow-600 text-yellow-400'
                  : 'bg-rose-950/80 border-rose-600 text-rose-400'
              }`}>
                {result.headers?.securityGrade || 'N/A'}
              </div>
            </div>

            {/* SSL/TLS Status */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 font-mono flex items-center justify-between">
              <div>
                <div className="text-[11px] text-zinc-500 uppercase font-semibold">SSL/TLS Encryption</div>
                <div className="text-xs text-zinc-300 mt-1">
                  {result.ssl ? result.ssl.protocol : 'No TLS Handshake'}
                </div>
                {result.ssl && (
                  <div className="text-[10px] text-zinc-500 mt-0.5">
                    {result.ssl.daysRemaining} days remaining
                  </div>
                )}
              </div>
              <div className={`p-3 rounded-2xl border ${
                result.ssl && !result.ssl.expired
                  ? 'bg-emerald-950/80 border-emerald-600 text-emerald-400'
                  : 'bg-rose-950/80 border-rose-600 text-rose-400'
              }`}>
                {result.ssl && !result.ssl.expired ? <Lock className="w-6 h-6" /> : <Unlock className="w-6 h-6" />}
              </div>
            </div>

            {/* Latency & Server */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 font-mono flex items-center justify-between">
              <div>
                <div className="text-[11px] text-zinc-500 uppercase font-semibold">Roundtrip Latency</div>
                <div className="text-xl font-bold text-zinc-100 mt-0.5">
                  {result.headers ? `${result.headers.latencyMs}ms` : '—'}
                </div>
                <div className="text-[10px] text-zinc-400 mt-0.5 truncate max-w-[160px]">
                  Server: {result.headers?.server || 'Undisclosed'}
                </div>
              </div>
              <div className="p-3 rounded-2xl border bg-cyan-950/80 border-cyan-600 text-cyan-400">
                <Server className="w-6 h-6" />
              </div>
            </div>
          </div>

          {/* Section 1: HTTP Security Response Headers */}
          {result.headers && (
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 sm:p-6 space-y-4 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-cyan-400" />
                  <span>HTTP Security Headers Analysis</span>
                </h3>
                <span className="text-zinc-400 text-[11px]">
                  HTTP {result.headers.statusCode} {result.headers.statusText}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {result.headers.checks.map((c: any) => (
                  <div
                    key={c.name}
                    className={`p-3.5 rounded-xl border flex flex-col justify-between gap-2 ${
                      c.present
                        ? 'bg-zinc-950 border-emerald-900/60'
                        : 'bg-zinc-950 border-rose-900/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="font-semibold text-zinc-200">{c.name}</div>
                      {c.present ? (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          PRESENT
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-rose-950 text-rose-300 border border-rose-800 font-bold flex items-center gap-1">
                          <XCircle className="w-3 h-3 text-rose-400" />
                          MISSING
                        </span>
                      )}
                    </div>

                    {c.present ? (
                      <div className="text-[11px] text-emerald-300 break-all bg-emerald-950/20 p-2 rounded border border-emerald-900/40">
                        {c.value}
                      </div>
                    ) : (
                      <div className="text-[11px] text-zinc-400">
                        Recommendation: <span className="text-rose-300">{c.recommendation}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 2: SSL/TLS Certificate Chain Details */}
          {result.ssl && (
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 sm:p-6 space-y-4 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-emerald-400" />
                  <span>X.509 SSL/TLS Certificate Specifications</span>
                </h3>
                <button
                  onClick={() => copyData(JSON.stringify(result.ssl, null, 2), 'ssl')}
                  className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] flex items-center gap-1"
                >
                  {copiedSection === 'ssl' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>Copy Certificate Info</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-1">
                  <div className="text-[10px] text-zinc-500 uppercase">Subject Common Name (CN)</div>
                  <div className="font-semibold text-zinc-100">{result.ssl.subject}</div>
                </div>

                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-1">
                  <div className="text-[10px] text-zinc-500 uppercase">Certificate Issuer</div>
                  <div className="font-semibold text-cyan-300">{result.ssl.issuer}</div>
                </div>

                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-1">
                  <div className="text-[10px] text-zinc-500 uppercase">Validity Period</div>
                  <div className="text-zinc-300 text-[11px]">
                    From: {new Date(result.ssl.validFrom).toLocaleDateString()}
                    <br />
                    To: {new Date(result.ssl.validTo).toLocaleDateString()} ({result.ssl.daysRemaining} days left)
                  </div>
                </div>

                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-1">
                  <div className="text-[10px] text-zinc-500 uppercase">Cipher Suite & Protocol</div>
                  <div className="text-zinc-300 text-[11px]">
                    {result.ssl.cipherName} ({result.ssl.protocol})
                  </div>
                </div>

                {result.ssl.san && result.ssl.san.length > 0 && (
                  <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-1 sm:col-span-2">
                    <div className="text-[10px] text-zinc-500 uppercase">Subject Alternative Names (SAN)</div>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {result.ssl.san.slice(0, 10).map((s: string) => (
                        <span key={s} className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 text-[10px]">
                          {s}
                        </span>
                      ))}
                      {result.ssl.san.length > 10 && (
                        <span className="text-zinc-500 text-[10px] self-center">
                          +{result.ssl.san.length - 10} more
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Section 3: Authoritative DNS Records */}
          {result.dns && (
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 sm:p-6 space-y-4 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-400" />
                  <span>Authoritative DNS Records</span>
                </h3>
                <button
                  onClick={() => copyData(JSON.stringify(result.dns, null, 2), 'dns')}
                  className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] flex items-center gap-1"
                >
                  {copiedSection === 'dns' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>Copy DNS Records</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* A & AAAA */}
                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-2">
                  <div className="text-[11px] font-semibold text-zinc-400 uppercase">IPv4 Addresses (A Records)</div>
                  {result.dns.a.length === 0 ? (
                    <div className="text-zinc-500 text-[11px]">No A records returned</div>
                  ) : (
                    <div className="space-y-1">
                      {result.dns.a.map((ip: string) => (
                        <div key={ip} className="text-zinc-200 text-xs">{ip}</div>
                      ))}
                    </div>
                  )}

                  {result.dns.aaaa.length > 0 && (
                    <>
                      <div className="text-[11px] font-semibold text-zinc-400 uppercase pt-2">IPv6 Addresses (AAAA)</div>
                      <div className="space-y-1">
                        {result.dns.aaaa.map((ip: string) => (
                          <div key={ip} className="text-zinc-300 text-[11px] truncate">{ip}</div>
                        ))}
                      </div>
                    </>
                  )}
                </div>

                {/* MX & NS */}
                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-2">
                  <div className="text-[11px] font-semibold text-zinc-400 uppercase">Mail Exchangers (MX Records)</div>
                  {result.dns.mx.length === 0 ? (
                    <div className="text-zinc-500 text-[11px]">No MX records configured</div>
                  ) : (
                    <div className="space-y-1">
                      {result.dns.mx.map((m: any, idx: number) => (
                        <div key={idx} className="text-zinc-300 text-[11px]">
                          <span className="text-amber-400 font-semibold">{m.priority}</span> {m.exchange}
                        </div>
                      ))}
                    </div>
                  )}

                  {result.dns.ns.length > 0 && (
                    <>
                      <div className="text-[11px] font-semibold text-zinc-400 uppercase pt-2">Name Servers (NS)</div>
                      <div className="space-y-1">
                        {result.dns.ns.map((ns: string) => (
                          <div key={ns} className="text-cyan-300 text-[11px]">{ns}</div>
                        ))}
                      </div>
                    </>
                  )}
                </div>

                {/* TXT Records (SPF / DMARC / Domain Verification) */}
                {result.dns.txt && result.dns.txt.length > 0 && (
                  <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 space-y-2 sm:col-span-2">
                    <div className="text-[11px] font-semibold text-zinc-400 uppercase">
                      TXT Records ({result.dns.txt.length} records — SPF, DKIM, DMARC, Verification)
                    </div>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {result.dns.txt.map((txt: string, idx: number) => (
                        <div key={idx} className="text-zinc-300 text-[11px] bg-zinc-900/60 p-2 rounded border border-zinc-800/80 break-all">
                          {txt}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
        </div>
      )}

      {/* TAB 2: CRT.SH CERTIFICATE TRANSPARENCY SUBDOMAINS */}
      {activeTab === 'crtsh' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6 font-mono">
          <div className="space-y-2">
            <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-cyan-400" />
              crt.sh (Sectigo) Certificate Transparency Subdomain Enumeration
            </h2>
            <p className="text-xs text-zinc-400">
              Live queries publicly logged SSL/TLS certificate transparency (CT) append-only logs. Reveals registered subdomains, wildcards, and certificate issuance history without sending intrusive network packets to the target.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={crtDomain}
              onChange={(e) => setCrtDomain(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCrtshLookup()}
              placeholder="e.g. cisa.gov, github.com, nist.gov..."
              className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-100 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={() => handleCrtshLookup()}
              disabled={crtLoading}
              className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${crtLoading ? 'animate-spin' : ''}`} />
              <span>{crtLoading ? 'Querying crt.sh...' : 'Enumerate Subdomains'}</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            <span className="text-zinc-500 text-[11px] self-center">Quick Domains:</span>
            {['cisa.gov', 'github.com', 'nist.gov', 'cloudflare.com'].map((d) => (
              <button
                key={d}
                onClick={() => {
                  setCrtDomain(d);
                  handleCrtshLookup(d);
                }}
                className="px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 hover:border-cyan-600 text-zinc-300 hover:text-white transition-all text-[11px]"
              >
                {d}
              </button>
            ))}
          </div>

          {crtError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{crtError}</span>
            </div>
          )}

          {crtResult && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-zinc-400 pb-2 border-b border-zinc-800">
                <span>Unique Subdomains Discovered: <strong className="text-cyan-400">{crtResult.subdomainCount}</strong></span>
                <span>Source: {crtResult.source}</span>
              </div>

              {/* Subdomain chips */}
              <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
                <div className="text-[11px] font-bold text-zinc-300 uppercase">Publicly Registered Subdomains ({crtResult.subdomains?.length || 0})</div>
                <div className="flex flex-wrap gap-2 max-h-64 overflow-y-auto">
                  {crtResult.subdomains?.map((sub: string, idx: number) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-cyan-300 hover:border-cyan-600 cursor-pointer transition-colors"
                      onClick={() => {
                        setTarget(sub);
                        setActiveTab('socket');
                        handleInspect(sub);
                      }}
                      title="Click to run full Socket & TLS audit on this subdomain"
                    >
                      {sub}
                    </span>
                  ))}
                </div>
              </div>

              {/* Recent Certificates Summary */}
              {crtResult.recentCerts?.length > 0 && (
                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
                  <div className="text-[11px] font-bold text-zinc-300 uppercase">Recent Certificate Transparency Log Entries</div>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {crtResult.recentCerts.map((c: any, idx: number) => (
                      <div key={idx} className="p-2.5 rounded bg-zinc-900/60 border border-zinc-800/80 text-xs space-y-1">
                        <div className="flex justify-between text-zinc-200 font-bold">
                          <span>{c.commonName || crtResult.domain}</span>
                          <span className="text-zinc-500 text-[10px]">Log ID: {c.id}</span>
                        </div>
                        <div className="text-[11px] text-zinc-400 truncate">Issuer: {c.issuer}</div>
                        <div className="text-[10px] text-zinc-500">
                          Logged: {c.loggedAt?.split('T')[0] || 'N/A'} • Valid: {c.notBefore?.split('T')[0]} to {c.notAfter?.split('T')[0]}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CLOUDFLARE DOH */}
      {activeTab === 'doh' && (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-6 font-mono">
          <div className="space-y-2">
            <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400" />
              Cloudflare 1.1.1.1 DNS-over-HTTPS (DoH) API
            </h2>
            <p className="text-xs text-zinc-400">
              Direct authoritative queries to Cloudflare&apos;s privacy-preserving DoH resolver over HTTP/2 and TLS, returning standard RFC-compliant JSON DNS records.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={dohName}
              onChange={(e) => setDohName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleDohQuery()}
              placeholder="e.g. cisa.gov, cloudflare.com..."
              className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-100 focus:outline-none focus:border-cyan-500"
            />
            <select
              value={dohType}
              onChange={(e) => setDohType(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-zinc-200 focus:outline-none focus:border-cyan-500"
            >
              {['A', 'AAAA', 'MX', 'TXT', 'NS', 'CAA', 'CNAME', 'SOA'].map((t) => (
                <option key={t} value={t}>{t} Record</option>
              ))}
            </select>
            <button
              onClick={handleDohQuery}
              disabled={dohLoading}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${dohLoading ? 'animate-spin' : ''}`} />
              <span>{dohLoading ? 'Resolving...' : 'DoH Query'}</span>
            </button>
          </div>

          {dohError && (
            <div className="p-4 bg-rose-950/40 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{dohError}</span>
            </div>
          )}

          {dohResult && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between text-xs text-zinc-400 pb-2 border-b border-zinc-800">
                <span>Status Code: <strong className="text-emerald-400">{dohResult.dnsResponse?.Status === 0 ? 'NOERROR (0)' : dohResult.dnsResponse?.Status}</strong></span>
                <span>Source: {dohResult.source}</span>
              </div>

              {/* Answers */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-zinc-300 uppercase">Answers Returned</div>
                {dohResult.dnsResponse?.Answer && dohResult.dnsResponse.Answer.length > 0 ? (
                  dohResult.dnsResponse.Answer.map((ans: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 text-xs flex flex-wrap items-center justify-between gap-2">
                      <span className="font-bold text-zinc-200">{ans.data}</span>
                      <div className="flex items-center gap-3 text-[11px] text-zinc-400">
                        <span>TTL: {ans.TTL}s</span>
                        <span className="px-2 py-0.5 rounded bg-zinc-950 border border-zinc-700 text-emerald-300 uppercase font-bold">
                          {dohType}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-zinc-500 text-xs py-4 text-center">No answers returned for this record type.</div>
                )}
              </div>

              {/* Raw JSON */}
              <div className="pt-2 border-t border-zinc-900">
                <div className="text-[10px] text-zinc-500 uppercase mb-1">Raw RFC DoH Response Object</div>
                <pre className="p-3 bg-zinc-900/50 rounded-lg text-[10px] text-zinc-400 overflow-x-auto max-h-48">
                  {JSON.stringify(dohResult.dnsResponse, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
