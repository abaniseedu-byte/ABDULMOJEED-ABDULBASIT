import React, { useState, useEffect } from 'react';
import { Terminal, Shield, Cpu, Play, Server, RefreshCw, Send, CheckCircle2, AlertTriangle, Radio } from 'lucide-react';

interface C2Session {
  id: string;
  host: string;
  user: string;
  status: string;
  uptime: string;
  architecture: string;
}

export const C2ListenerConsole: React.FC = () => {
  const [sessions, setSessions] = useState<C2Session[]>([]);
  const [selectedSession, setSelectedSession] = useState<string>('c2-local');
  const [commandInput, setCommandInput] = useState<string>('whoami');
  const [consoleLogs, setConsoleLogs] = useState<Array<{ sender: string; text: string; time: string }>>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/c2/sessions');
      const data = await res.json();
      if (Array.isArray(data.sessions)) {
        setSessions(data.sessions);
        if (data.sessions.length > 0 && !data.sessions.some((s: C2Session) => s.id === selectedSession)) {
          setSelectedSession(data.sessions[0].id);
        }
      }
    } catch (err) {
      console.error('Failed to fetch sessions', err);
    }
  };

  const handleSendCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim() || isLoading) return;

    const cmd = commandInput;
    setCommandInput('');
    setIsLoading(true);

    const now = new Date().toLocaleTimeString();
    setConsoleLogs(prev => [...prev, { sender: 'operator', text: `> ${cmd}`, time: now }]);

    try {
      const res = await fetch('/api/c2/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: selectedSession, command: cmd })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setConsoleLogs(prev => [...prev, { sender: 'agent', text: data.output || '(process exited with no stdout)', time: new Date().toLocaleTimeString() }]);
    } catch (err: any) {
      setConsoleLogs(prev => [...prev, { sender: 'error', text: `[-] Execution error: ${err.message}`, time: new Date().toLocaleTimeString() }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 text-emerald-500 pointer-events-none">
          <Radio className="w-32 h-32 animate-pulse" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs uppercase tracking-widest font-semibold">
            <Radio className="w-4 h-4 animate-ping text-emerald-400" />
            <span>LIVE AGENT / LOCAL RUNTIME CONSOLE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-bold text-zinc-100 tracking-tight">
            Command & Control Agent Telemetry
          </h1>
          <p className="text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Execute commands only against an actually connected local runtime or an explicitly configured authenticated agent transport. Remote sessions are never fabricated.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Active Sessions Sidebar */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-4 lg:col-span-1">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-2 text-xs font-mono font-semibold text-zinc-300">
              <Server className="w-4 h-4 text-emerald-400" />
              <span>Active Agents ({sessions.length})</span>
            </div>
            <button onClick={fetchSessions} className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-zinc-200">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2">
            {sessions.length > 0 ? sessions.map((s) => (
              <div
                key={s.id}
                onClick={() => setSelectedSession(s.id)}
                className={`p-3 rounded-xl border transition-all cursor-pointer font-mono text-xs ${
                  selectedSession === s.id
                    ? 'bg-emerald-950/40 border-emerald-500/80 text-emerald-300 shadow-md'
                    : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200">{s.id}</span>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    {s.status}
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-zinc-400 truncate">{s.user}</div>
                <div className="mt-0.5 text-[10px] text-zinc-500">{s.host} ({s.architecture})</div>
              </div>
            )) : (
              <div className="text-[11px] text-zinc-500 font-mono p-2">No live agent sessions are connected.</div>
            )}
          </div>
        </div>

        {/* Interactive WebShell Terminal */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 sm:p-6 lg:col-span-3 flex flex-col h-[600px] shadow-2xl">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
            <div className="flex items-center gap-2 font-mono text-xs text-zinc-300">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>Interactive Session Terminal [{selectedSession}]</span>
            </div>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              LIVE LOCAL RUNTIME
            </span>
          </div>

          {/* Log Window */}
          <div className="flex-1 bg-zinc-900/70 border border-zinc-800/80 rounded-xl p-4 font-mono text-xs overflow-y-auto space-y-3">
            {consoleLogs.map((log, i) => (
              <div key={i} className="space-y-1">
                <div className="flex items-center justify-between text-[10px] text-zinc-500">
                  <span className="uppercase tracking-wider">{log.sender}</span>
                  <span>{log.time}</span>
                </div>
                <pre className={`whitespace-pre-wrap leading-relaxed ${
                  log.sender === 'operator' ? 'text-cyan-300 font-semibold' :
                  log.sender === 'error' ? 'text-rose-400 font-semibold' : 'text-emerald-300'
                }`}>
                  {log.text}
                </pre>
              </div>
            ))}
            {isLoading && (
              <div className="text-zinc-500 font-mono text-xs animate-pulse">
                [*] Transmitting command to remote agent...
              </div>
            )}
          </div>

          {/* Command Form */}
          <form onSubmit={handleSendCommand} className="mt-4 flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3 top-3 font-mono text-xs text-emerald-400">&gt;</span>
              <input
                type="text"
                value={commandInput}
                onChange={(e) => setCommandInput(e.target.value)}
                placeholder="Enter shell command (e.g., whoami, id, uname -a)..."
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-7 pr-4 py-2.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-zinc-950 font-mono text-xs font-bold flex items-center gap-2 transition-colors shadow-lg disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Execute</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
