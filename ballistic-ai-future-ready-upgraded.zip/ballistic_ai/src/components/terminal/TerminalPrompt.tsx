import React from 'react';
import { PromptStyle } from '../../types/terminal';

interface TerminalPromptProps {
  user: string;
  hostname: string;
  displayCwd: string;
  style: PromptStyle;
  isInput?: boolean;
}

export const TerminalPrompt: React.FC<TerminalPromptProps> = ({
  user,
  hostname,
  displayCwd,
  style,
  isInput = false
}) => {
  const isRoot = user === 'root';

  if (style === 'compact-1line') {
    return (
      <span className="font-mono font-semibold select-none flex-shrink-0">
        <span className={isRoot ? 'text-rose-400' : 'text-emerald-400'}>{user}</span>
        <span className="text-zinc-500">@</span>
        <span className="text-cyan-400">{hostname}</span>
        <span className="text-zinc-500">:</span>
        <span className="text-blue-400 font-bold">{displayCwd}</span>
        <span className={isRoot ? 'text-rose-400 ml-1' : 'text-zinc-400 ml-1'}>
          {isRoot ? '#' : '$'}
        </span>
      </span>
    );
  }

  // Zsh 2-line Kali prompt
  const effectiveUser = style === 'root-kali' ? 'root' : user;
  const effectiveIsRoot = effectiveUser === 'root';
  const symbol = effectiveIsRoot ? '#' : '$';

  return (
    <div className="font-mono select-none flex-shrink-0 leading-tight">
      {/* Top line of prompt */}
      <div className="flex items-center text-xs">
        <span className="text-blue-400 select-none">┌──(</span>
        <span className={`font-bold ${effectiveIsRoot ? 'text-rose-400' : 'text-cyan-400'}`}>
          {effectiveUser}
        </span>
        <span className="text-zinc-400">㉿</span>
        <span className="text-blue-400 font-medium">{hostname}</span>
        <span className="text-blue-400 select-none">)-[</span>
        <span className="text-zinc-100 font-semibold">{displayCwd}</span>
        <span className="text-blue-400 select-none">]</span>
      </div>

      {/* Bottom line with cursor hook */}
      <div className="flex items-center text-xs mt-0.5">
        <span className="text-blue-400 select-none mr-1.5">└─{symbol}</span>
      </div>
    </div>
  );
};
