import React from 'react';
import { X, Sliders, RotateCcw, Volume2, Type, Palette, Terminal, Eye } from 'lucide-react';
import { TerminalSettings, DEFAULT_TERMINAL_SETTINGS, TerminalThemeId, PromptStyle, CursorStyle } from '../../types/terminal';

interface TerminalSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TerminalSettings;
  onUpdateSettings: (newSettings: Partial<TerminalSettings>) => void;
  onReset: () => void;
}

export const TerminalSettingsModal: React.FC<TerminalSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onReset
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden font-mono text-xs flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-zinc-900 px-5 py-3.5 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-zinc-100 font-semibold">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>Kali Terminal Preferences</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-5 overflow-y-auto flex-1 text-zinc-300">
          {/* Theme */}
          <div className="space-y-2">
            <label className="flex items-center gap-1.5 text-zinc-200 font-semibold uppercase tracking-wider text-[11px]">
              <Palette className="w-3.5 h-3.5 text-cyan-400" />
              <span>Color Palette Theme</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'kali-dark' as TerminalThemeId, name: 'Kali Classic', desc: 'Navy slate & cyan' },
                { id: 'kali-oled' as TerminalThemeId, name: 'Kali Pure OLED', desc: 'True #000 black' },
                { id: 'kali-matrix' as TerminalThemeId, name: 'Kali Matrix', desc: 'Terminal green on dark' },
                { id: 'kali-red' as TerminalThemeId, name: 'Kali Red Team', desc: 'Crimson & charcoal' },
                { id: 'solarized' as TerminalThemeId, name: 'Solarized Dark', desc: 'Teal & cyan contrast' },
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => onUpdateSettings({ theme: t.id })}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    settings.theme === t.id
                      ? 'border-cyan-500 bg-cyan-950/40 text-cyan-200'
                      : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="font-semibold text-zinc-200">{t.name}</div>
                  <div className="text-[10px] text-zinc-500">{t.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Typography */}
          <div className="space-y-2 border-t border-zinc-800/80 pt-4">
            <label className="flex items-center gap-1.5 text-zinc-200 font-semibold uppercase tracking-wider text-[11px]">
              <Type className="w-3.5 h-3.5 text-cyan-400" />
              <span>Typography & Sizing</span>
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-zinc-500 block mb-1">Font Size: {settings.fontSize}px</span>
                <input
                  type="range"
                  min={11}
                  max={17}
                  step={1}
                  value={settings.fontSize}
                  onChange={(e) => onUpdateSettings({ fontSize: parseInt(e.target.value, 10) })}
                  className="w-full accent-cyan-500"
                />
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block mb-1">Font Family</span>
                <select
                  value={settings.fontFamily}
                  onChange={(e) => onUpdateSettings({ fontFamily: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value='ui-monospace, SFMono-Regular, "JetBrains Mono", Menlo, Monaco, Consolas, monospace'>
                    JetBrains / System Monospace
                  </option>
                  <option value='"Fira Code", monospace'>Fira Code</option>
                  <option value='"Ubuntu Mono", monospace'>Ubuntu Mono</option>
                  <option value='"Courier New", monospace'>Courier New</option>
                </select>
              </div>
            </div>
          </div>

          {/* Prompt Style */}
          <div className="space-y-2 border-t border-zinc-800/80 pt-4">
            <label className="flex items-center gap-1.5 text-zinc-200 font-semibold uppercase tracking-wider text-[11px]">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Shell Prompt Format</span>
            </label>
            <div className="space-y-1.5">
              {[
                {
                  id: 'zsh-kali' as PromptStyle,
                  name: 'Kali Rolling ZSH (Default)',
                  preview: '┌──(kali㉿kali-rolling)-[~]\n└─$'
                },
                {
                  id: 'root-kali' as PromptStyle,
                  name: 'Kali Root Operator (#)',
                  preview: '┌──(root㉿kali-sec-ops)-[~]\n└─#'
                },
                {
                  id: 'compact-1line' as PromptStyle,
                  name: 'Single Line Compact ($)',
                  preview: 'kali@kali-rolling:~$ '
                }
              ].map(p => (
                <button
                  key={p.id}
                  onClick={() => onUpdateSettings({ promptStyle: p.id })}
                  className={`w-full p-2 rounded-lg border text-left flex items-center justify-between transition-all ${
                    settings.promptStyle === p.id
                      ? 'border-cyan-500 bg-cyan-950/40 text-cyan-200'
                      : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-zinc-200">{p.name}</div>
                    <pre className="text-[10px] text-zinc-500 font-mono mt-0.5 whitespace-pre">{p.preview}</pre>
                  </div>
                  {settings.promptStyle === p.id && (
                    <span className="text-cyan-400 font-bold text-xs">✓ Active</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Cursor & Feedback */}
          <div className="space-y-3 border-t border-zinc-800/80 pt-4">
            <label className="flex items-center gap-1.5 text-zinc-200 font-semibold uppercase tracking-wider text-[11px]">
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              <span>Cursor & Feedback Options</span>
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-zinc-500 block mb-1">Cursor Style</span>
                <div className="flex rounded-lg border border-zinc-800 p-0.5 bg-zinc-900">
                  {(['block', 'underline', 'bar'] as CursorStyle[]).map(c => (
                    <button
                      key={c}
                      onClick={() => onUpdateSettings({ cursorStyle: c })}
                      className={`flex-1 py-1 text-center rounded capitalize text-[11px] ${
                        settings.cursorStyle === c
                          ? 'bg-cyan-950 text-cyan-300 font-semibold'
                          : 'text-zinc-500 hover:text-zinc-300'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] text-zinc-500 block mb-1">Scrollback Buffer</span>
                <select
                  value={settings.scrollbackLimit}
                  onChange={(e) => onUpdateSettings({ scrollbackLimit: parseInt(e.target.value, 10) })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200 focus:outline-none"
                >
                  <option value={1000}>1,000 lines</option>
                  <option value={2000}>2,000 lines</option>
                  <option value={5000}>5,000 lines</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={settings.cursorBlink}
                  onChange={(e) => onUpdateSettings({ cursorBlink: e.target.checked })}
                  className="accent-cyan-500 rounded"
                />
                <span className="text-zinc-300">Blinking Cursor animation</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={settings.audioBell}
                  onChange={(e) => onUpdateSettings({ audioBell: e.target.checked })}
                  className="accent-cyan-500 rounded"
                />
                <span className="text-zinc-300 flex items-center gap-1">
                  <Volume2 className="w-3 h-3 text-cyan-400" />
                  Terminal Audio Bell on Command Error
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={settings.showTiming}
                  onChange={(e) => onUpdateSettings({ showTiming: e.target.checked })}
                  className="accent-cyan-500 rounded"
                />
                <span className="text-zinc-300">Display execution timing badges (ms)</span>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-zinc-900 px-5 py-3 border-t border-zinc-800 flex items-center justify-between">
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 bg-zinc-800/80 hover:bg-zinc-800 transition-colors text-[11px]"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Defaults</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-semibold transition-colors text-[11px]"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
