import React, { useRef, useEffect } from 'react';
import { Search, ChevronUp, ChevronDown, X } from 'lucide-react';

interface TerminalSearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  matchCount: number;
  currentMatchIndex: number;
  onNext: () => void;
  onPrev: () => void;
  onClose: () => void;
}

export const TerminalSearchBar: React.FC<TerminalSearchBarProps> = ({
  searchQuery,
  onSearchChange,
  matchCount,
  currentMatchIndex,
  onNext,
  onPrev,
  onClose
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'Enter') {
      if (e.shiftKey) {
        onPrev();
      } else {
        onNext();
      }
    }
  };

  return (
    <div className="absolute top-2 right-4 z-40 bg-zinc-900/95 border border-zinc-700/80 rounded-lg shadow-2xl p-1.5 flex items-center gap-2 backdrop-blur-md text-xs font-mono text-zinc-200 animate-in fade-in slide-in-from-top-2 duration-150">
      <Search className="w-3.5 h-3.5 text-zinc-400 ml-1 flex-shrink-0" />
      <input
        ref={inputRef}
        type="text"
        value={searchQuery}
        onChange={(e) => onSearchChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Find in output (Enter/Shift+Enter)..."
        className="w-52 sm:w-64 bg-zinc-950/80 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
      />

      <div className="text-[11px] text-zinc-400 whitespace-nowrap min-w-[50px] text-center">
        {searchQuery ? (
          matchCount > 0 ? (
            <span>{matchCount} match{matchCount > 1 ? 'es' : ''}</span>
          ) : (
            <span className="text-rose-400">0 matches</span>
          )
        ) : (
          <span className="text-zinc-600">--</span>
        )}
      </div>

      <div className="flex items-center gap-0.5">
        <button
          onClick={onPrev}
          disabled={matchCount === 0}
          title="Previous Match (Shift+Enter)"
          className="p-1 rounded hover:bg-zinc-800 text-zinc-300 disabled:opacity-30 transition-colors"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onNext}
          disabled={matchCount === 0}
          title="Next Match (Enter)"
          className="p-1 rounded hover:bg-zinc-800 text-zinc-300 disabled:opacity-30 transition-colors"
        >
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onClose}
          title="Close (Esc)"
          className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors ml-1"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
