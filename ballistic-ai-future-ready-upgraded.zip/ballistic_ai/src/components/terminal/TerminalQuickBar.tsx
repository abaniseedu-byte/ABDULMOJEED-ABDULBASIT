import React, { useState } from 'react';
import { Terminal, Shield, Network, Cpu, FileText, ChevronRight } from 'lucide-react';

interface TerminalQuickBarProps {
  onSelectCommand: (cmd: string) => void;
}

export const TerminalQuickBar: React.FC<TerminalQuickBarProps> = ({ onSelectCommand }) => {
  const [activeCategory, setActiveCategory] = useState<'offensive' | 'recon' | 'system' | 'files' | 'scripts'>('offensive');

  const categories = {
    offensive: [
      { cmd: 'gobuster dir -u http://127.0.0.1:3000 -w wordlists/directories.txt', desc: 'Run Gobuster Web Directory & Path Fuzzer' },
      { cmd: 'sqlmap -u "http://127.0.0.1:3000/api/users?id=1" --batch', desc: 'Run SQLMap automated SQL injection assessment' },
      { cmd: 'nikto -h 127.0.0.1:3000', desc: 'Run Nikto comprehensive web server vulnerability scan' },
      { cmd: 'hydra -l admin -P wordlists/passwords.txt 127.0.0.1 ssh', desc: 'Run THC-Hydra password brute force test' },
      { cmd: 'hashcat -m 0 5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', desc: 'Crack SHA-256 / MD5 password hash' },
      { cmd: 'msfconsole search cve:2024', desc: 'Search Metasploit Framework 6 exploit database' }
    ],
    recon: [
      { cmd: 'nmap 127.0.0.1', desc: 'Real TCP socket port scan' },
      { cmd: 'dig google.com', desc: 'DNS record lookup' },
      { cmd: 'whois google.com', desc: 'Domain registry WHOIS lookup' },
      { cmd: 'nc -zv 127.0.0.1 3000', desc: 'Netcat TCP port connectivity test' },
      { cmd: 'curl -s -I http://127.0.0.1:3000', desc: 'HTTP response header inspection' }
    ],
    system: [
      { cmd: 'neofetch', desc: 'Kali Linux system specifications & dragon banner' },
      { cmd: 'whoami && id', desc: 'User identity & groups' },
      { cmd: 'uname -a', desc: 'Kernel & architecture' },
      { cmd: 'uptime && df -h', desc: 'Uptime & storage' },
      { cmd: 'ps aux | head -n 8', desc: 'Active process tree' }
    ],
    files: [
      { cmd: 'pwd && ls -la', desc: 'List current directory' },
      { cmd: 'cat notes.txt', desc: 'Read engagement notes' },
      { cmd: 'cat wordlists/directories.txt', desc: 'View directories wordlist' },
      { cmd: 'cat wordlists/passwords.txt', desc: 'View passwords wordlist' },
      { cmd: 'find . -maxdepth 2', desc: 'Recursive folder map' }
    ],
    scripts: [
      { cmd: 'python3 scripts/port_probe.py 127.0.0.1 3000', desc: 'Run Python socket scanner' },
      { cmd: 'bash scripts/banner_grab.sh 127.0.0.1 3000', desc: 'Run shell banner grabber' },
      { cmd: 'node -e "console.log(process.versions)"', desc: 'Node runtime diagnostic' },
      { cmd: 'help', desc: 'Display Kali command manual' }
    ]
  };

  return (
    <div className="bg-zinc-950/80 border-b border-zinc-800/80 px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs font-mono select-none">
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
        <span className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider mr-1 flex items-center gap-1">
          <Terminal className="w-3 h-3 text-cyan-400" />
          Quick:
        </span>

        <button
          onClick={() => setActiveCategory('offensive')}
          className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors ${
            activeCategory === 'offensive' ? 'bg-red-950/90 text-red-300 border border-red-700/70' : 'text-zinc-400 hover:text-red-300'
          }`}
        >
          ⚔️ Offensive
        </button>
        <button
          onClick={() => setActiveCategory('recon')}
          className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
            activeCategory === 'recon' ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-700/60' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Recon
        </button>
        <button
          onClick={() => setActiveCategory('system')}
          className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
            activeCategory === 'system' ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-700/60' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          System
        </button>
        <button
          onClick={() => setActiveCategory('files')}
          className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
            activeCategory === 'files' ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-700/60' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Files
        </button>
        <button
          onClick={() => setActiveCategory('scripts')}
          className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
            activeCategory === 'scripts' ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-700/60' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Scripts
        </button>
      </div>

      <div className="flex items-center gap-1.5 overflow-x-auto flex-1 justify-start sm:justify-end">
        {categories[activeCategory].map((item, idx) => (
          <button
            key={idx}
            onClick={() => onSelectCommand(item.cmd)}
            title={item.desc}
            className="px-2 py-0.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-300 hover:text-cyan-300 text-[11px] whitespace-nowrap transition-all flex items-center gap-1"
          >
            <span>{item.cmd}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
