import React from 'react';

/**
 * Robust ANSI escape code parser for rendering colored terminal text.
 * Handles standard 16 colors, bright variants, 256-color palette, bold, dim, underline, italic, and strikethrough.
 */

// 16 Standard & Bright colors mapped to hex/CSS
const STANDARD_COLORS: Record<number, string> = {
  // Normal
  30: '#1e222a', // black
  31: '#f87171', // red
  32: '#4ade80', // green
  33: '#facc15', // yellow
  34: '#60a5fa', // blue
  35: '#c084fc', // magenta
  36: '#22d3ee', // cyan
  37: '#e2e8f0', // white

  // Bright
  90: '#64748b', // bright black / gray
  91: '#ef4444', // bright red
  92: '#22c55e', // bright green
  93: '#eab308', // bright yellow
  94: '#3b82f6', // bright blue
  95: '#a855f7', // bright magenta
  96: '#06b6d4', // bright cyan
  97: '#f8fafc', // bright white
};

const BG_COLORS: Record<number, string> = {
  40: '#000000',
  41: '#7f1d1d',
  42: '#14532d',
  43: '#713f12',
  44: '#1e3a8a',
  45: '#581c87',
  46: '#164e63',
  47: '#334155',

  100: '#1e293b',
  101: '#991b1b',
  102: '#166534',
  103: '#854d0e',
  104: '#1d4ed8',
  105: '#6b21a8',
  106: '#0e7490',
  107: '#475569',
};

// 256-color lookup helper
function get256Color(n: number): string {
  if (n < 16) {
    const basic = [
      '#000000', '#800000', '#008000', '#808000', '#000080', '#800080', '#008080', '#c0c0c0',
      '#808080', '#ff0000', '#00ff00', '#ffff00', '#0000ff', '#ff00ff', '#00ffff', '#ffffff'
    ];
    return basic[n] || '#ffffff';
  }
  if (n >= 16 && n <= 231) {
    // 6x6x6 color cube
    const num = n - 16;
    const r = Math.floor(num / 36);
    const g = Math.floor((num % 36) / 6);
    const b = num % 6;
    const v = (x: number) => (x === 0 ? 0 : 55 + x * 40);
    return `rgb(${v(r)}, ${v(g)}, ${v(b)})`;
  }
  if (n >= 232 && n <= 255) {
    // Grayscale ramp
    const gray = (n - 232) * 10 + 8;
    return `rgb(${gray}, ${gray}, ${gray})`;
  }
  return '#ffffff';
}

interface SpanStyle {
  color?: string;
  backgroundColor?: string;
  fontWeight?: string | number;
  fontStyle?: string;
  textDecoration?: string;
  opacity?: number;
}

export function parseAnsiToReact(
  rawText: string,
  searchQuery?: string
): React.ReactNode[] {
  if (!rawText) return [];

  // Remove non-SGR escape sequences (e.g. cursor motion, erase line)
  const cleaned = rawText
    .replace(/\x1b\[[0-9;]*[A-HJKSTf]/g, '')
    .replace(/\x1b\([AB012]/g, '')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '');

  // Split on ANSI escape sequences: \x1b[...m
  const regex = /\x1b\[([0-9;]*)m/g;
  let match: RegExpExecArray | null;
  let lastIndex = 0;

  const segments: Array<{ text: string; style: SpanStyle }> = [];
  let currentStyle: SpanStyle = {};

  while ((match = regex.exec(cleaned)) !== null) {
    const textBefore = cleaned.slice(lastIndex, match.index);
    if (textBefore) {
      segments.push({ text: textBefore, style: { ...currentStyle } });
    }

    const codeStr = match[1];
    if (!codeStr || codeStr === '0') {
      // Reset
      currentStyle = {};
    } else {
      const codes = codeStr.split(';').map(c => parseInt(c, 10));
      for (let i = 0; i < codes.length; i++) {
        const code = codes[i];
        if (code === 0) {
          currentStyle = {};
        } else if (code === 1) {
          currentStyle.fontWeight = '600';
        } else if (code === 2) {
          currentStyle.opacity = 0.65;
        } else if (code === 3) {
          currentStyle.fontStyle = 'italic';
        } else if (code === 4) {
          currentStyle.textDecoration = 'underline';
        } else if (code === 22) {
          delete currentStyle.fontWeight;
          delete currentStyle.opacity;
        } else if (code === 23) {
          delete currentStyle.fontStyle;
        } else if (code === 24) {
          delete currentStyle.textDecoration;
        } else if (code === 39) {
          delete currentStyle.color;
        } else if (code === 49) {
          delete currentStyle.backgroundColor;
        } else if (STANDARD_COLORS[code]) {
          currentStyle.color = STANDARD_COLORS[code];
        } else if (BG_COLORS[code]) {
          currentStyle.backgroundColor = BG_COLORS[code];
        } else if (code === 38 && codes[i + 1] === 5 && codes[i + 2] !== undefined) {
          // 256 colors fg: 38;5;N
          currentStyle.color = get256Color(codes[i + 2]);
          i += 2;
        } else if (code === 48 && codes[i + 1] === 5 && codes[i + 2] !== undefined) {
          // 256 colors bg: 48;5;N
          currentStyle.backgroundColor = get256Color(codes[i + 2]);
          i += 2;
        } else if (code === 38 && codes[i + 1] === 2 && codes[i + 4] !== undefined) {
          // 24-bit truecolor fg: 38;2;R;G;B
          currentStyle.color = `rgb(${codes[i + 2]}, ${codes[i + 3]}, ${codes[i + 4]})`;
          i += 4;
        }
      }
    }

    lastIndex = regex.lastIndex;
  }

  const remaining = cleaned.slice(lastIndex);
  if (remaining) {
    segments.push({ text: remaining, style: { ...currentStyle } });
  }

  // If there's an active search query, highlight matching occurrences
  const q = (searchQuery || '').trim();

  return segments.map((seg, sIdx) => {
    if (!q) {
      return (
        <span key={sIdx} style={seg.style}>
          {seg.text}
        </span>
      );
    }

    // Split segment text by search query (case-insensitive)
    const lowerText = seg.text.toLowerCase();
    const lowerQ = q.toLowerCase();
    const parts: React.ReactNode[] = [];
    let searchLastIndex = 0;
    let matchPos = lowerText.indexOf(lowerQ, searchLastIndex);

    while (matchPos !== -1) {
      if (matchPos > searchLastIndex) {
        parts.push(seg.text.slice(searchLastIndex, matchPos));
      }
      parts.push(
        <mark
          key={`mark-${searchLastIndex}`}
          className="bg-amber-400 text-zinc-950 font-bold px-0.5 rounded-xs"
        >
          {seg.text.slice(matchPos, matchPos + q.length)}
        </mark>
      );
      searchLastIndex = matchPos + q.length;
      matchPos = lowerText.indexOf(lowerQ, searchLastIndex);
    }

    if (searchLastIndex < seg.text.length) {
      parts.push(seg.text.slice(searchLastIndex));
    }

    return (
      <span key={sIdx} style={seg.style}>
        {parts}
      </span>
    );
  });
}
