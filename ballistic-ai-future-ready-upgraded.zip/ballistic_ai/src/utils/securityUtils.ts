// Cryptographic & Security Utilities

/**
 * Computes SHA-256 hex string of a File or ArrayBuffer using browser Web Crypto API
 */
export async function computeSha256(data: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Calculates Shannon Entropy of a byte buffer (0.0 to 8.0)
 * High entropy (> 7.0) typically indicates packed, encrypted, or compressed data.
 */
export function calculateEntropy(buffer: ArrayBuffer): number {
  const bytes = new Uint8Array(buffer);
  if (bytes.length === 0) return 0;

  const frequencies = new Array(256).fill(0);
  for (let i = 0; i < bytes.length; i++) {
    frequencies[bytes[i]]++;
  }

  let entropy = 0;
  for (let i = 0; i < 256; i++) {
    if (frequencies[i] > 0) {
      const p = frequencies[i] / bytes.length;
      entropy -= p * Math.log2(p);
    }
  }

  return parseFloat(entropy.toFixed(3));
}

/**
 * Formats bytes to human readable string (KB, MB, etc.)
 */
export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Generates a standard 16-byte hex dump string with ASCII representation
 */
export function generateHexDump(buffer: ArrayBuffer, maxBytes = 512): string {
  const bytes = new Uint8Array(buffer.slice(0, maxBytes));
  const lines: string[] = [];

  for (let i = 0; i < bytes.length; i += 16) {
    const chunk = bytes.slice(i, i + 16);
    const offset = i.toString(16).padStart(8, '0');
    
    // Hex part
    const hexParts: string[] = [];
    for (let j = 0; j < 16; j++) {
      if (j < chunk.length) {
        hexParts.push(chunk[j].toString(16).padStart(2, '0'));
      } else {
        hexParts.push('  ');
      }
      if (j === 7) hexParts.push(' ');
    }
    const hexString = hexParts.join(' ');

    // ASCII part
    let asciiString = '';
    for (let j = 0; j < chunk.length; j++) {
      const byte = chunk[j];
      if (byte >= 32 && byte <= 126) {
        asciiString += String.fromCharCode(byte);
      } else {
        asciiString += '.';
      }
    }

    lines.push(`${offset}  ${hexString}  |${asciiString}|`);
  }

  if (buffer.byteLength > maxBytes) {
    lines.push(`... [Truncated for preview: ${buffer.byteLength - maxBytes} more bytes]`);
  }

  return lines.join('\n');
}

/**
 * CVSS v3.1 Base Score Calculator
 */
export function calculateCvss3(metrics: {
  av: 'N' | 'A' | 'L' | 'P';
  ac: 'L' | 'H';
  pr: 'N' | 'L' | 'H';
  ui: 'N' | 'R';
  s: 'U' | 'C';
  c: 'H' | 'L' | 'N';
  i: 'H' | 'L' | 'N';
  a: 'H' | 'L' | 'N';
}): { score: number; severity: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'; vector: string } {
  const avWeights = { N: 0.85, A: 0.62, L: 0.55, P: 0.2 };
  const acWeights = { L: 0.77, H: 0.44 };
  const prWeightsUnchanged = { N: 0.85, L: 0.62, H: 0.27 };
  const prWeightsChanged = { N: 0.85, L: 0.68, H: 0.5 };
  const uiWeights = { N: 0.85, R: 0.62 };

  const ciaWeights = { H: 0.56, L: 0.22, N: 0.0 };

  const prWeight = metrics.s === 'U' ? prWeightsUnchanged[metrics.pr] : prWeightsChanged[metrics.pr];
  const iss = 1 - (1 - ciaWeights[metrics.c]) * (1 - ciaWeights[metrics.i]) * (1 - ciaWeights[metrics.a]);

  let impact = 0;
  if (metrics.s === 'U') {
    impact = 6.42 * iss;
  } else {
    impact = 7.52 * (iss - 0.029) - 3.25 * Math.pow(iss - 0.02, 15);
  }

  const exploitability = 8.22 * avWeights[metrics.av] * acWeights[metrics.ac] * prWeight * uiWeights[metrics.ui];

  let score = 0;
  if (impact <= 0) {
    score = 0;
  } else if (metrics.s === 'U') {
    score = Math.min(Math.ceil((impact + exploitability) * 10) / 10, 10.0);
  } else {
    score = Math.min(Math.ceil((1.08 * (impact + exploitability)) * 10) / 10, 10.0);
  }

  let severity: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'NONE';
  if (score >= 9.0) severity = 'CRITICAL';
  else if (score >= 7.0) severity = 'HIGH';
  else if (score >= 4.0) severity = 'MEDIUM';
  else if (score > 0.0) severity = 'LOW';

  const vector = `CVSS:3.1/AV:${metrics.av}/AC:${metrics.ac}/PR:${metrics.pr}/UI:${metrics.ui}/S:${metrics.s}/C:${metrics.c}/I:${metrics.i}/A:${metrics.a}`;

  return { score, severity, vector };
}
